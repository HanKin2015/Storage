#ifndef FBC_MESSY_TEST_FUNCTION_POINTERS_HPP_
#define FBC_MESSY_TEST_FUNCTION_POINTERS_HPP_

int test_function_pointers1();
int test_function_pointers2();
int test_function_pointers3();
int test_function_pointers4();
int test_function_pointers5();
int test_function_pointers6();
int test_function_pointers7();
int test_function_pointers8();
int test_function_pointers9();
int test_function_pointers10();
int test_function_pointers11();
int test_function_pointers12();
int test_function_pointers13();
int test_function_pointers14();
int test_function_pointers15();
int test_function_pointers16();
int test_function_pointers17();
int test_function_pointers18();
int test_function_pointers19();
int test_function_pointers20();
int test_function_pointers21();

#endif // FBC_MESSY_TEST_FUNCTION_POINTERS_HPP_
