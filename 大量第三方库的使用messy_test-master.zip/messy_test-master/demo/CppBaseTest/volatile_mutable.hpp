#ifndef FBC_MESSY_TEST_VOLATILE_MUTABLE_HPP_
#define FBC_MESSY_TEST_VOLATILE_MUTABLE_HPP_

namespace volatile_mutable_ {

int test_volatile_1();
int test_volatile_2();
int test_volatile_3();
int test_volatile_4();

int test_mutable_1();
int test_mutable_2();
int test_mutable_3();
int test_mutable_4();

} // namespace volatile_mutable_

#endif // FBC_MESSY_TEST_VOLATILE_MUTABLE_HPP_
