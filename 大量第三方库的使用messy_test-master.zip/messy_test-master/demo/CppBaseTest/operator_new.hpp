#ifndef FBC_CPPBASE_OPERATOR_NEW_HPP_
#define FBC_CPPBASE_OPERATOR_NEW_HPP_

namespace operator_new_ {

int test_operator_new_1();
int test_operator_new_2();
int test_operator_new_3();
int test_operator_new_4();
int test_operator_new_5();

} // namespace operator_new_

#endif // FBC_CPPBASE_OPERATOR_NEW_HPP_
