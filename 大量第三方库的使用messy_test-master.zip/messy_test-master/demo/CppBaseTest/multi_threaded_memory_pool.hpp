#ifndef FBC_CPPBASETEST_MULTI_THREADED_MEMORY_POOL_HPP_
#define FBC_CPPBASETEST_MULTI_THREADED_MEMORY_POOL_HPP_

namespace multi_threaded_memory_pool_ {

int test_multi_threaded_memory_pool_1();
int test_multi_threaded_memory_pool_2();

} // namespace multi_threaded_memory_pool_

#endif // FBC_CPPBASETEST_MULTI_THREADED_MEMORY_POOL_HPP_
