#ifndef FBC_MESSY_TEST_UNION_HPP_
#define FBC_MESSY_TEST_UNION_HPP_

int test_union1();
int test_union2();
int test_union3();

#endif // FBC_MESSY_TEST_UNION_HPP_
