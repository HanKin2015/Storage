#ifndef FBC_MESSY_TEST_LINKED_LIST_HPP_
#define FBC_MESSY_TEST_LINKED_LIST_HPP_

int test_linked_list1();
int test_linked_list2();
int test_linked_list3();
int test_linked_list4();
int test_linked_list5();

#endif // FBC_MESSY_TEST_LINKED_LIST_HPP_
