#ifndef FBC_MESSY_TEST_MOVE_HPP_
#define FBC_MESSY_TEST_MOVE_HPP_

int test_move1();
int test_move2();
int test_move3();
int test_move4();

#endif // FBC_MESSY_TEST_MOVE_HPP_
