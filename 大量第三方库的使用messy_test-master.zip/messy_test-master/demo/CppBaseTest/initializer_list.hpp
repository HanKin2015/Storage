#ifndef FBC_CPPBASE_TEST_INITIALIZER_LIST_HPP_
#define FBC_CPPBASE_TEST_INITIALIZER_LIST_HPP_

int test_initializer_list_1();
int test_initializer_list_2();

#endif // FBC_CPPBASE_TEST_INITIALIZER_LIST_HPP_
