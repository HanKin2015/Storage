#ifndef FBC_CPPBASETEST_CODING_OPTIMIZATIONS_HPP_
#define FBC_CPPBASETEST_CODING_OPTIMIZATIONS_HPP_

namespace coding_optimizations_ {

int test_coding_optimizations_1();
int test_coding_optimizations_2();

} // namespace coding_optimizations_

#endif // FBC_CPPBASETEST_CODING_OPTIMIZATIONS_HPP_
