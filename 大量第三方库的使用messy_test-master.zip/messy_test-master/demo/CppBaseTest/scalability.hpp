#ifndef FBC_CPPBASETEST_SCALABILITY_HPP_
#define FBC_CPPBASETEST_SCALABILITY_HPP_

namespace scalability_ {

int test_scalability_1();
int test_scalability_2();

} // namespace scalability_

#endif // FBC_CPPBASETEST_SCALABILITY_HPP_
