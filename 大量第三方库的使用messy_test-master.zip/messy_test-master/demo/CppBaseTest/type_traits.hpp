#ifndef FBC_MESSY_TEST_TYPE_TRAITS_HPP_
#define FBC_MESSY_TEST_TYPE_TRAITS_HPP_

namespace type_traits_ {

int test_type_traits_helper_classes();
int test_type_traits_type_traits();
int test_type_traits_type_transformations();

} // namespace type_traits_

#endif // FBC_MESSY_TEST_TYPE_TRAITS_HPP_