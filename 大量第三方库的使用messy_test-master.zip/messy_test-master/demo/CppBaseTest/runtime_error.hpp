#ifndef FBC_CPP_BASE_TEST_RUNTIME_ERROR_HPP_
#define FBC_CPP_BASE_TEST_RUNTIME_ERROR_HPP_

namespace runtime_error_ {

int test_runtime_error_1();
int test_runtime_error_2();
int test_runtime_error_3();
int test_runtime_error_4();
int test_runtime_error_5();
int test_runtime_error_6();
int test_runtime_error_7();
int test_runtime_error_8();

} // namespace runtime_error_

#endif // FBC_CPP_BASE_TEST_RUNTIME_ERROR_HPP_
