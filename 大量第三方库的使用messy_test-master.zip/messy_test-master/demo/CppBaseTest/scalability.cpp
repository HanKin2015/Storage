#include "scalability.hpp"
#include <iostream>
#include <chrono>
#include <string>


namespace scalability_ {

// reference: 《提高C++性能的编程技术》：第十五章：可扩展性


int test_scalability_1()
{
	return 0;
}

} // namespace scalability_

