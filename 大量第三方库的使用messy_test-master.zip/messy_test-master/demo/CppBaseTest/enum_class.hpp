#ifndef FBC_CPP_BASE_TEST_ENUM_CLASS_HPP_
#define FBC_CPP_BASE_TEST_ENUM_CLASS_HPP_

namespace enum_class_ {

int test_enum_class_1();
int test_enum_class_2();
int test_enum_class_3();

} // namespace enum_class_

#endif // FBC_CPP_BASE_TEST_ENUM_CLASS_HPP_
