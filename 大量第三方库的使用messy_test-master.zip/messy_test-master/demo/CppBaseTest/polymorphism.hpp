#ifndef FBC_MESSY_TEST_POLYMORPHISM_HPP_
#define FBC_MESSY_TEST_POLYMORPHISM_HPP_

int test_polymorphism1();
int test_polymorphism2();
int test_polymorphism3();
int test_polymorphism4();

#endif // FBC_MESSY_TEST_POLYMORPHISM_HPP_
