#ifndef FBC_MESSY_TEST_SHARED_PTR_HPP_
#define FBC_MESSY_TEST_SHARED_PTR_HPP_

int test_shared_ptr1();
int test_shared_ptr2();
int test_shared_ptr3();
int test_shared_ptr4();
int test_shared_ptr5();
int test_shared_ptr_reset();
int test_shared_ptr_get();
int test_shared_ptr_operator();
int test_shared_ptr_owner_before();
int test_shared_ptr_swap();
int test_shared_ptr_unique();
int test_shared_ptr_reset_delete();

#endif // FBC_MESSY_TEST_SHARED_PTR_HPP_
