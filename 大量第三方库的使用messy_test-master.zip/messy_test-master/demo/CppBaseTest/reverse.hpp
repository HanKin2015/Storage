#ifndef FBC_MESSY_TEST_REVERSE_HPP_
#define FBC_MESSY_TEST_REVERSE_HPP_

int test_reverse_1();
int test_reverse_2();
int test_reverse_copy_1();
int test_reverse_copy_2();

#endif // FBC_MESSY_TEST_REVERSE_HPP_

