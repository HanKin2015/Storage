#ifndef FBC_MESSY_TEST_FOR_HPP_
#define FBC_MESSY_TEST_FOR_HPP_

int test_for1();
int test_for2();
int test_for3();

#endif // FBC_MESSY_TEST_FOR_HPP_
