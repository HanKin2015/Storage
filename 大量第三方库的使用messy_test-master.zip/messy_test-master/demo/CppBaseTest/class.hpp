#ifndef FBC_MESSY_TEST_CLASS_HPP_
#define FBC_MESSY_TEST_CLASS_HPP_

namespace class_{

int test_class1();
int test_class2();
int test_class3();

} // namespace class_

#endif // FBC_MESSY_TEST_CLASS_HPP_
