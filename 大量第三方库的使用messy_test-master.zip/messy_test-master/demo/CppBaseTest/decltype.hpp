#ifndef FBC_MESSY_TEST_DECLTYPE_HPP_
#define FBC_MESSY_TEST_DECLTYPE_HPP_

int test_decltype1();
int test_decltype2();

#endif // FBC_MESSY_TEST_DECLTYPE_HPP_
