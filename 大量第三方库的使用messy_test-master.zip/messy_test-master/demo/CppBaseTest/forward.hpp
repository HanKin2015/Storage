#ifndef FBC_MESSY_TEST_FORWARD_HPP_
#define FBC_MESSY_TEST_FORWARD_HPP_

int test_forward1();
int test_forward2();
int test_forward3();
int test_forward4();

#endif // FBC_MESSY_TEST_FORWARD_HPP_
