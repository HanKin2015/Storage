#ifndef FBC_MESSY_TEST_LAMBDA_HPP_
#define FBC_MESSY_TEST_LAMBDA_HPP_

int test_lambda1();
int test_lambda2();
int test_lambda3();
int test_lambda4();
int test_lambda5();
int test_lambda6();
int test_lambda7();

#endif // FBC_MESSY_TEST_LAMBDA_HPP_
