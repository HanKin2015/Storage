#ifndef FBC_CPP_BASE_EXPONENTIAL_DISTRIBUTION_HPP_
#define FBC_CPP_BASE_EXPONENTIAL_DISTRIBUTION_HPP_

int test_exponential_distribution_1();
int test_exponential_distribution_2();
int test_exponential_distribution_3();

#endif // FBC_CPP_BASE_EXPONENTIAL_DISTRIBUTION_HPP_
