#ifndef FBC_CPPBASE_TEST_TYPEDEF_HPP_
#define FBC_CPPBASE_TEST_TYPEDEF_HPP_

namespace typedef_ {

int test_typedef_1();
int test_typedef_2();
int test_typedef_3();
int test_typedef_4();
int test_typedef_5();

} // nmaespace typedef_

#endif // FBC_CPPBASE_TEST_TYPEDEF_HPP_

