#ifndef FBC_MESSY_TEST_UNIQUE_PTR_HPP_
#define FBC_MESSY_TEST_UNIQUE_PTR_HPP_

namespace unique_ptr_ {

int test_unique_ptr1();
int test_unique_ptr2();
int test_unique_ptr3();
int test_unique_ptr4();
int test_unique_ptr5();
int test_unique_ptr6();
int test_unique_ptr7();
int test_unique_ptr8();
int test_unique_ptr9();
int test_unique_ptr10();
int test_unique_ptr11();
int test_unique_ptr12();
int test_unique_ptr13();

} // namespace unique_ptr_

#endif // FBC_MESSY_TEST_UNIQUE_PTR_HPP_
