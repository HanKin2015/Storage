#ifndef FBC_MESSY_TEST_WEAK_PTR_HPP_
#define FBC_MESSY_TEST_WEAK_PTR_HPP_

int test_weak_ptr1();
int test_weak_ptr2();
int test_weak_ptr3();
int test_weak_ptr4();
int test_weak_ptr5();

#endif // FBC_MESSY_TEST_WEAK_PTR_HPP_
