#ifndef FBC_CPPBASE_TEST_DEQUE_HPP_
#define FBC_CPPBASE_TEST_DEQUE_HPP_

int test_deque_1();
int test_deque_2();

#endif // FBC_CPPBASE_TEST_DEQUE_HPP_

