#ifndef FBC_CPP_BASE_LOCAL_CLASS_HPP_
#define FBC_CPP_BASE_LOCAL_CLASS_HPP_

namespace local_class_ {

int test_local_class_1();
int test_local_class_2();
int test_local_class_3();
int test_local_class_4();
int test_local_class_5();
int test_local_class_6();
int test_local_class_7();
int test_local_class_8();

} // namespace local_class_



#endif // FBC_CPP_BASE_LOCAL_CLASS_HPP_
