#ifndef FBC_CPPBASE_CALL_ONCE_HPP_
#define FBC_CPPBASE_CALL_ONCE_HPP_

namespace call_once_ {

int test_call_once_1();
int test_call_once_2();
int test_call_once_3();

} // namespace call_once_

#endif // FBC_CPPBASE_CALL_ONCE_HPP_

