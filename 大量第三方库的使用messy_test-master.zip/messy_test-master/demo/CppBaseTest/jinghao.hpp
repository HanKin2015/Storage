#ifndef FBC_MESSY_TEST_JING_HAO_HPP_
#define FBC_MESSY_TEST_JING_HAO_HPP_

int test_jinghao1();
int test_jinghao2();

#endif // FBC_MESSY_TEST_JING_HAO_HPP_
