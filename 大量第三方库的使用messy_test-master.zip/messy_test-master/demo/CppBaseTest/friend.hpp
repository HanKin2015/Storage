#ifndef FBC_MESSY_TEST_FRIEND_HPP_
#define FBC_MESSY_TEST_FRIEND_HPP_

int test_friend1();
int test_friend2();
int test_friend3();
int test_friend4();
int test_friend5();
int test_friend6();
int test_friend7();
int test_friend8();
int test_friend9();
int test_friend10();
int test_friend11();
int test_friend12();
int test_friend13();
int test_friend14();
int test_friend15();


#endif // FBC_MESSY_TEST_FRIEND_HPP_
