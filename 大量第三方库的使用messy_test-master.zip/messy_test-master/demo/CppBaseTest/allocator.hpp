#ifndef FBC_CPPBASE_TEST_ALLOCATOR_HPP_
#define FBC_CPPBASE_TEST_ALLOCATOR_HPP_

namespace allocator_ {

int test_allocator_1();
int test_allocator_2();
int test_allocator_3();
int test_allocator_4();

} // namespace allocator_

#endif // FBC_CPPBASE_TEST_ALLOCATOR_HPP_
