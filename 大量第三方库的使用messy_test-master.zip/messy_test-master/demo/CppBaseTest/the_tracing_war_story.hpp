#ifndef FBC_CPPBASETEST_TRACING_WAR_STORY_HPP_
#define FBC_CPPBASETEST_TRACING_WAR_STORY_HPP_

// reference: 《提高C++性能的编程技术》: 第一章：跟踪实例

namespace tracing_war_story_ {

	int test_tracing_war_story();

} // namespace tracing_war_story_


#endif // FBC_CPPBASETEST_TRACING_WAR_STORY_HPP_

