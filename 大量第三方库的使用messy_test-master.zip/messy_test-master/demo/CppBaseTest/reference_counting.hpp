#ifndef FBC_CPPBASETEST_REFERENCE_COUNTING_HPP_
#define FBC_CPPBASETEST_REFERENCE_COUNTING_HPP_

namespace reference_counting_ {

int test_reference_counting_1();
int test_reference_counting_2();

} // namespace reference_counting_

#endif // FBC_CPPBASETEST_REFERENCE_COUNTING_HPP_
