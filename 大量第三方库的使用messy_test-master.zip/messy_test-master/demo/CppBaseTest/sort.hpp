#ifndef FBC_MESSY_TEST_SORT_HPP_
#define FBC_MESSY_TEST_SORT_HPP_

int test_sort_bubble();
int test_sort_insertion();
int test_sort_selection();
int test_sort_shell();
int test_sort_merge();
int test_sort_quick();
int test_sort_heap();
int test_sort_STL();

#endif // FBC_MESSY_TEST_SORT_HPP_
