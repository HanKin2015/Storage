#ifndef FBC_CPPBASETEST_RETURN_VALUE_OPTIMIZATION_HPP_
#define FBC_CPPBASETEST_RETURN_VALUE_OPTIMIZATION_HPP_

namespace return_value_optimization_ {

int test_return_value_optimization_1();

} // namespace return_value_optimization_

#endif // FBC_CPPBASETEST_RETURN_VALUE_OPTIMIZATION_HPP_
