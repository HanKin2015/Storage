#ifndef FBC_MESSY_TEST_ADDRESSOF_HPP_
#define FBC_MESSY_TEST_ADDRESSOF_HPP_

int test_addressof_1();
int test_addressof_2();
int test_addressof_3();
int test_addressof_4();

#endif // FBC_MESSY_TEST_ADDRESSOF_HPP_

