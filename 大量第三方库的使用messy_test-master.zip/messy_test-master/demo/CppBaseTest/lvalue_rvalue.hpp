#ifndef FBC_CPPBASE_LVALUE_RVALUE_HPP_
#define FBC_CPPBASE_LVALUE_RVALUE_HPP_

namespace lvalue_rvalue_ {

int test_lvalue_rvalue_1();
int test_lvalue_rvalue_2();
int test_lvalue_rvalue_3();
int test_lvalue_rvalue_4();
int test_lvalue_rvalue_5();
int test_lvalue_rvalue_6();
int test_lvalue_rvalue_7();
int test_lvalue_rvalue_8();
int test_lvalue_rvalue_9();
int test_lvalue_rvalue_10();

} // namespace lvalue_rvalue_

#endif // FBC_CPPBASE_LVALUE_RVALUE_HPP_

