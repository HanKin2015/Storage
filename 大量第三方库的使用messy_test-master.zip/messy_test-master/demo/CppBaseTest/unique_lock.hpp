#ifndef FBC_CPPBASE_UNIQUE_LOCK_HPP_
#define FBC_CPPBASE_UNIQUE_LOCK_HPP_

namespace unique_lock_ {

int test_unique_lock_1();
int test_unique_lock_2();
int test_unique_lock_3();
int test_unique_lock_4();
int test_unique_lock_5();
int test_unique_lock_6();
int test_unique_lock_7();
int test_unique_lock_8();
int test_unique_lock_9();
int test_unique_lock_10();

} // namespace unique_lock_

#endif // FBC_CPPBASE_UNIQUE_LOCK_HPP_
