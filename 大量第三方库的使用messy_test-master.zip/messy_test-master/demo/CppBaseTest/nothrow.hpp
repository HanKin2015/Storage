#ifndef FBC_MESSY_TEST_NOTHROW_HPP_
#define FBC_MESSY_TEST_NOTHROW_HPP_

int test_nothrow1();
int test_nothrow2();

#endif // FBC_MESSY_TEST_NOTHROW_HPP_
