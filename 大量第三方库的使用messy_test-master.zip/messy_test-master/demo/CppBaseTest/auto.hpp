#ifndef FBC_MESSY_TEST_AUTO_HPP_
#define FBC_MESSY_TEST_AUTO_HPP_

int test_auto1();
int test_auto2();
int test_auto3();

#endif // FBC_MESSY_TEST_AUTO_HPP_
