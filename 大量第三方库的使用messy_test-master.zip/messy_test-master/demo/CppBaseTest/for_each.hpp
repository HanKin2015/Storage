#ifndef FBC_MESSY_TEST_FOR_EACH_HPP_
#define FBC_MESSY_TEST_FOR_EACH_HPP_

int test_for_each1();
int test_for_each2();
int test_for_each3();
int test_for_each4();
int test_for_each5();

#endif // FBC_MESSY_TEST_FOR_EACH_HPP_
