#ifndef FBC_MESSY_TEST_ISTREAM_HPP_
#define FBC_MESSY_TEST_ISTREAM_HPP_

void test_istream();

#endif // FBC_MESSY_TEST_ISTREAM_HPP_
