#ifndef FBC_CPPBASETEST_INLINE_HPP_
#define FBC_CPPBASETEST_INLINE_HPP_

namespace inline_ {

int test_inline_1();
int test_inline_2();

} // namespace inline_

#endif // FBC_CPPBASETEST_INLINE_HPP_
