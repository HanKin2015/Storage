#ifndef FBC_CPP_BASE_TEST_EXCEPTION_HPP_
#define FBC_CPP_BASE_TEST_EXCEPTION_HPP_

namespace exception_ {

int test_exception_1();
int test_exception_2();
int test_exception_3();

} // namespace exception_

#endif // FBC_CPP_BASE_TEST_EXCEPTION_HPP_
