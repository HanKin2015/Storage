#ifndef FBC_CPP_BASE_TEST_ARRAY_HPP_
#define FBC_CPP_BASE_TEST_ARRAY_HPP_

int test_array_1();
int test_array_2();
int test_array_3();

#endif // FBC_CPP_BASE_TEST_ARRAY_HPP_
