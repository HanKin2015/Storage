#ifndef FBC_CPP_BASE_NORMAL_DISTRIBUTION_HPP_
#define FBC_CPP_BASE_NORMAL_DISTRIBUTION_HPP_

int test_normal_distribution_1();
int test_normal_distribution_2();
int test_normal_distribution_3();

#endif // FBC_CPP_BASE_NORMAL_DISTRIBUTION_HPP_
