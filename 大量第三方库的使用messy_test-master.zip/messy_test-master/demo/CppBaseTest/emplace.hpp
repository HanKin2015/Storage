#ifndef FBC_CPPBASE_EMPLACE_HPP_
#define FBC_CPPBASE_EMPLACE_HPP_

namespace emplace_ {

int test_emplace_1();
int test_emplace_2();
int test_emplace_3();
int test_emplace_4();

} // namespace emplace_

#endif // FBC_CPPBASE_EMPLACE_HPP_

