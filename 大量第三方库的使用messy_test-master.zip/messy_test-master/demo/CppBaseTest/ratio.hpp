#ifndef FBC_CPP_BASE_TEST_RATIO_HPP_
#define FBC_CPP_BASE_TEST_RATIO_HPP_

int test_ratio_1();
int test_ratio_2();

#endif // FBC_CPP_BASE_TEST_RATIO_HPP_
