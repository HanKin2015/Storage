#ifndef FBC_CPPBASETEST_TEMPORARY_OBJECT_HPP_
#define FBC_CPPBASETEST_TEMPORARY_OBJECT_HPP_

namespace temporary_object_ {

int test_temporary_object_1();
int test_temporary_object_2();

} // namespace temporary_object_

#endif // FBC_CPPBASETEST_TEMPORARY_OBJECT_HPP_
