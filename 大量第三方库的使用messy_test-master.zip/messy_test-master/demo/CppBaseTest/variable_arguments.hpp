#ifndef FBC_MESSY_TEST_CPPBASE_VARIABLE_ARGUMENTS_HPP_
#define FBC_MESSY_TEST_CPPBASE_VARIABLE_ARGUMENTS_HPP_

namespace variable_arguments_ {

int test_variable_arguments_macro_1();
int test_variable_arguments_macro_2();
int test_variable_arguments_macro_3();
int test_variable_arguments_function_1();
int test_variable_arguments_function_2();
int test_variable_arguments_function_3();
int test_variable_arguments_function_4();
int test_variable_arguments_function_5();
int test_variable_arguments_template_class_1();
int test_variable_arguments_template_function_1();
int test_variable_arguments_template_function_2();
int test_variable_arguments_template_function_3();
int test_variable_arguments_sizeof_1();

} // namespace variable_arguments_

#endif // FBC_MESSY_TEST_CPPBASE_VARIABLE_ARGUMENTS_HPP_
