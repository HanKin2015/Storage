#ifndef FBC_MESSY_TEST_TEST_THREAD_HPP_
#define FBC_MESSY_TEST_TEST_THREAD_HPP_

int test_create_thread();
int test_thread_mutex();
int test_thread_cond1();
int test_thread_cond2();
int test_thread_cond3();

#endif // FBC_MESSY_TEST_TEST_THREAD_HPP_
