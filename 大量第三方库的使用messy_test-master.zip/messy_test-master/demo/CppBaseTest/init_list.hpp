#ifndef FBC_MESSY_TEST_INIT_LIST_HPP_
#define FBC_MESSY_TEST_INIT_LIST_HPP_

int test_init_list1();
int test_init_list2();
int test_init_list3();

#endif // FBC_MESSY_TEST_INIT_LIST_HPP_
