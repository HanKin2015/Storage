#ifndef FBC_MESSY_TEST_CPPBASE_ITERATOR_HPP_
#define FBC_MESSY_TEST_CPPBASE_ITERATOR_HPP_

namespace iterator_ {

int test_iterator_1();
int test_iterator_2();
int test_iterator_3();
int test_iterator_4();
int test_iterator_5();
int test_iterator_6();
int test_iterator_7();
int test_iterator_8();
int test_iterator_9();
int test_iterator_10();
int test_iterator_11();
int test_iterator_12();
int test_iterator_13();
int test_iterator_14();
int test_iterator_15();
int test_iterator_16();
int test_iterator_17();
int test_iterator_18();
int test_iterator_19();
int test_iterator_20();

} // namespace iterator_

#endif // FBC_MESSY_TEST_CPPBASE_ITERATOR_HPP_
