#ifndef FBC_CPPBASE_LOCK_GUARD_HPP_
#define FBC_CPPBASE_LOCK_GUARD_HPP_

namespace lock_guard_ {

int test_lock_guard_1();
int test_lock_guard_2();
int test_lock_guard_3();
int test_lock_guard_4();

} // namespace lock_guard_

#endif // FBC_CPPBASE_LOCK_GUARD_HPP_
