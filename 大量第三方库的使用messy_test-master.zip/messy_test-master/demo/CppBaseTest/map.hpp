#ifndef FBC_MESSY_TEST_MAP_HPP_
#define FBC_MESSY_TEST_MAP_HPP_

int test_map1();
int test_map2();
int test_map3();
int test_map4();
int test_map5();

#endif // FBC_MESSY_TEST_MAP_HPP_
