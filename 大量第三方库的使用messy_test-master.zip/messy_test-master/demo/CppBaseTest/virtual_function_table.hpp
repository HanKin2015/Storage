#ifndef FBC_CPPBASE_TEST_VIRTUAL_FUNCTION_TABLE_HPP_
#define FBC_CPPBASE_TEST_VIRTUAL_FUNCTION_TABLE_HPP_

namespace virtual_function_table_ {

int test_virtual_function_table_1();

} // namespace virtual_function_table_

#endif // FBC_CPPBASE_TEST_VIRTUAL_FUNCTION_TABLE_HPP_
