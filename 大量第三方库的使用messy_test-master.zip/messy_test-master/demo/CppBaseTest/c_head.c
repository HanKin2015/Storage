#include "c_head.h"
#include <stdio.h>

void tmp_f(void)
{
	fprintf(stdout, "\n This is a C code\n");
}
