#ifndef FBC_CPP_BASE_TEST_CHRONO_HPP_
#define FBC_CPP_BASE_TEST_CHRONO_HPP_

int test_chrono_1();
int test_chrono_duration();
int test_chrono_high_resolution_clock();
int test_chrono_steady_clock();
int test_chrono_system_clock();
int test_chrono_time_point();

#endif // FBC_CPP_BASE_TEST_CHRONO_HPP_
