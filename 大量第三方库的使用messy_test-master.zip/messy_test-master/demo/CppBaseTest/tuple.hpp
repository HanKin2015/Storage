#ifndef FBC_CPP_BASE_TEST_TUPLE_HPP_
#define FBC_CPP_BASE_TEST_TUPLE_HPP_

int test_tuple_1();
int test_tuple_2();
int test_tuple_3();
int test_tuple_4();

#endif // FBC_CPP_BASE_TEST_TUPLE_HPP_
