#ifndef FBC_MESSY_TEST_RVALUE_REFERENCES_HPP_
#define FBC_MESSY_TEST_RVALUE_REFERENCES_HPP_

int test_lvalue_references1();
int test_rvalue_references1();
int test_rvalue_references2();
int test_rvalue_references3();

#endif // FBC_MESSY_TEST_RVALUE_REFERENCES_HPP_
