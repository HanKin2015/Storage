#ifndef FBC_MESSY_TEST_PRIORITY_QUEUE_HPP_
#define FBC_MESSY_TEST_PRIORITY_QUEUE_HPP_

int test_priority_queue_1();
int test_priority_queue_2();
int test_priority_queue_3();
int test_priority_queue_4();

#endif // FBC_MESSY_TEST_PRIORITY_QUEUE_HPP_
