#ifndef FBC_MESSY_TEST_FSTREAM_HPP_
#define FBC_MESSY_TEST_FSTREAM_HPP_

int test_file_size();
int test_fstream1();
int test_fstream2();
int test_fstream3();
int test_fstream4();
int test_fstream6();
int test_fstream7();

int test_init_database();
int test_store_database();
int test_close_database();
int test_fstream5();

// http://www.bogotobogo.com/cplusplus/fstream_input_output.php


#endif // FBC_MESSY_TEST_FSTREAM_HPP_

