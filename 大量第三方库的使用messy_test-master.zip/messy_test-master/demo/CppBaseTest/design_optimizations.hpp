#ifndef FBC_CPPBASETEST_DESIGN_OPTIMIZATIONS_HPP_
#define FBC_CPPBASETEST_DESIGN_OPTIMIZATIONS_HPP_

namespace design_optimizations_ {

int test_design_optimizations_1();
int test_design_optimizations_2();

} // namespace design_optimizations_

#endif // FBC_CPPBASETEST_DESIGN_OPTIMIZATIONS_HPP_
