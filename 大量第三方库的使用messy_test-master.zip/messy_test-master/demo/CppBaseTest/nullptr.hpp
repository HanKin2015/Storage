#ifndef FBC_MESSY_TEST_NULLPTR_HPP_
#define FBC_MESSY_TEST_NULLPTR_HPP_

int test_nullptr1();
int test_nullptr2();
int test_nullptr3();
int test_nullptr4();
int test_nullptr5();

#endif // FBC_MESSY_TEST_NULLPTR_HPP_

