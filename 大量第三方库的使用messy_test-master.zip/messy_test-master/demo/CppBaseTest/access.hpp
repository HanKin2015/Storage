#ifndef CPPBASE_TEST_ACCESS_HPP_
#define CPPBASE_TEST_ACCESS_HPP_

namespace access_ {

int test_access_1();

} // namespace access_

#endif // CPPBASE_TEST_ACCESS_HPP_
