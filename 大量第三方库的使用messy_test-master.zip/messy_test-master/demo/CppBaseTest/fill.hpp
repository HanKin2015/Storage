#ifndef FBC_MESSY_TEST_FILL_HPP_
#define FBC_MESSY_TEST_FILL_HPP_

int test_fill_1();
int test_fill_2();
int test_fill_n_1();

#endif // FBC_MESSY_TEST_FILL_HPP_
