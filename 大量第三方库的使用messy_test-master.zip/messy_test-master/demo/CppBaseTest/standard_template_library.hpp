#ifndef FBC_CPPBASETEST_STANDARD_TEMPLATE_LIBRARY_HPP_
#define FBC_CPPBASETEST_STANDARD_TEMPLATE_LIBRARY_HPP_

namespace standard_template_library_ {

int test_standard_template_library_1();
int test_standard_template_library_2();

} // namespace standard_template_library_

#endif // FBC_CPPBASETEST_STANDARD_TEMPLATE_LIBRARY_HPP_
