#ifndef FBC_CPP_BASE_CONDITION_VARIABLE_HPP_
#define FBC_CPP_BASE_CONDITION_VARIABLE_HPP_

namespace condition_variable_ {

int test_condition_variable_1();
int test_condition_variable_wait();
int test_condition_variable_wait_for();
int test_condition_variable_notify_one();
int test_condition_variable_notify_all();
int test_condition_variable_2();

} // namespace condition_variable_

#endif // FBC_CPP_BASE_CONDITION_VARIABLE_HPP_
