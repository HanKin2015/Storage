#ifndef FBC_MESSY_TEST_DELTET_HPP_
#define FBC_MESSY_TEST_DELTET_HPP_

int test_delete1();

#endif // FBC_MESSY_TEST_DELTET_HPP_
