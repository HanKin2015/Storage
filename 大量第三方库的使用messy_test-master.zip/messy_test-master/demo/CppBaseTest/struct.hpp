#ifndef FBC_MESSY_TEST_STRUCT_HPP_
#define FBC_MESSY_TEST_STRUCT_HPP_

int test_struct1();
int test_struct2();
int test_struct3();
int test_struct4();

#endif // FBC_MESSY_TEST_STRUCT_HPP_
