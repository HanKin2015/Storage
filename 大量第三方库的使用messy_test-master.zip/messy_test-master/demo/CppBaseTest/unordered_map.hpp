#ifndef FBC_MESSY_TEST_UNORDERED_MAP_HPP_
#define FBC_MESSY_TEST_UNORDERED_MAP_HPP_

int test_unordered_map1();
int test_unordered_map2();
int test_unordered_map3();

#endif // FBC_MESSY_TEST_UNORDERED_MAP_HPP_
