#ifndef FBC_CPP_BASE_MUTEX_HPP_
#define FBC_CPP_BASE_MUTEX_HPP_

namespace mutex_ {

int test_mutex_1();
int test_mutex_2();
int test_mutex_3();

} // namespace mutex_
#endif // FBC_CPP_BASE_MUTEX_HPP_
