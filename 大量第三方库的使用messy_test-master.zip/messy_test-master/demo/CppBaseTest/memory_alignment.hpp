#ifndef FBC_CPPBASE_TEST_MEMORY_ALIGNMENT_HPP_
#define FBC_CPPBASE_TEST_MEMORY_ALIGNMENT_HPP_

namespace memory_alignment_ {

int test_memory_alignment_1();
int test_memory_alignment_2();
int test_memory_alignment_3();
int test_memory_alignment_4();

} // memory_alignment_


#endif // FBC_CPPBASE_TEST_MEMORY_ALIGNMENT_HPP_

