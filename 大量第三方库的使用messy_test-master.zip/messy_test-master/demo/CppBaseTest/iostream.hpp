#ifndef FBC_MESSY_TEST_IOSTRAM_HPP_
#define FBC_MESSY_TEST_IOSTRAM_HPP_

int test_iostream_cout();
int test_iostream_cin();
int test_iostream_clog();
int test_iostream_cerr();
int test_iostream_w();


#endif // FBC_MESSY_TEST_IOSTRAM_HPP_
