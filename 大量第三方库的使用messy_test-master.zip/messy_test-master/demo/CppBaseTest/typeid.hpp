#ifndef FBC_MESSY_TEST_TYPEID_HPP_
#define FBC_MESSY_TEST_TYPEID_HPP_

int test_typeid1();
int test_typeid2();
int test_typeid3();

#endif // FBC_MESSY_TEST_TYPEID_HPP_
