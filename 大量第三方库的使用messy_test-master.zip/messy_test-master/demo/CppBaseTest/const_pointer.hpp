#ifndef FBC_CPP_BASE_CONST_POINTER_HPP_
#define FBC_CPP_BASE_CONST_POINTER_HPP_

int test_const_pointer_1();
int test_const_pointer_2();

#endif // FBC_CPP_BASE_CONST_POINTER_HPP_
