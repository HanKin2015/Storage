#ifndef FBC_CPP_BASE_NESTED_CLASS_HPP_
#define FBC_CPP_BASE_NESTED_CLASS_HPP_

namespace nested_class_ {

int test_nested_class_1();
int test_nested_class_2();
int test_nested_class_3();
int test_nested_class_4();
int test_nested_class_5();
int test_nested_class_6();
int test_nested_class_7();

} // namespace nested_class_

#endif // FBC_CPP_BASE_NESTED_CLASS_HPP_

