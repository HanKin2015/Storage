#ifndef FBC_CPPBASE_C_HEAD_H_
#define FBC_CPPBASE_C_HEAD_H_

void tmp_f(void);

#endif // FBC_CPPBASE_C_HEAD_H_
