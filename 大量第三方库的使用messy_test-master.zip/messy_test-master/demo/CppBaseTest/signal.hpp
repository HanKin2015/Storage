#ifndef FBC_MESSY_TEST_CPPBASETEST_SIGNAL_HPP_
#define FBC_MESSY_TEST_CPPBASETEST_SIGNAL_HPP_

namespace signal_ {

int test_signal_SIGINT();
int test_signal_SIGILL();
int test_signal_SIGFPE();
int test_signal_SIGSEGV();
int test_signal_SIGTERM();
int test_signal_SIGABRT();

} // signal_

#endif // FBC_MESSY_TEST_CPPBASETEST_SIGNAL_HPP_
