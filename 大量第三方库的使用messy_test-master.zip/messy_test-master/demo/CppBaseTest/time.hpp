#ifndef FBC_MESSY_TEST_TIME_HPP_
#define FBC_MESSY_TEST_TIME_HPP_

namespace time_ {

int test_gmtime_localtime();
int test_date_timestamp();

} // namespace time_

#endif // FBC_MESSY_TEST_TIME_HPP_
