#ifndef FBC_MESSY_TEST_SSTREAM_HPP_
#define FBC_MESSY_TEST_SSTREAM_HPP_

int test_ostringstream();
int test_istringstream();
int test_stringstream();

#endif // FBC_MESSY_TEST_STREAM_HPP_
