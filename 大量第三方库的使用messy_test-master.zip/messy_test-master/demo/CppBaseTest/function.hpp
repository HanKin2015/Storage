#ifndef FBC_MESSY_TEST_FUNCTION_HPP_
#define FBC_MESSY_TEST_FUNCTION_HPP_

int test_function1();
int test_function2();
int test_function3();

#endif // FBC_MESSY_TEST_FUNCTION_HPP_
