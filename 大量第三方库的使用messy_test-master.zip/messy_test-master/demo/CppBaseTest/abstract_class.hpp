#ifndef FBC_MESSY_TEST_ABSTRACT_CLASS_HPP_
#define FBC_MESSY_TEST_ABSTRACT_CLASS_HPP_

namespace abstract_class_ {

int test_abstract_class1();
int test_abstract_class2();
int test_abstract_class3();
int test_abstract_class4();
int test_abstract_class5();
int test_abstract_class6();

} // namespace abstract_class_

#endif // FBC_MESSY_TEST_ABSTRACT_CLASS_HPP_
