#ifndef FBC_MESSY_TEST_REFERENCE_HPP_
#define FBC_MESSY_TEST_REFERENCE_HPP_

int test_reference_1();
int test_reference_2();
int test_reference_3();

#endif // FBC_MESSY_TEST_REFERENCE_HPP_
