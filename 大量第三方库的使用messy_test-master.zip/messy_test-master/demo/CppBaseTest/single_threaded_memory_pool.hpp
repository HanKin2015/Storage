#ifndef FBC_CPPBASETEST_SINGLE_THREADED_MEMORY_POOL_HPP_
#define FBC_CPPBASETEST_SINGLE_THREADED_MEMORY_POOL_HPP_

namespace single_threaded_memory_pool_ {

int test_single_threaded_memory_pool_1();
int test_single_threaded_memory_pool_2();

} // namespace single_threaded_memory_pool_

#endif // FBC_CPPBASETEST_SINGLE_THREADED_MEMORY_POOL_HPP_
