#ifndef FBC_MESSY_TEST_BIND_HPP_
#define FBC_MESSY_TEST_BIND_HPP_

int test_bind1();
int test_bind2();
int test_bind3();
int test_bind4();
int test_bind5();

#endif // FBC_MESSY_TEST_BIND_HPP_
