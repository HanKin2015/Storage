#ifndef FBC_MESSY_TEST_PAIR_HPP_
#define FBC_MESSY_TEST_PAIR_HPP_

int test_pair1();
int test_pair2();
int test_pair3();

#endif // FBC_MESSY_TEST_PAIR_HPP_
