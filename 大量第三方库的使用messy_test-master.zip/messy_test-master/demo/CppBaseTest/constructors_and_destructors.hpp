#ifndef FBC_CPPBASETEST_CONSTRUCTORS_AND_DESTRUCTORS_HPP_
#define FBC_CPPBASETEST_CONSTRUCTORS_AND_DESTRUCTORS_HPP_

namespace constructors_destructors_ {

int test_constructors_destructors_1();

} // namespace constructors_destructors_


#endif // FBC_CPPBASETEST_CONSTRUCTORS_AND_DESTRUCTORS_HPP_

