#ifndef FBC_CPPBASE_SORT1_HPP_
#define FBC_CPPBASE_SORT1_HPP_

int test_sort_1();
int test_sort_2();
int test_sort_3();
int test_sort_4();
int test_stable_sort_1();
int test_stable_sort_2();
int test_partial_sort_1();

#endif // FBC_CPPBASE_SORT1_HPP_
