#ifndef FBC_CPPBASE_TEST_STACK_HPP_
#define FBC_CPPBASE_TEST_STACK_HPP_

int test_stack_1();
int test_stack_2();

#endif // FBC_CPPBASE_TEST_STACK_HPP_
