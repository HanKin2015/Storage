#ifndef FBC_MESSY_TEST_INHERITANCE_HPP_
#define FBC_MESSY_TEST_INHERITANCE_HPP_

int test_inheritance1();
int test_inheritance2();
int test_inheritance3();
int test_inheritance4();

#endif // FBC_MESSY_TEST_INHERITANCE_HPP_
