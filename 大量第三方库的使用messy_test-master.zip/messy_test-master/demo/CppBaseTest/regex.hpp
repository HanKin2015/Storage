#ifndef FBC_MESSY_TEST_REGEX_HPP_
#define FBC_MESSY_TEST_REGEX_HPP_

int test_regex_match();
int test_regex_search();
int test_regex_search2();
int test_regex_replace();
int test_regex_replace2();


#endif // FBC_MESSY_TEST_REGEX_HPP_
