#ifndef FBC_MESSY_TEST_VECTOR_HPP
#define FBC_MESSY_TEST_VECTOR_HPP

int test_vector_init();
int test_vector_access();
int test_vector_operation();
int test_vector_two_dimension();

#endif // FBC_MESSY_TEST_VECTOR_HPP
