#ifndef FBC_CPP_BASE_TEST_LIST_HPP_
#define FBC_CPP_BASE_TEST_LIST_HPP_

int test_list_1();
int test_list_2();

#endif // FBC_CPP_BASE_TEST_LIST_HPP_