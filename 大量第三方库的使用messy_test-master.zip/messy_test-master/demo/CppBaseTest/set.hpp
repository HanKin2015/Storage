#ifndef FBC_MESSY_TEST_SET_HPP_
#define FBC_MESSY_TEST_SET_HPP_

int test_set_cplusplus();
int test_set_cppreference();

#endif // FBC_MESSY_TEST_SET_HPP_
