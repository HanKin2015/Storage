#ifndef FBC_MESSY_TEST_TRY_CATCH_HPP_
#define FBC_MESSY_TEST_TRY_CATCH_HPP_

int test_exception1();
int test_exception2();
int test_exception3();
int test_exception4();
int test_exception5();
int test_exception6();
int test_exception7();

#endif // FBC_MESSY_TEST_TRY_CATCH_HPP_
