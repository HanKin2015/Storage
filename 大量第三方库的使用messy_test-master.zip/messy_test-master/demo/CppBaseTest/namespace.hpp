#ifndef FBC_CPPBASE_TEST_NAMESPACE_HPP_
#define FBC_CPPBASE_TEST_NAMESPACE_HPP_

namespace namespace_ {

int test_namespace_1();
int test_namespace_2();
int test_namespace_3();
int test_namespace_4();
int test_namespace_5();
int test_namespace_6();

} // using namespace_


#endif // FBC_CPPBASE_TEST_NAMESPACE_HPP_

