#ifndef FBC_MESSY_TEST_SPDLOG_TEST_FUNSET_HPP_
#define FBC_MESSY_TEST_SPDLOG_TEST_FUNSET_HPP_

int test_spdlog_console();
int test_spdlog_async();
int test_spdlog_syslog();
int test_spdlog_user_defined();
int test_spdlog_err_handler();
int test_spdlog_user_defined_macro();

#endif // FBC_MESSY_TEST_SPDLOG_TEST_FUNSET_HPP_
