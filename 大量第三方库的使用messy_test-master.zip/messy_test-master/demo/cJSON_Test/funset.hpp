#ifndef FBC_CJSON_TEST_FUNSET_HPP_
#define FBC_CJSON_TEST_FUNSET_HPP_

int read_file(const char* filename, char* content);
void utf8_to_gbk(const char* utf8, char* gbk);
int test_cjson_1();
int test_cjson_2();


#endif // FBC_CJSON_TEST_FUNSET_HPP_
