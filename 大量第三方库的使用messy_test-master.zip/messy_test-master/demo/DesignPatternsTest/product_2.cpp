#include "product_2.hpp"

#include <iostream>

Product_2::Product_2()
{

}

Product_2::~Product_2()
{

}

ConcreteProduct_2::ConcreteProduct_2()
{
	std::cout<<"ConcreteProduct_2 ..."<<std::endl;
}

ConcreteProduct_2::~ConcreteProduct_2()
{

}
