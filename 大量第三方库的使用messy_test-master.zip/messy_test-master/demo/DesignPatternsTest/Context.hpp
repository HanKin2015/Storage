#ifndef FBC_MESSY_TEST_CONTEXT_HPP_
#define FBC_MESSY_TEST_CONTEXT_HPP_

class Context_1
{
public:
	Context_1();
	~Context_1();
protected:
private:
};

#endif // FBC_MESSY_TEST_CONTEXT_HPP_
