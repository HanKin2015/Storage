#include "Context.hpp"

Context_1::Context_1()
{

}

Context_1::~Context_1()
{

}