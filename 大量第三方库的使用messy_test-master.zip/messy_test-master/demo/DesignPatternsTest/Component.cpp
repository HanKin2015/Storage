#include "Component.hpp"

Component_1::Component_1()
{

}

Component_1::~Component_1()
{

}

void Component_1::Add(const Component_1&)
{

}

Component_1* Component_1::GetChild(int index)
{
	return 0;
}

void Component_1::Remove(const Component_1& com)
{

}
