#ifndef FBC_MESSY_TEST_RECEIVER_HPP_
#define FBC_MESSY_TEST_RECEIVER_HPP_

class Receiver
{
public:
	Receiver();
	~Receiver();
	void Action();
protected:
private:
};

#endif // FBC_MESSY_TEST_RECEIVER_HPP_
