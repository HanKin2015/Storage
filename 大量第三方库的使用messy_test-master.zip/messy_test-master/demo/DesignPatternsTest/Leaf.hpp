#ifndef FBC_MESSY_TEST_LEAF_HPP_
#define FBC_MESSY_TEST_LEAF_HPP_

#include "Component.hpp"

class Leaf_1 : public Component_1
{
public:
	Leaf_1();
	~Leaf_1();
	void Operation();
protected:
private:
};

#endif // FBC_MESSY_TEST_LEAF_HPP_
