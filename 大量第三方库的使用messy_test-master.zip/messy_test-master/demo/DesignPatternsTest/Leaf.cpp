#include <iostream>
#include "Leaf.hpp"

Leaf_1::Leaf_1()
{

}

Leaf_1::~Leaf_1()
{

}

void Leaf_1::Operation()
{
	std::cout<<"Leaf Operation ..."<<std::endl;
}