#include "Receiver.hpp"
#include <iostream>

Receiver::Receiver()
{

}

Receiver::~Receiver()
{

}

void Receiver::Action()
{
	std::cout<<"Receiver action ..."<<std::endl;
}