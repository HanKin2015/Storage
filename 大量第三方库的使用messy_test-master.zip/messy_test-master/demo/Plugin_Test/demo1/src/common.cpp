#include "common.hpp"

FBC_API char* get_csdn_blog_address()
{
	return "https://blog.csdn.net/fengbingchun";
}

FBC_API char* get_github_address()
{
	return "https://github.com//fengbingchun";
}