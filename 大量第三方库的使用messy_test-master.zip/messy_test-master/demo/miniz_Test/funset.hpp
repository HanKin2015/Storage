#ifndef FBC_MESSY_TEST_MINIZ_FUNSET_HPP_
#define FBC_MESSY_TEST_MINIZ_FUNSET_HPP_

int test_miniz_1();
int test_miniz_2();
int test_miniz_3();
int test_miniz_4();
int test_miniz_5();
int test_miniz_6();

#endif // FBC_MESSY_TEST_MINIZ_FUNSET_HPP_
