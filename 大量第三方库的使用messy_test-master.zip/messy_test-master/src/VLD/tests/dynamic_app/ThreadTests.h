#pragma once

void RunLoaderLockTests(bool);

