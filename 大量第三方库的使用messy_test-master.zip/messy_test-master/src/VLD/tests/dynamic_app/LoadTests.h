#pragma once

HMODULE RunLoaderTests( bool resolve );
HMODULE RunMFCLoaderTests( bool resolve );
