
#define VLDVERSION          L"2.4RC2"
#define VERSION_NUMBER		2,4,1,0
#define VERSION_STRING		"2.4.1.0"
#define VERSION_COPYRIGHT	"Copyright (C) 2005-2014"

#ifndef __FILE__
!define VLD_VERSION "2.4RC2"	// NSIS Script
#endif
