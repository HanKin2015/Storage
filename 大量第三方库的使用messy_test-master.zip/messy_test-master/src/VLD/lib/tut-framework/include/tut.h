#warning This header is deprecated and will be removed in next versions. Please #include <tut/tut.hpp> instead
#include <tut/tut.hpp>
