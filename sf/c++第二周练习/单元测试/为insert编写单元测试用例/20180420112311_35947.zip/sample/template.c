static int s_buf[1024];
static arr_t s_arr;

UT_SUITE(arr)

UT_SETUP()
{
    memset(s_buf, 0, sizeof(s_buf));
    s_arr.vals = s_buf;
    s_arr.capacity = 1024;
    s_arr.cnt = 0;
}

UT_CASE(case1)
{
}

UT_CASE(case2)
{
}

//TODO: add UT_CASE(xxx)

UT_TEARDOWN()
{
}
