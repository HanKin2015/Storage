
UT_SUITE(range_substr)

UT_CASE(case1)
{
    const char *str = "hello world";
    UT_ASSERT(NULL == range_substr(str, str + 5, "wo"));
}

//TODO: UT_CASE(case2)...
