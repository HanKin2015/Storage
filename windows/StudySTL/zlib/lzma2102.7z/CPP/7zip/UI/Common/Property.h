// Property.h

#ifndef __7Z_PROPERTY_H
#define __7Z_PROPERTY_H

#include "../../../Common/MyString.h"

struct CProperty
{
  UString Name;
  UString Value;
};

#endif
