/*****************************************************************
 *              Stack functions header v1.4                      *
 *                                                               *
 * 2005 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *                                                               *
 *                                                               *
 *Linear functions:                                              *
 * stack_elementL, push_frontL, pop_frontL, push_backL,          *
 * stack_sizeL, stack_clearL                                     *
 *                                                               *
 *Bilinear functions:                                            *
 * stack_element, stack_insert, stack_delete, stack_delete_range,*
 * stack_exchange, stack_move, stack_move_range, stack_size,     *
 * stack_clear, stack_reverse_range, push_sort, stack_sort       *
 *                                                               *
 *                                                               *
 *Usage:                                                         *
 * //for printf                                                  *
 *#include <stdio.h>                                             *
 *                                                               *
 * //insert only push_frontL function                            *
 *#define push_frontL                                            *
 *                                                               *
 * //insert all linear functions                                 *
 *#define stack_allL                                             *
 *                                                               *
 * //insert all bilinear functions                               *
 *#define stack_all                                              *
 *                                                               *
 *#include "StackFunc.h"                                         *
 *                                                               *
 * //stack initialization                                        *
 *stack_bilin *element=NULL, *first=NULL, *top=NULL;             *
 *                                                               *
 *void main()                                                    *
 *{                                                              *
 *  char szResult[MAX_STRLEN]="";                                *
 *  int nError;                                                  *
 *                                                               *
 *  stack_insert(&element, 1, &first, &top);                     *
 *  lstrcpy(element->string, "some string");                     *
 *                                                               *
 *  if (!(nError=stack_element(&element, 1, &first, &top)))      *
 *  {                                                            *
 *    lstrcpy(szResult, element->string);                        *
 *    stack_delete(element, &first, &top);                       *
 *  }                                                            *
 *  printf("szResult={%s} (%d)\n", szResult, nError);            *
 *}                                                              *
 *****************************************************************/

#ifndef _STACKFUNC_
#define _STACKFUNC_ 


#include <windows.h>

/* Maximum string lenght */
#ifndef MAX_STRLEN
	#define MAX_STRLEN 1024
#endif


/********************************************************************
 ********************************************************************
 **                                                                **
 **           Linear chain functions (MAX_STRLEN + 4)              **
 **                                                                **
 ********************************************************************
 ********************************************************************/

#ifndef stack_lin_structure
	#if defined stack_allL || defined stack_elementL || defined push_frontL ||\
		defined pop_frontL || defined push_backL || defined stack_sizeL ||\
		defined stack_clearL

	typedef struct _stack_lin {
		struct _stack_lin *prev;
		char string[MAX_STRLEN];
	} stack_lin;
	#endif
#endif

/********************************************************************
 *
 *  stack_elementL
 *
 *Finds the element by index and returns pointer on it.
 *
 *[out] stack_bilin **elementL  -pointer to a pointer to the element
 *[in]  int index               -number of the element if positive search
 *                               from top if negative from beginning
 *
 *[in,out] stack_lin **firstL   -Pointer to a pointer that specifies
 *                               the first element in the stack
 *[in,out] stack_lin **topL     -Pointer to a pointer that specifies
 *                               the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 ********************************************************************/
#if defined stack_elementL || defined stack_allL
#define stack_elementL_INCLUDED
#undef stack_elementL
int stack_elementL(stack_lin **elementL, int index, stack_lin **firstL, stack_lin **topL)
{
	stack_lin *pTmpL=*topL;
	int sum;
	*elementL=NULL;

	for (sum=1; (pTmpL); ++sum)
	{
		if (sum == index)
		{
			*elementL=pTmpL;
			return 0;
		}
		pTmpL=pTmpL->prev;
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  push_frontL
 *
 *Adds an element to the top of the stack.
 *
 *[out] stack_bilin **elementL  -pointer to a pointer to the element
 *
 *[in,out] stack_lin **firstL   -Pointer to a pointer that specifies
 *                               the first element in the stack
 *[in,out] stack_lin **topL     -Pointer to a pointer that specifies
 *                               the last element in the stack
 ********************************************************************/
#if defined push_frontL || defined stack_allL
#define push_frontL_INCLUDED
#undef push_frontL
void push_frontL(stack_lin **elementL, stack_lin **firstL, stack_lin **topL)
{
	*elementL=(stack_lin*)GlobalAlloc(GPTR, sizeof(stack_lin));

	if (*topL)
		(*elementL)->prev=*topL;
	else
		*firstL=*elementL;
	*topL=*elementL;
}
#endif

/********************************************************************
 *
 *  pop_frontL
 *
 *Removes the element from the top of the stack and
 * puts it in the buffer.
 *
 *[in,out] stack_lin **firstL   -Pointer to a pointer that specifies
 *                               the first element in the stack
 *[in,out] stack_lin **topL     -Pointer to a pointer that specifies
 *                               the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 ********************************************************************/
#if defined pop_frontL || defined stack_allL
#define pop_frontL_INCLUDED
#undef pop_frontL
int pop_frontL(stack_lin **firstL, stack_lin **topL)
{
	stack_lin *pTmpL=*topL;

	if (!*topL) return 1;
	*topL=pTmpL->prev;
	if (!*topL) *firstL=NULL;
	GlobalFree((HGLOBAL)pTmpL);
	return 0;
}
#endif

/********************************************************************
 *
 *  push_backL
 *
 *Adds an element to the beginning of the stack.
 *
 *[out] stack_bilin **elementL  -pointer to a pointer to the element
 *
 *[in,out] stack_lin **firstL   -Pointer to a pointer that specifies
 *                               the first element in the stack
 *[in,out] stack_lin **topL     -Pointer to a pointer that specifies
 *                               the last element in the stack
 ********************************************************************/
#if defined push_backL || defined stack_allL
#define push_backL_INCLUDED
#undef push_backL
void push_backL(stack_lin **elementL, stack_lin **firstL, stack_lin **topL)
{
	*elementL=(stack_lin*)GlobalAlloc(GPTR, sizeof(stack_lin));

	if (*firstL)
		(*firstL)->prev=*elementL;
	else
		*topL=*elementL;
	*firstL=*elementL;
}
#endif

/********************************************************************
 *
 *  stack_sizeL
 *
 *Gets the number of elements in the stack.                         
 *
 *[in,out] stack_lin **firstL   -Pointer to a pointer that specifies
 *                               the first element in the stack
 *[in,out] stack_lin **topL     -Pointer to a pointer that specifies
 *                               the last element in the stack
 *
 *Returns: the number of elements
 ********************************************************************/
#if defined stack_sizeL || defined stack_allL
#define stack_sizeL_INCLUDED
#undef stack_sizeL
int stack_sizeL(stack_lin **firstL, stack_lin **topL)
{
	stack_lin *pTmpL=*topL;
	int sum;

	for (sum=0; (pTmpL); ++sum)
		pTmpL=pTmpL->prev;
	return sum;
}
#endif

/********************************************************************
 *
 *  stack_clearL
 *
 *Clear all stack.
 *
 *[in,out] stack_lin **firstL   -Pointer to a pointer that specifies
 *                               the first element in the stack
 *[in,out] stack_lin **topL     -Pointer to a pointer that specifies
 *                               the last element in the stack
 ********************************************************************/
#if defined stack_clearL || defined stack_allL
#define stack_clearL_INCLUDED
#undef stack_clearL
void stack_clearL(stack_lin **firstL, stack_lin **topL)
{
	stack_lin *pTmpL=*topL;
	stack_lin *pTmpL2;

	while (pTmpL)
	{
		pTmpL2=pTmpL->prev;
		GlobalFree((HGLOBAL)pTmpL);
		pTmpL=pTmpL2;
	}

	*topL=NULL;
	*firstL=NULL;
}
#endif


/********************************************************************
 ********************************************************************
 **                                                                **
 **          Bilinear chain functions (MAX_STRLEN + 8)             **
 **                                                                **
 ********************************************************************
 ********************************************************************/


#ifndef stack_bilin_structure
	#if defined stack_all || defined stack_element || defined stack_insert ||\
		defined stack_delete || defined stack_delete_range || defined stack_exchange ||\
		defined stack_move || defined stack_move_range || defined stack_size ||\
		defined stack_clear || defined stack_reverse_range || defined push_sort ||\
		defined stack_sort

	typedef struct _stack_bilin {
		struct _stack_bilin *next;
		struct _stack_bilin *prev;
		char string[MAX_STRLEN];
	} stack_bilin;
	#endif
#endif


/********************************************************************
 *
 *  stack_element
 *
 *Finds the element by index and returns pointer on it.
 *
 *[out] stack_bilin **element    -pointer to a pointer to the element
 *[in]  int index                -number of the element if positive search
 *                                from top if negative from beginning
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on wrong index
 ********************************************************************/
#if defined stack_element || defined stack_sort || defined stack_all
#define stack_element_INCLUDED
#undef stack_element
int stack_element(stack_bilin **element, int index, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	int sum;
	*element=NULL;

	if (index > 0)
	{
		pTmp=*top;
		sum=1;
	}
	else if (index < 0)
	{
		pTmp=*first;
		sum=-1;
	}
	else return 1;

	while (pTmp)
	{
		if (sum == index)
		{
			*element=pTmp;
			return 0;
		}
		if (index > 0)
		{
			pTmp=pTmp->prev;
			++sum;
		}
		else
		{
			pTmp=pTmp->next;
			--sum;
		}
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  stack_insert
 *
 *Finds the element by index and
 * inserts new element in it index.
 *
 *[out] stack_bilin **element    -pointer to a pointer to the element
 *[in]  int index                -number of the element if positive search
 *                                from top if negative from beginning
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on wrong index
 ********************************************************************/
#if defined stack_insert || defined push_sort || defined stack_all
#define stack_insert_INCLUDED
#undef stack_insert
int stack_insert(stack_bilin **element, int index, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	int sum;
	*element=NULL;

	if (index > 0)
	{
		pTmp=*top;
		sum=1;
	}
	else if (index < 0)
	{
		pTmp=*first;
		sum=-1;
	}
	else return 1;

	while ((pTmp) || (sum == index))
	{
		if (sum == index)
		{
			*element=(stack_bilin*)GlobalAlloc(GPTR, sizeof(stack_bilin));

			if (!pTmp)
			{
				if (index > 0)
				{
					if (*first)
					{
						(*first)->prev=*element;
						(*element)->next=*first;
					}
					else
						*top=*element;
					*first=*element;
				}
				else
				{
					if (*top)
					{
						(*top)->next=*element;
						(*element)->prev=*top;
					}
					else
						*first=*element;
					*top=*element;
				}
			}
			else if (index > 0)
			{
				if (pTmp == *top) *top=*element;
				else pTmp->next->prev=*element;

				(*element)->prev=pTmp;
				(*element)->next=pTmp->next;
				pTmp->next=*element;
			}
			else
			{
				if (pTmp == *first) *first=*element;
				else pTmp->prev->next=*element;

				(*element)->next=pTmp;
				(*element)->prev=pTmp->prev;
				pTmp->prev=*element;
			}
			return 0;
		}
		if (index > 0)
		{
			pTmp=pTmp->prev;
			++sum;
		}
		else
		{
			pTmp=pTmp->next;
			--sum;
		}
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  stack_delete
 *
 * Removes element.
 *
 *[in] stack_bilin *element      -pointer to the element
 *[in] int index                 -number of the element if positive search
 *                                from top if negative from beginning
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 ********************************************************************/
#if defined stack_delete || defined stack_all
#define stack_delete_INCLUDED
#undef stack_delete
int stack_delete(stack_bilin *element, stack_bilin **first, stack_bilin **top)
{
	if (!element) return 1;

	if (element == *first)
	{
		*first=element->next;
		if (*first) (*first)->prev=NULL;
		else *top=NULL;
	}
	else if (element == *top)
	{
		*top=element->prev;
		if (*top) (*top)->next=NULL;
		else *first=NULL;
	}
	else
	{
		element->prev->next=element->next;
		element->next->prev=element->prev;
	}
	GlobalFree((HGLOBAL)element);
	return 0;
}
#endif

/********************************************************************
 *
 *  stack_delete_range
 *
 *Finds the elements between indexes and removes.
 *
 *[in]  int index   -number of the element if positive search
 *                   from top if negative from beginning (range limit)
 *[in]  int index2  -number of the element if positive search
 *                   from top if negative from beginning (range limit)
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 ********************************************************************/
#if defined stack_delete_range || defined stack_all
#define stack_delete_range_INCLUDED
#undef stack_delete_range
int stack_delete_range(int index, int index2, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	stack_bilin *pTmp2=NULL;
	stack_bilin *pTmp3;
	stack_bilin *pTmp4;
	int sum;
	BOOL bMeet=FALSE;
	BOOL bExit=FALSE;

	loop:

	if (index > 0)
	{
		pTmp=*top;
		sum=1;
	}
	else if (index < 0)
	{
		pTmp=*first;
		sum=-1;
	}
	else return 1;

	while (pTmp)
	{
		if (pTmp == pTmp2) bMeet=TRUE;

		if (sum == index)
		{
			if (!pTmp2)
			{
				pTmp2=pTmp;
				index=index2;
				goto loop;
			}
			if ((bMeet == FALSE && index < 0) || (bMeet == TRUE && index > 0))
			{
				pTmp3=pTmp;
				pTmp4=pTmp2;
				pTmp=pTmp4;
				pTmp2=pTmp3;
			}

			if ((pTmp2 == *first) && (pTmp == *top))
			{
				*first=NULL;
				*top=NULL;
			}
			else if (pTmp2 == *first)
			{
				*first=pTmp->next;
				(*first)->prev=NULL;
			}
			else if (pTmp == *top)
			{
				*top=pTmp2->prev;
				(*top)->next=NULL;
			}
			else
			{
				pTmp2->prev->next=pTmp->next;
				pTmp->next->prev=pTmp2->prev;
			}

			for (; bExit != TRUE; pTmp=pTmp3)
			{
				if (pTmp2 == pTmp) bExit=TRUE;
				else pTmp3=pTmp->prev;
				GlobalFree((HGLOBAL)pTmp);
			}
			return 0;
		}
		if (index > 0)
		{
			pTmp=pTmp->prev;
			++sum;
		}
		else
		{
			pTmp=pTmp->next;
			--sum;
		}
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  stack_exchange
 *
 *Finds the elements by indexes and exchanges them.
 *
 *[in]  int index   -number of the element if positive search
 *                   from top if negative from beginning
 *[in]  int index2  -number of the element if positive search
 *                   from top if negative from beginning
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 *         2 indexes pointed to the same element
 ********************************************************************/
#if defined stack_exchange || defined stack_reverse_range || defined stack_all
#define stack_exchange_INCLUDED
#undef stack_exchange
int stack_exchange(int index, int index2, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	stack_bilin *pTmp2=NULL;
	stack_bilin *pTmp3;
	stack_bilin *pTmp4;
	struct _stack_bilin *pTmpNext;
	struct _stack_bilin *pTmpPrev;
	int sum;
	BOOL bMeet=FALSE;

	loop:

	if (index > 0)
	{
		pTmp=*top;
		sum=1;
	}
	else if (index < 0)
	{
		pTmp=*first;
		sum=-1;
	}
	else return 1;

	while (pTmp)
	{
		if (pTmp == pTmp2) bMeet=TRUE;

		if (sum == index)
		{
			if (!pTmp2)
			{
				pTmp2=pTmp;
				index=index2;
				goto loop;
			}
			if (pTmp2 == pTmp) return 2;

			if ((bMeet == FALSE && index < 0) || (bMeet == TRUE && index > 0))
			{
				pTmp3=pTmp;
				pTmp4=pTmp2;
				pTmp=pTmp4;
				pTmp2=pTmp3;
			}
			pTmpNext=pTmp2->next;
			pTmpPrev=pTmp2->prev;

			if (pTmp2 == *first) *first=pTmp;
			else pTmp2->prev->next=pTmp;

			if (pTmp == *top) *top=pTmp2;
			else pTmp->next->prev=pTmp2;

			if (pTmp2->next == pTmp)
			{
				pTmp2->next=pTmp->next;
				pTmp2->prev=pTmp;
				pTmp->next=pTmp2;
				pTmp->prev=pTmpPrev;
			}
			else
			{
				pTmp2->next->prev=pTmp;
				pTmp->prev->next=pTmp2;

				pTmp2->next=pTmp->next;
				pTmp2->prev=pTmp->prev;
				pTmp->next=pTmpNext;
				pTmp->prev=pTmpPrev;
			}
			return 0;
		}
		if (index > 0)
		{
			pTmp=pTmp->prev;
			++sum;
		}
		else
		{
			pTmp=pTmp->next;
			--sum;
		}
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  stack_move
 *
 *Finds the element by index and move it to the new index.
 *
 *[in]  int index   -number of the element if positive search
 *                   from top if negative from beginning (source)
 *[in]  int index2  -number of the element if positive search
 *                   from top if negative from beginning (destination)
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 *         2 source and destination indexes pointed to the same element
 ********************************************************************/
#if defined stack_move || defined stack_sort || defined stack_all
#define stack_move_INCLUDED
#undef stack_move
int stack_move(int index, int index2, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	stack_bilin *pTmp2=NULL;
	int sum;
	BOOL bMeet=FALSE;

	loop:

	if (index > 0)
	{
		pTmp=*top;
		sum=1;
	}
	else if (index < 0)
	{
		pTmp=*first;
		sum=-1;
	}
	else return 1;

	while (pTmp)
	{
		if (pTmp == pTmp2) bMeet=TRUE;

		if (sum == index)
		{
			if (!pTmp2)
			{
				pTmp2=pTmp;
				index=index2;
				goto loop;
			}
			if (pTmp2 == pTmp) return 2;

			if (pTmp2 == *first)
			{
				*first=pTmp2->next;
				pTmp2->next->prev=NULL;
			}
			else if (pTmp2 == *top)
			{
				*top=pTmp2->prev;
				pTmp2->prev->next=NULL;
			}
			else
			{
				pTmp2->next->prev=pTmp2->prev;
				pTmp2->prev->next=pTmp2->next;
			}

			if ((bMeet == FALSE && index < 0) || (bMeet == TRUE && index > 0))
			{
				if (pTmp == *first) *first=pTmp2;
				else pTmp->prev->next=pTmp2;

				pTmp2->next=pTmp;
				pTmp2->prev=pTmp->prev;
				pTmp->prev=pTmp2;
			}
			else
			{
				if (pTmp == *top) *top=pTmp2;
				else pTmp->next->prev=pTmp2;

				pTmp2->prev=pTmp;
				pTmp2->next=pTmp->next;
				pTmp->next=pTmp2;
			}
			return 0;
		}
		if (index > 0)
		{
			pTmp=pTmp->prev;
			++sum;
		}
		else
		{
			pTmp=pTmp->next;
			--sum;
		}
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  stack_move_range
 *
 *Finds the element by index and move it to the new index.
 *
 *[in]  int index   -number of the element if positive search
 *                   from top if negative from beginning (range limit)
 *[in]  int index2  -number of the element if positive search
 *                   from top if negative from beginning (range limit)
 *[in]  int index3  -number of the element if positive search
 *                   from top if negative from beginning (destination)
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 *         2 destination index pointed to the element in the range
 ********************************************************************/
#if defined stack_move_range || defined stack_all
#define stack_move_range_INCLUDED
#undef stack_move_range
int stack_move_range(int index, int index2, int index3, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	stack_bilin *pTmp2=NULL;
	stack_bilin *pTmp3=NULL;
	stack_bilin *pTmp4;
	stack_bilin *pTmp5;
	int sum;
	int nMeet=0;
	BOOL bMeet=FALSE;

	loop:

	if (index > 0)
	{
		pTmp=*top;
		sum=1;
	}
	else if (index < 0)
	{
		pTmp=*first;
		sum=-1;
	}
	else return 1;

	while (pTmp)
	{
		if (pTmp3)
		{
			if (pTmp == pTmp2) ++nMeet;
			if (pTmp == pTmp3) ++nMeet;
			else if (nMeet == 2) nMeet=3;
		}
		else if (pTmp == pTmp2) bMeet=TRUE;

		if (sum == index)
		{
			if (!pTmp2)
			{
				pTmp2=pTmp;
				index=index2;
				goto loop;
			}
			if (!pTmp3)
			{
				pTmp3=pTmp;
				index=index3;
				goto loop;
			}

			if (nMeet == 1 || nMeet == 2) return 2;

			if ((bMeet == FALSE && index2 < 0) || (bMeet == TRUE && index2 > 0))
			{
				pTmp4=pTmp2;
				pTmp5=pTmp3;
				pTmp2=pTmp5;
				pTmp3=pTmp4;
			}

			if (pTmp2 == *first && pTmp3 == *top) return 2;

			if (pTmp2 == *first)
			{
				*first=pTmp3->next;
				pTmp3->next->prev=NULL;
			}
			else if (pTmp3 == *top)
			{
				*top=pTmp2->prev;
				pTmp2->prev->next=NULL;
			}
			else
			{
				pTmp3->next->prev=pTmp2->prev;
				pTmp2->prev->next=pTmp3->next;
			}

			if ((nMeet == 0 && index < 0) || (nMeet == 3 && index > 0))
			{
				if (pTmp == *first) *first=pTmp2;
				else pTmp->prev->next=pTmp2;

				pTmp3->next=pTmp;
				pTmp2->prev=pTmp->prev;
				pTmp->prev=pTmp3;
			}
			else
			{
				if (pTmp == *top) *top=pTmp3;
				else pTmp->next->prev=pTmp3;

				pTmp2->prev=pTmp;
				pTmp3->next=pTmp->next;
				pTmp->next=pTmp2;
			}
			return 0;
		}
		if (index > 0)
		{
			pTmp=pTmp->prev;
			++sum;
		}
		else
		{
			pTmp=pTmp->next;
			--sum;
		}
	}
	return 1;
}
#endif

/********************************************************************
 *
 *  stack_size
 *
 *Gets the number of elements in the stack.                         
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: the number of elements
 ********************************************************************/
#if defined stack_size || defined stack_reverse_range || defined stack_all
#define stack_size_INCLUDED
#undef stack_size
int stack_size(stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp=*top;
	int sum;

	for (sum=0; (pTmp); ++sum)
		pTmp=pTmp->prev;
	return sum;
}
#endif

/********************************************************************
 *
 *  stack_clear
 *
 *Clear all stack.
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 ********************************************************************/
#if defined stack_clear || defined stack_all
#define stack_clear_INCLUDED
#undef stack_clear
void stack_clear(stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp=*top;
	stack_bilin *pTmp2;

	while (pTmp)
	{
		pTmp2=pTmp->prev;
		GlobalFree((HGLOBAL)pTmp);
		pTmp=pTmp2;
	}

	*top=NULL;
	*first=NULL;
}
#endif

/********************************************************************
 *
 *  stack_reverse_range
 *
 *Reverse range of elements.
 *
 *[in]  int index   -number of the element if positive search
 *                   from top if negative from beginning (range limit)
 *[in]  int index2  -number of the element if positive search
 *                   from top if negative from beginning (range limit)
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Returns: 0 on success
 *         1 on empty stack
 *         2 indexes pointed to the same element
 *Note:
 *  stack_reverse_range uses stack_exchange, stack_size
 ********************************************************************/
#if (defined stack_reverse_range && defined stack_exchange_INCLUDED && defined stack_size_INCLUDED) || defined stack_all
#define stack_reverse_range_INCLUDED
#undef stack_reverse_range
int stack_reverse_range(int index, int index2, stack_bilin **first, stack_bilin **top)
{
	int a,b;

	if (index < 0 && index2 > 0)
		index=stack_size(first, top) + index + 1;
	if (index > 0 && index2 < 0)
		index2=stack_size(first, top) + index2 + 1;

	if (index == index2) return 2;

	if (index > index2)
	{
		a=index;
		b=index2;
		index=b;
		index2=a;
	}
	for (a=0; index < index2 && a == 0; ++index, --index2)
		a=stack_exchange(index, index2, first, top);
	return a;
}
#endif

/********************************************************************
 *
 *  push_sort
 *
 *Push element to the stack and sorts alphabetically in ascending or descending.
 *
 *[out] stack_bilin **element    -pointer to a pointer to the element
 *[in]  char *str                -string
 *[in]  int nUpDown              -sorts in "1"-ascending, "-1"-descending
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Note:
 *  Required "char string[]" in the structure
 *  push_sort uses stack_insert
 ********************************************************************/

#if (defined push_sort && defined stack_insert_INCLUDED) || defined stack_all
#define push_sort_INCLUDED
#undef push_sort
void push_sort(stack_bilin **element, char *str, int nUpDown, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp=*top;
	int a,b;

	if (nUpDown != 1 && nUpDown != -1) return;

	for (a=1; (pTmp); ++a, pTmp=pTmp->prev)
	{
		b=lstrcmp(pTmp->string, str);
		if (b == 0 || b == nUpDown) break;
	}
	stack_insert(element, a, first, top);
	lstrcpy((*element)->string, str);
}
#endif

/********************************************************************
 *
 *  stack_sort
 *
 *Sorts the stack alphabetically in ascending or descending.
 *
 *[in] int nUpDown   -sorts in "1"-ascending, "-1"-descending
 *
 *[in,out] stack_bilin **first   -Pointer to a pointer that specifies
 *                                the first element in the stack
 *[in,out] stack_bilin **top     -Pointer to a pointer that specifies
 *                                the last element in the stack
 *
 *Note:
 *  Required "char string[]" in the structure
 *  stack_sort uses stack_move, stack_element
 ********************************************************************/

#if (defined stack_sort && defined stack_move_INCLUDED && defined stack_element_INCLUDED) || defined stack_all
#define stack_sort_INCLUDED
#undef stack_sort
void stack_sort(int nUpDown, stack_bilin **first, stack_bilin **top)
{
	stack_bilin *pTmp;
	stack_bilin *pTmp2;
	int a,b,c;

	if (nUpDown != 1 && nUpDown != -1) return;

	for (a=2; !stack_element(&pTmp, a, first, top); ++a)
		for (b=1; b < a && !stack_element(&pTmp2, b, first, top); ++b)
		{
			c=lstrcmp(pTmp2->string, pTmp->string);
			if (c == 0 || c == nUpDown)
			{
				stack_move(a, b, first, top);
				break;
			}
		}
}
#endif

#undef stack_elementL
#undef push_frontL
#undef pop_frontL
#undef push_backL
#undef stack_sizeL
#undef stack_clearL
#undef stack_element
#undef stack_insert
#undef stack_delete
#undef stack_delete_range
#undef stack_exchange
#undef stack_move
#undef stack_move_range
#undef stack_size
#undef stack_clear
#undef stack_reverse_range
#undef push_sort
#undef stack_sort

#endif //_STACKFUNC_
