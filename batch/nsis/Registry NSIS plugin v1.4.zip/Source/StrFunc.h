/*****************************************************************
 *              String functions header v1.3                     *
 *                                                               *
 * 2005 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *                                                               *
 *                                                               *
 *Functions:                                                     *
 * WordFind, StrReplace, GetOptions                              *
 *                                                               *
 *Usage:                                                         *
 *#define WordFind                                               *
 *#define StrReplace                                             *
 *#define StrReplace_INSENSITIVE                                 *
 *#define GetOptions                                             *
 *#include "StrFunc.h"                                           *
 *****************************************************************/

#ifndef _STRFUNC_
#define _STRFUNC_ 


/********************************************************************
 *
 *  WordFind
 *
 *String manipulation function.
 *
 *[out] char *pResult   -output
 *[in]  char *pText     -text
 *[in]  char *pDelim    -delimiter
 *[in]  int nNumber     -number of the delimiter/word if positive
 *                       search from beginning if negative from end,
 *                       if nNumber==0 then returns sum of delimiters/words
 *[in]  char pOption    -">"     all text before founded delimiter
 *                       "<"     all text after founded delimiter
 *                       "<>"    deletes delimiter
 *                       "*"     text between delimiters (word)
 *                       "*>"    all text after founded word
 *                       ">*"    word and all text after founded word
 *                       "<*"    all text before founded word
 *                       "*<"    word and all text before founded word
 *                       "<*>"   deletes word and neighbouring delimiter
 *                       "/word" finds "word" and returns it number
 *                               if nNumber<0 then nRes=(0 - nRes)
 *
 *Returns (nRes):  sum of delimiters/words if nNumber==0
 *                 0  no errors
 *                 -1 syntax error or pDelim is empty
 *                 -2 no delimiters found
 *                 -3 no such delimiter/word number
 *
 *Defines:
 * #define WordFind                 //insert WordFind function
 * #define WordFind_INSENSITIVE     //comparisons is not case sensitive (required: msvcrt.lib)
 * #define WordFind_UNMINUS         //nNumber only positive (uses for minimize program size)
 * #define WordFind_UNPLUS          //nNumber only negative (uses for minimize program size)
 *
 *Examples:
 *  WordFind(szRes, "A||B||C", "||", 1, ">");       //szRes == B||C
 *  WordFind(szRes, "A||B||C", "||", 1, "<");       //szRes == A
 *  WordFind(szRes, "A||B||C", "||", 2, "<");       //szRes == A||B
 *  WordFind(szRes, "A||B||C", "||", -1, "<");      //szRes == A||B
 *  WordFind(szRes, "A||B||C", "||", -2, "<>");     //szRes == AB||C
 *  WordFind(szRes, "A||B||C", "||", 1, "*");       //szRes == A
 *  WordFind(szRes, "A||B||C", "||", 2, "*");       //szRes == B
 *  WordFind(szRes, "A||B||C", "||", -1, "*");      //szRes == C
 *  WordFind(szRes, "A||B||C", "||", 2, "*>");      //szRes == ||C
 *  WordFind(szRes, "A||B||C", "||", 2, ">*");      //szRes == B||C
 *  WordFind(szRes, "A||B||C", "||", 2, "<*");      //szRes == A||
 *  WordFind(szRes, "A||B||C", "||", 2, "*<");      //szRes == A||B
 *  WordFind(szRes, "A||B||C", "||", 2, "<*>");     //szRes == A||C
 *  nRes=WordFind(szRes, "A||B||C", "||", 0, ">");  //nRes == 2
 *  nRes=WordFind(szRes, "A||B||C", "||", 0, "*");  //nRes == 3
 *  nRes=WordFind(szRes, "A||B||C", "||", 1, "/B"); //nRes == 2
 ********************************************************************/
#ifdef WordFind
#undef WordFind
int WordFind(char *pResult, char *pText, char *pDelim, int nNumber, char *pOption)
{
	char *pDelim2=pDelim;
	char *pText2=pText;
	char *pText3=pText;
	BOOL bFound=FALSE;
	BOOL bRow=TRUE;
	int nOption=0;
	int nCurStrNumber=0;
	int nCurWordNumber=0;
	int nCurWordNumberOp10=0;
	int nDelimLen=lstrlen(pDelim);

	if (!lstrcmp(pOption,  ">")) nOption=1;
	else if (!lstrcmp(pOption,  "<")) nOption=2;
	else if (!lstrcmp(pOption,  "<>")) nOption=3;
	else if (!lstrcmp(pOption,  "*")) nOption=4;
	else if (!lstrcmp(pOption,  "*>")) nOption=5;
	else if (!lstrcmp(pOption,  ">*")) nOption=6;
	else if (!lstrcmp(pOption,  "<*")) nOption=7;
	else if (!lstrcmp(pOption,  "*<")) nOption=8;
	else if (!lstrcmp(pOption,  "<*>")) nOption=9;
	else if (pOption[0] == '/')
	{
		nOption=10;
		++pOption;
	}

	if (nDelimLen == 0 || nOption == 0)
	{
		lstrcpy(pResult, pText);
		return -1;
	}

	#ifndef WordFind_UNPLUS
	if (nNumber >= 0)
	{
		while (*pText2)
		{
			#ifdef WordFind_INSENSITIVE
			for (pDelim2=pDelim; (*pText2) && (tolower(*pText2) == tolower(*pDelim2)); ++pText2)
			#else
			for (pDelim2=pDelim; (*pText2) && (*pText2 == *pDelim2); ++pText2)
			#endif
				if (!*++pDelim2)
				{
					if (nOption > 3)
					{
						if (bRow == FALSE && (++nCurWordNumber == nNumber || nOption == 10))
						{
							if (nOption == 4 || nOption == 10)
								lstrcpyn(pResult, pText3, pText2 - pText3 - nDelimLen + 2);
							else if (nOption == 5)
								lstrcpy(pResult, pText2 - nDelimLen + 1);
							else if (nOption == 6)
								lstrcpy(pResult, pText3);
							else if (nOption == 7)
								lstrcpyn(pResult, pText, pText3 - pText + 1);
							else if (nOption == 8)
								lstrcpyn(pResult, pText, pText2 - pText - nDelimLen + 2);
							else if (nOption == 9)
							{
								lstrcpyn(pResult, pText, pText3 - pText + 1);
								lstrcat(pResult, pText2 + 1);
							}
							if (nOption != 10)
								return 0;

							#ifdef WordFind_INSENSITIVE
							if (!lstrcmpi(pResult, pOption) && ++nCurWordNumberOp10 == nNumber)
								return nCurWordNumber;
							#else
							if (!lstrcmp(pResult, pOption) && ++nCurWordNumberOp10 == nNumber)
								return nCurWordNumber;
							#endif
						}
						pText3=pText2 + 1;
						bRow=TRUE;
					}
					else if (++nCurStrNumber == nNumber)
					{
						if (nOption == 1)
							lstrcpy(pResult, pText2 + 1);
						else if (nOption == 2)
							lstrcpyn(pResult, pText, pText2 - pText - nDelimLen + 2);
						else
						{
							lstrcpyn(pResult, pText, pText2 - pText - nDelimLen + 2);
							lstrcat(pResult, pText2 + 1);
						}
						return 0;
					}
					pDelim2=pDelim;
					bFound=TRUE;
				}
			if (*pText2++) bRow=FALSE;
		}
		if (nOption > 3 && bRow == FALSE && (++nCurWordNumber == nNumber || nOption == 10))
		{
			if (nOption == 4 || nOption == 6 || nOption == 10)
				lstrcpy(pResult, pText3);
			else if (nOption == 5)
				pResult[0]='\0';
			else if (nOption == 7)
				lstrcpyn(pResult, pText, pText3 - pText + 1);
			else if (nOption == 8)
				lstrcpy(pResult, pText);
			else if (nOption == 9)
				lstrcpyn(pResult, pText, pText3 - pText - nDelimLen + 1);
			if (nOption != 10)
				return 0;
								
			#ifdef WordFind_INSENSITIVE
			if (!lstrcmpi(pResult, pOption) && ++nCurWordNumberOp10 == nNumber)
				return nCurWordNumber;
			#else
			if (!lstrcmp(pResult, pOption) && ++nCurWordNumberOp10 == nNumber)
				return nCurWordNumber;
			#endif
		}
		if (nNumber == 0)
		{
			lstrcpy(pResult, pText);
			if (nOption <= 3)
				return nCurStrNumber;
			if (nOption >= 4 && nOption <= 9)
				return nCurWordNumber;
			return nCurWordNumberOp10;
		}
	}
	#endif

	#ifndef WordFind_UNMINUS
	else if (nNumber < 0)
	{
		pText2+=lstrlen(pText) - 1;
		pText3=pText2 + 2;
		pDelim+=nDelimLen - 1;

		while (*pText2)
		{
			#ifdef WordFind_INSENSITIVE
			for (pDelim2=pDelim; (*pText2) && (tolower(*pText2) == tolower(*pDelim2)); --pText2)
			#else
			for (pDelim2=pDelim; (*pText2) && (*pText2 == *pDelim2); --pText2)
			#endif
				if (!*--pDelim2)
				{
					if (nOption > 3)
					{
						if (bRow == FALSE && (--nCurWordNumber == nNumber || nOption == 10))
						{
							if (nOption == 4 || nOption == 10)
								lstrcpyn(pResult, pText2 + nDelimLen, pText3 - pText2 - nDelimLen);
							else if (nOption == 5)
								lstrcpy(pResult, pText3 - 1);
							else if (nOption == 6)
								lstrcpy(pResult, pText2 + nDelimLen);
							else if (nOption == 7)
								lstrcpyn(pResult, pText, pText2 - pText + nDelimLen + 1);
							else if (nOption == 8)
								lstrcpyn(pResult, pText, pText3 - pText);
							else if (nOption == 9)
							{
								lstrcpyn(pResult, pText, pText2 - pText + 1);
								lstrcat(pResult, pText3 - 1);
							}
							if (nOption != 10)
								return 0;

							#ifdef WordFind_INSENSITIVE
							if (!lstrcmpi(pResult, pOption) && --nCurWordNumberOp10 == nNumber)
								return (0 - nCurWordNumber);
							#else
							if (!lstrcmp(pResult, pOption) && --nCurWordNumberOp10 == nNumber)
								return (0 - nCurWordNumber);
							#endif
						}
						pText3=pText2 + 1;
						bRow=TRUE;
					}
					else if (--nCurStrNumber == nNumber)
					{
						if (nOption == 1)
							lstrcpy(pResult, pText2 + nDelimLen);
						else if (nOption == 2)
							lstrcpyn(pResult, pText, pText2 - pText + 1);
						else
						{
							lstrcpyn(pResult, pText, pText2 - pText + 1);
							lstrcat(pResult, pText2 + nDelimLen);
						}
						return 0;
					}
					pDelim2=pDelim;
					bFound=TRUE;
				}
			if (*pText2--) bRow=FALSE;
		}
		if (nOption > 3 && bRow == FALSE && (--nCurWordNumber == nNumber || nOption == 10))
		{
			if (nOption == 4 || nOption == 8 || nOption == 10)
				lstrcpyn(pResult, pText, pText3 - pText);
			else if (nOption == 5)
				lstrcpy(pResult, pText3 - 1);
			else if (nOption == 6)
				lstrcpy(pResult, pText);
			else if (nOption == 7)
				pResult[0]='\0';
			else if (nOption == 9)
				lstrcpy(pResult, pText3 + nDelimLen - 1);
			if (nOption != 10)
				return 0;

			#ifdef WordFind_INSENSITIVE
			if (!lstrcmpi(pResult, pOption) && --nCurWordNumberOp10 == nNumber)
				return  (0 - nCurWordNumber);
			#else
			if (!lstrcmp(pResult, pOption) && --nCurWordNumberOp10 == nNumber)
				return  (0 - nCurWordNumber);
			#endif
		}
	}
	#endif

	lstrcpy(pResult, pText);
	if (bFound == TRUE)
		return -3;
	else
		return -2;
}
#endif

/********************************************************************
 *
 *  StrReplace
 *
 *Replace substring in string.
 *
 *[out] char *pResult    -output (if errors pText copy to pResult)
 *[in]  char *pText      -text
 *[in]  char *pIt        -replace it
 *[in]  char *pWith      -replace with
 *
 *Returns:  0 no errors
 *          1 no substrings found
 *
 *Defines:
 * #define StrReplace                 //insert StrReplace function
 * #define StrReplace_INSENSITIVE     //comparisons is not case sensitive (required: msvcrt.lib)
 *
 *Examples:
 *  StrReplace(szRes, "123||456||789||", "||", "+");    //szRes == 123+456+789+
 *  StrReplace(szRes, "123||456||789||", "||", "");     //szRes == 123456789
 ********************************************************************/
#ifdef StrReplace
#undef StrReplace
int StrReplace(char *pResult, char *pText, char *pIt, char *pWith)
{
	char *pText2=pText;
	char *pIt2=pIt;
	char *pResult2=pResult;
	int nItLen=lstrlen(pIt);
	int nWithLen=lstrlen(pWith);
	BOOL bFound=FALSE;
	int i=0;

	while (*pText2)
		#ifdef StrReplace_INSENSITIVE
		for (pIt2=pIt, pText2+=i, i=1; (tolower(*pText2) == tolower(*pIt2)) && (*pText2); ++pText2)
		#else
		for (pIt2=pIt, pText2+=i, i=1; (*pText2 == *pIt2) && (*pText2); ++pText2)
		#endif
			if (!*++pIt2)
			{
				lstrcpyn(pResult2, pText, pText2 - pText - nItLen + 2);
				lstrcat(pResult2, pWith);
				pResult2+=(pText2 - pText - nItLen + nWithLen + 1);
				pText=pText2 + 1;
				pIt2=pIt;
				bFound=TRUE;
			}
	if (bFound == FALSE)
	{
		lstrcpy(pResult, pText);
		return 1;
	}
	else
	{
		lstrcat(pResult, pText);
		return 0;
	}
}
#endif

/********************************************************************
 *
 *  GetOptions
 *
 *Gets option string from parameters line.
 *
 *[out] char *string  -option string
 *[in]  char *line    -parameters line
 *[in]  char *option  -option
 *
 *Returns: 0 if option found, 1 if not found
 *
 *Defines:
 * #define GetOptions                 //insert GetOptions function
 * #define GetOptions_INSENSITIVE     //comparisons is not case sensitive (required: msvcrt.lib)
 *
 *Examples:
 *  GetOptions(szRes, "/a1=bb /a2=cc /a3=dd", "/a1=");       //szRes == bb
 *  GetOptions(szRes, "/a1=bb /a2=\"cc\" /a3=dd", "/a2=");   //szRes == cc
 *  GetOptions(szRes, "/a1=bb /a2=cc /a3=\"/dd\"", "/a3=");  //szRes == /dd
 *  GetOptions(szRes, "/a1 /a2 /a3", "/a2");                 //Returns: 0
 *  GetOptions(szRes, "/a1 /a2 /a3", "/a4");                 //Returns: 1
 ********************************************************************/
#ifdef GetOptions
#undef GetOptions
int GetOptions(char *string, char *line, char *option)
{
	char chDelimiter='\0';
	char chQuote='\0';
	char *pTmp=NULL;
	int s=0;
	int nStart=0;
	int nTmp=0;

	chDelimiter=option[0];
	++option;

	for (; (line[s]); ++s)
	{
		if ((chQuote == '\0') && (line[s] != '\"') && (line[s] != '\'') && (line[s] != '`'))
		{
			if (line[s] == chDelimiter)
			{
				if (nStart)
				{
					end:
					while (line[--s] == ' ');

					#ifdef GetOptions_INSENSITIVE
					if ((tolower(line[nStart]) == tolower(line[s])) &&
						((line[s] == '\"') || (line[s] == '\'') || (line[s] == '`')))
					#else
					if ((line[nStart] == line[s]) &&
						((line[s] == '\"') || (line[s] == '\'') || (line[s] == '`')))
					#endif
						++nStart, --s;

					for (; nStart <= s; ++nStart, ++nTmp)
						string[nTmp]=line[nStart];

					string[nTmp]='\0';
					return 0;
				}
				#ifdef GetOptions_INSENSITIVE
				for (pTmp=option, ++s; (line[s]) && (*pTmp) && (tolower(*pTmp) == tolower(line[s])); ++s, ++pTmp);
				#else
				for (pTmp=option, ++s; (line[s]) && (*pTmp) && (*pTmp == line[s]); ++s, ++pTmp);
				#endif

				if ((!line[s]) && (!*pTmp))
				{
					string[0]='\0';
					return 0;
				}
				else if (!line[s])
				{
					string[0]='\0';
					return 1;
				}
				else if (!*pTmp)
					nStart=s--;
			}
		}
		else if (chQuote == '\0')
			chQuote=line[s];
		else if (line[s] == chQuote)
			chQuote='\0';
	}
	if (nStart) goto end;

	string[0]='\0';
	return 1;
}
#endif

#endif //_STRFUNC_