/*****************************************************************
 *                Registry NSIS plugin v1.4                      *
 *                                                               *
 * 2005 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *****************************************************************/


/* Comment-out and recompile */
#define REGISTRY_SEARCH   //Compile with search function
#define REGISTRY_READ     //Compile with read function
#define REGISTRY_WRITE    //Compile with write function
#define REGISTRY_CREATE   //Compile with create function
#define REGISTRY_DELETE   //Compile with delete functions
#define REGISTRY_BACKUP   //Compile with export/import functions
#define REGISTRY_CONVERT  //Compile with convertion functions




#include <windows.h>

/* Maximum string lenght (default: 1024) */
#define MAX_STRLEN 1024
#define MAX_DATALEN 65536

/* Include conversion functions */
#if defined REGISTRY_WRITE || defined REGISTRY_CONVERT || defined REGISTRY_SEARCH || defined REGISTRY_READ
	#if defined REGISTRY_WRITE
		#define xatoi
	#endif
	#if defined REGISTRY_CONVERT
		#define hex2str
	#endif
	#if defined REGISTRY_CONVERT || defined REGISTRY_SEARCH || defined REGISTRY_READ
		#define str2hex
	#endif
	#include "ConvFunc.h"
#endif

/* Include string functions */
#if defined REGISTRY_SEARCH || defined REGISTRY_BACKUP
	#define GetOptions
	#include "StrFunc.h"
#endif

/* Include private stack functions */
#if defined REGISTRY_SEARCH || defined REGISTRY_BACKUP
	#if defined REGISTRY_SEARCH || defined REGISTRY_BACKUP
		#define stack_clear
		#define stack_insert
		#define stack_delete
	#endif
	#include "StackFunc.h"

	stack_bilin *pStackElement=NULL, *pStackFirst=NULL, *pStackTop=NULL;
#endif

/* NSIS stack structure */
typedef struct _stack_t {
	struct _stack_t *next;
	char text[MAX_STRLEN];
} stack_t;

stack_t **g_stacktop;

/* Defines */
#ifndef REG_QWORD
	#define REG_QWORD 11
#endif
#define IDC_STATIC  1006
#define ALL_TYPES   -1

/* Global variables */
char szBuf[MAX_DATALEN]="";
char szBuf2[MAX_DATALEN]="";
char szError[4]="";
char szName[MAX_STRLEN]="";
char szKey[MAX_STRLEN]="";
char *pSubKey=&szKey[0];
char *pKey=NULL;
char *pValue=NULL;
unsigned char *pString;
HKEY hKey=0;
HKEY hKeyHandle=0;
#ifdef REGISTRY_SEARCH
	char szNameF[MAX_STRLEN]="";
	char szKeyF[MAX_STRLEN]="";
	char *pSubKeyF=&szKeyF[0];
	char *pKeyF=NULL;
	char *pValueF=NULL;
	unsigned char *pStringF;
	HKEY hKeyF=0;
	HKEY hKeyHandleF=0;
	HANDLE hSearchDetailsF=0;
	BOOL bAllNamesF=TRUE;
	BOOL bFindKeysF=TRUE;
	BOOL bFindValuesF=TRUE;
	BOOL bFindStringsF=TRUE;
	BOOL bGotoSubkeysF=TRUE;
	int nBannerF=0;
	int nFindTypeF=ALL_TYPES;
	int nGotoF=0;
	int nElementF=1;
	DWORD dwIndexF;
#endif

/* NSIS variables */
enum
{
INST_0,         // $0
INST_1,         // $1
INST_2,         // $2
INST_3,         // $3
INST_4,         // $4
INST_5,         // $5
INST_6,         // $6
INST_7,         // $7
INST_8,         // $8
INST_9,         // $9
INST_R0,        // $R0
INST_R1,        // $R1
INST_R2,        // $R2
INST_R3,        // $R3
INST_R4,        // $R4
INST_R5,        // $R5
INST_R6,        // $R6
INST_R7,        // $R7
INST_R8,        // $R8
INST_R9,        // $R9
INST_CMDLINE,   // $CMDLINE
INST_INSTDIR,   // $INSTDIR
INST_OUTDIR,    // $OUTDIR
INST_EXEDIR,    // $EXEDIR
INST_LANG,      // $LANGUAGE
__INST_LAST
};

/* Funtions prototypes and macros */
int popstring(char *str);
int getvarindex(char *var);
int TypeNameToTypeValue(char *name);
void RegReadPath(HKEY *hKey, char **pSubKey);
void RegReadType(char *szString, char *szType, DWORD dwType, unsigned char *pString, DWORD dwSizeString);
void RegWriteType(HANDLE hFileWrite, char *szValueName, DWORD dwType, unsigned char *pString, DWORD dwSizeString);
void ReplaceEscapeSequence(char *pResult, char *pText);
LONG myRegDeleteKeyEx(HKEY thiskey, LPCTSTR lpSubKey, int onlyifempty);
BOOL FileExists(char *fname);
void HexStrToHexData(char *pHexStr, unsigned char *pHexData, int *nHexLen);
#define setvar(varnum, var, g_stringsize, g_variables) {\
	if (var != NULL && varnum >= 0 && varnum < __INST_LAST)\
		lstrcpy(g_variables + varnum*g_stringsize, var);}
#define SWAP_ENDIAN(x) (((x<<24)&0xFF000000)|((x<<8)&0xFF0000)|((x>>8)&0xFF00)|((x>>24)&0xFF))


/* NSIS functions code */
#ifdef REGISTRY_SEARCH
void __declspec(dllexport) Open(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nKey=1;
	int nVarError;
	hKeyF=0;

	popstring(szKeyF);
	popstring(szBuf);
	popstring(szError);
	nVarError=getvarindex(szError);

	RegReadPath(&hKeyF, &pSubKeyF);

	CharUpper(szBuf);
	if (!GetOptions(szNameF, szBuf, "/N="))
		bAllNamesF=FALSE;
	if (!GetOptions(szBuf2, szBuf, "/K=") && (*szBuf2 == '0'))
		bFindKeysF=FALSE;
	if (!GetOptions(szBuf2, szBuf, "/V=") && (*szBuf2 == '0'))
		bFindValuesF=FALSE;
	if (!GetOptions(szBuf2, szBuf, "/S=") && (*szBuf2 == '0'))
		bFindStringsF=FALSE;
	if (!GetOptions(szBuf2, szBuf, "/G=") && (*szBuf2 == '0'))
		bGotoSubkeysF=FALSE;
	if (!GetOptions(szBuf2, szBuf, "/B="))
		if (*szBuf2 == '1')
		{
			nBannerF=1;
			hSearchDetailsF=GetDlgItem(FindWindowEx(hwndParent, NULL, "#32770", NULL), IDC_STATIC);
		}
		else if (*szBuf2 == '2')
			nBannerF=2;
	if (!GetOptions(szBuf2, szBuf, "/T="))
		nFindTypeF=TypeNameToTypeValue(szBuf2);
	if ((hKeyF == 0) || ((bFindKeysF == FALSE) && (bFindValuesF == FALSE) && (bFindStringsF == FALSE)) ||
	    (RegOpenKeyEx(hKeyF, pSubKeyF, 0, KEY_READ, &hKeyHandleF) != ERROR_SUCCESS))
	{
		setvar(nVarError, "-1", string_size, variables);
	}
	else
	{
		RegCloseKey(hKeyHandleF);
		setvar(nVarError, "0", string_size, variables);
		nGotoF=1;
	}
  }
}

void __declspec(dllexport) Find(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVar1, nVar2, nVar3, nVar4;
	DWORD dwSizeKey;
	DWORD dwSizeValue;
	DWORD dwSizeString;
	DWORD dwType;

	popstring(szError);
	nVar1=getvarindex(szError);
	popstring(szError);
	nVar2=getvarindex(szError);
	popstring(szError);
	nVar3=getvarindex(szError);
	popstring(szError);
	nVar4=getvarindex(szError);

	if (nGotoF == 4) goto EnumKey;
	else if (nGotoF == 3) goto EnumValue;
	else if (nGotoF == 2) goto OpenKey;
	else if (nGotoF != 1) goto End;

	pKeyF=(char *)GlobalAlloc(GPTR, MAX_STRLEN+1);
	pValueF=(char *)GlobalAlloc(GPTR, MAX_STRLEN+1);
	pStringF=(unsigned char *)GlobalAlloc(GPTR, MAX_DATALEN+1);

	stack_insert(&pStackElement, -1, &pStackFirst, &pStackTop);
	lstrcpy(pStackElement->string, pSubKeyF);

	while (nElementF != 0)
	{
		--nElementF;
		lstrcpy(pSubKeyF, pStackTop->string);
		stack_delete(pStackTop, &pStackFirst, &pStackTop);

		if (nBannerF == 1) SendMessage(hSearchDetailsF, WM_SETTEXT, 0, (LPARAM)pSubKeyF);
		else if (nBannerF == 2)
		{
			setvar(nVar1, pSubKeyF, string_size, variables);
			setvar(nVar2, "", string_size, variables);
			setvar(nVar3, "", string_size, variables);
			setvar(nVar4, "BANNER", string_size, variables);

			nGotoF=2;
			return;
		}

		OpenKey:
		if (RegOpenKeyEx(hKeyF, pSubKeyF, 0, KEY_READ, &hKeyHandleF) != ERROR_SUCCESS) continue;

		dwIndexF=-1;
		if ((bFindValuesF == FALSE) && (bFindStringsF == FALSE)) goto EnumKey;

		EnumValue:
		++dwIndexF;
		dwSizeValue=MAX_STRLEN;
		dwSizeString=MAX_DATALEN;
		pStringF[0]='\0';

		if (RegEnumValue(hKeyHandleF, dwIndexF, pValueF, &dwSizeValue, NULL, &dwType, pStringF, &dwSizeString) == ERROR_SUCCESS)
		{
			if (((bFindValuesF == TRUE) && (bAllNamesF == TRUE || !lstrcmpi(pValueF, szNameF)) && ((nFindTypeF == ALL_TYPES) || (nFindTypeF == (int)dwType))) ||
				((bFindStringsF == TRUE) && (bAllNamesF == TRUE || ((dwType == REG_SZ || dwType == REG_EXPAND_SZ) && !lstrcmpi(pStringF, szNameF))) && ((nFindTypeF == ALL_TYPES) || (nFindTypeF == (int)dwType))))
			{
				RegReadType(szBuf, szBuf2, dwType, pStringF, dwSizeString);
				setvar(nVar1, pSubKeyF, string_size, variables);
				setvar(nVar2, pValueF, string_size, variables);
				setvar(nVar3, szBuf, string_size, variables);
				setvar(nVar4, szBuf2, string_size, variables);

				nGotoF=3;
				return;
			}
			else
				goto EnumValue;
		}

		dwIndexF=-1;

		EnumKey:
		if (bGotoSubkeysF != FALSE)
		{
			++dwIndexF;
			dwSizeKey=MAX_STRLEN;

			if (RegEnumKeyEx(hKeyHandleF, dwIndexF, pKeyF, &dwSizeKey, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
			{
				lstrcpy(szBuf, pSubKeyF);
				if (*pSubKeyF) lstrcat(szBuf, "\\");
				lstrcat(szBuf, pKeyF);

				//stack_insert(&pStackElement, dwIndexF + 1, &pStackFirst, &pStackTop);
				//lstrcpy(pStackElement->string, szBuf);
				stack_insert(&pStackElement, -1, &pStackFirst, &pStackTop);
				lstrcpy(pStackElement->string, szBuf);

				++nElementF;

				if ((bFindKeysF == TRUE) && (bAllNamesF == TRUE || !lstrcmpi(pKeyF, szNameF)))
				{
					setvar(nVar1, pSubKeyF, string_size, variables);
					setvar(nVar2, pKeyF, string_size, variables);
					setvar(nVar3, "", string_size, variables);
					setvar(nVar4, "REG_KEY", string_size, variables);

					nGotoF=4;
					return;
				}
				else
					goto EnumKey;
			}
		}
		RegCloseKey(hKeyHandleF);
	}

	GlobalFree(pKeyF);
	GlobalFree(pValueF);
	GlobalFree(pStringF);
	nGotoF=0;

	End:
	setvar(nVar1, "", string_size, variables);
	setvar(nVar2, "", string_size, variables);
	setvar(nVar3, "", string_size, variables);
	setvar(nVar4, "", string_size, variables);
  }
}

void __declspec(dllexport) Close(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  {
	if (hKeyHandleF) RegCloseKey(hKeyHandleF);
	if (nBannerF == 1) SendMessage(hSearchDetailsF, WM_SETTEXT, 0, (LPARAM)"");
	stack_clear(&pStackFirst, &pStackTop);
	if (nGotoF != 0)
	{
		if (pKeyF) GlobalFree(pKeyF);
		if (pValueF) GlobalFree(pValueF);
		if (pStringF) GlobalFree(pStringF);
	}
	nGotoF=0;
  }
}	
#endif //REGISTRY_SEARCH

#ifdef REGISTRY_READ
void __declspec(dllexport) Read(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVar1, nVar2, nVar3, nVar4;
	DWORD dwSizeString=MAX_DATALEN;
	DWORD dwType;
	int nError;
	pSubKey=&szKey[0];

	popstring(szKey);
	popstring(szName);
	popstring(szError);
	nVar1=getvarindex(szError);
	popstring(szError);
	nVar2=getvarindex(szError);
	popstring(szError);
	nVar3=getvarindex(szError);
	popstring(szError);
	nVar4=getvarindex(szError);

	RegReadPath(&hKey, &pSubKey);

	if (RegOpenKeyEx(hKey, pSubKey, 0, KEY_READ, &hKeyHandle) == ERROR_SUCCESS)
	{
		pString=(unsigned char *)GlobalAlloc(GPTR, MAX_DATALEN+1);
		pString[0]='\0';

		nError=RegQueryValueEx(hKeyHandle, szName, NULL, &dwType, pString, &dwSizeString);
		if (nError == ERROR_SUCCESS)
		{
			RegReadType(szBuf, szBuf2, dwType, pString, dwSizeString);
			setvar(nVar1, pSubKey, string_size, variables);
			setvar(nVar2, szName, string_size, variables);
			setvar(nVar3, szBuf, string_size, variables);
			setvar(nVar4, szBuf2, string_size, variables);
		}
		RegCloseKey(hKeyHandle);
		GlobalFree(pString);

		if (nError == ERROR_SUCCESS) return;
	}
	setvar(nVar1, "", string_size, variables);
	setvar(nVar2, "", string_size, variables);
	setvar(nVar3, "", string_size, variables);
	setvar(nVar4, "", string_size, variables);
  }
}
#endif //REGISTRY_READ

#ifdef REGISTRY_WRITE
void __declspec(dllexport) Write(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	char *pBuf;
	DWORD dwValue;
	DWORD dwSizeString=MAX_STRLEN;
	DWORD dwType;
	int nVarError;
	int nError;
	pSubKey=&szKey[0];

	popstring(szKey);
	popstring(szName);
	popstring(szBuf);
	popstring(szBuf2);
	popstring(szError);
	nVarError=getvarindex(szError);

	RegReadPath(&hKey, &pSubKey);

	if ((dwType=TypeNameToTypeValue(szBuf2)) != -1 && RegOpenKeyEx(hKey, pSubKey, 0, KEY_SET_VALUE, &hKeyHandle) == ERROR_SUCCESS)
	{
		if (dwType == REG_BINARY ||\
			dwType == REG_NONE ||\
			dwType == REG_LINK ||\
			dwType == REG_RESOURCE_LIST ||\
			dwType == REG_FULL_RESOURCE_DESCRIPTOR ||\
			dwType == REG_RESOURCE_REQUIREMENTS_LIST ||\
			dwType == REG_QWORD)
		{
			HexStrToHexData(szBuf, (unsigned char *)szBuf2, &dwSizeString);
			nError=RegSetValueEx(hKeyHandle, szName, 0, dwType, (unsigned char *)szBuf2, dwSizeString);
		}
		else if (dwType == REG_DWORD ||\
			dwType == REG_DWORD_BIG_ENDIAN)
		{
			if (dwType == REG_DWORD) dwValue=xatoi(szBuf);
			else dwValue=SWAP_ENDIAN(xatoi(szBuf));
			nError=RegSetValueEx(hKeyHandle, szName, 0, dwType, (unsigned char *) &dwValue, sizeof(DWORD));
		}
		else if (dwType == REG_MULTI_SZ)
		{
			for (pBuf=szBuf; (*pBuf); ++pBuf)
				if (*pBuf == '\n') *pBuf='\0';
			*++pBuf='\0';
			*++pBuf='\0';
			nError=RegSetValueEx(hKeyHandle, szName, 0, REG_MULTI_SZ, szBuf, (pBuf - szBuf));
		}
		else if (dwType == REG_EXPAND_SZ ||\
			dwType == REG_SZ)
			nError=RegSetValueEx(hKeyHandle, szName, 0, dwType, szBuf, lstrlen(szBuf) + 1);

		RegCloseKey(hKeyHandle);

		if (nError == ERROR_SUCCESS)
		{
			setvar(nVarError, "0", string_size, variables);
			return;
		}
	}
	setvar(nVarError, "-1", string_size, variables);
  }
}
#endif //REGISTRY_WRITE

#ifdef REGISTRY_CREATE
void __declspec(dllexport) CreateKey(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVarError;
	int nError, nError2;
	HKEY hKeyHandle2;
	pSubKey=&szKey[0];

	popstring(szKey);
	popstring(szName);
	popstring(szError);
	nVarError=getvarindex(szError);

	RegReadPath(&hKey, &pSubKey);

	if (RegOpenKeyEx(hKey, pSubKey, 0, KEY_CREATE_SUB_KEY, &hKeyHandle) == ERROR_SUCCESS)
	{
		nError=RegCreateKeyEx(hKeyHandle, szName, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKeyHandle2, &nError2);

		RegCloseKey(hKeyHandle);
		RegCloseKey(hKeyHandle2);

		if (nError == ERROR_SUCCESS)
		{
			if (nError2 == REG_CREATED_NEW_KEY)
			{
				setvar(nVarError, "0", string_size, variables);
			}
			else
			{
				setvar(nVarError, "1", string_size, variables);
			}
			return;
		}
	}
	setvar(nVarError, "-1", string_size, variables);
  }
}
#endif //REGISTRY_CREATE

#ifdef REGISTRY_DELETE
void __declspec(dllexport) DeleteValue(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVarError;
	int nError;
	pSubKey=&szKey[0];

	popstring(szKey);
	popstring(szName);
	popstring(szError);
	nVarError=getvarindex(szError);

	RegReadPath(&hKey, &pSubKey);

	if (RegOpenKeyEx(hKey, pSubKey, 0, KEY_SET_VALUE, &hKeyHandle) == ERROR_SUCCESS)
	{
		nError=RegDeleteValue(hKeyHandle, szName);

		RegCloseKey(hKeyHandle);

		if (nError == ERROR_SUCCESS)
		{
			setvar(nVarError, "0", string_size, variables);
			return;
		}
	}
	setvar(nVarError, "-1", string_size, variables);
  }
}

void __declspec(dllexport) DeleteKey(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	char *pKeyName;
	int nVarError;
	int nError;
	pSubKey=&szKey[0];

	popstring(szKey);
	popstring(szError);
	nVarError=getvarindex(szError);

	RegReadPath(&hKey, &pSubKey);

	if (!*pSubKey) goto error;

	for (pKeyName=pSubKey + lstrlen(pSubKey) - 1; (*pKeyName != '\\') && (*pKeyName); --pKeyName);

	if (!*pKeyName) goto error;

	*pKeyName++='\0';

	if (RegOpenKeyEx(hKey, pSubKey, 0, KEY_ENUMERATE_SUB_KEYS, &hKeyHandle) == ERROR_SUCCESS)
	{
		nError=RegDeleteKey(hKeyHandle, pKeyName);

		if (nError != ERROR_SUCCESS)
			nError=myRegDeleteKeyEx(hKeyHandle, pKeyName, 0);

		RegCloseKey(hKeyHandle);

		if (nError == ERROR_SUCCESS)
		{
			setvar(nVarError, "0", string_size, variables);
			return;
		}
	}

	error:
	setvar(nVarError, "-1", string_size, variables);
  }
}
#endif //REGISTRY_DELETE

#ifdef REGISTRY_BACKUP
void __declspec(dllexport) SaveKey(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	DWORD dwSizeKey;
	DWORD dwSizeValue;
	DWORD dwSizeString;
	DWORD dwType;
	DWORD dwIndex;
	DWORD dwNumberOfBytesWritten;
	int nVarError;
	int nReplaceSubkeys=0;
	int nElement=1;
	BOOL bGotoSubkeys=TRUE;
	HANDLE hSearchDetails=0;
	HANDLE hFileWrite=0;
	pSubKey=&szKey[0];

	popstring(szKey);
	popstring(szName);
	popstring(szBuf);
	popstring(szError);
	nVarError=getvarindex(szError);

	RegReadPath(&hKey, &pSubKey);

	CharUpper(szBuf);
	if (!GetOptions(szError, szBuf, "/G="))
		if (*szError == '0') bGotoSubkeys=FALSE;
	if (!GetOptions(szError, szBuf, "/B="))
		if (*szError == '1') hSearchDetails=GetDlgItem(FindWindowEx(hwndParent, NULL, "#32770", NULL), IDC_STATIC);
	if (!GetOptions(szError, szBuf, "/D="))
		if (*szError == '1') nReplaceSubkeys=1;
		else if (*szError == '2') nReplaceSubkeys=2;

	if (RegOpenKeyEx(hKey, pSubKey, 0, KEY_READ, &hKeyHandle) != ERROR_SUCCESS)
	{
		setvar(nVarError, "-1", string_size, variables);
		return;
	}
	RegCloseKey(hKeyHandle);

	hFileWrite=CreateFile(szName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if (hFileWrite == INVALID_HANDLE_VALUE)
	{
		setvar(nVarError, "-1", string_size, variables);
		return;
	}
	WriteFile(hFileWrite, "REGEDIT4\r\n", lstrlen("REGEDIT4\r\n"), &dwNumberOfBytesWritten, NULL);

	pKey=(char *)GlobalAlloc(GPTR, MAX_STRLEN+1);
	pValue=(char *)GlobalAlloc(GPTR, MAX_STRLEN+1);
	pString=(unsigned char *)GlobalAlloc(GPTR, MAX_DATALEN+1);
	stack_insert(&pStackElement, 1, &pStackFirst, &pStackTop);
	lstrcpy(pStackElement->string, pSubKey);

	while (nElement != 0)
	{
		--nElement;
		lstrcpy(pSubKey, pStackTop->string);
		stack_delete(pStackTop, &pStackFirst, &pStackTop);

		if (hSearchDetails != 0) SendMessage(hSearchDetails, WM_SETTEXT, 0, (LPARAM)pSubKey);

		if (RegOpenKeyEx(hKey, pSubKey, 0, KEY_READ, &hKeyHandle) != ERROR_SUCCESS) continue;

		if (!*pSubKey)
			wsprintf(szBuf, "\r\n[%s]\r\n", szKey);
		else
		{
			if (nReplaceSubkeys == 1 || nReplaceSubkeys == 2)
			{
				if (nReplaceSubkeys == 1) nReplaceSubkeys=0;
				wsprintf(szBuf, "\r\n[-%s\\%s]", szKey, pSubKey);
				WriteFile(hFileWrite, szBuf, lstrlen(szBuf), &dwNumberOfBytesWritten, NULL);
			}
			wsprintf(szBuf, "\r\n[%s\\%s]\r\n", szKey, pSubKey);
		}

		WriteFile(hFileWrite, szBuf, lstrlen(szBuf), &dwNumberOfBytesWritten, NULL);

		dwIndex=0;
		while (1)
		{
			dwSizeValue=MAX_STRLEN;
			dwSizeString=MAX_DATALEN;
			pString[0]='\0';
			if (RegEnumValue(hKeyHandle, dwIndex++, pValue, &dwSizeValue, NULL, &dwType, pString, &dwSizeString) != ERROR_SUCCESS)
				break;
			RegWriteType(hFileWrite, pValue, dwType, pString, dwSizeString);
		}

		if (bGotoSubkeys != FALSE)
		{
			dwIndex=0;
			while (1)
			{
				dwSizeKey=MAX_STRLEN;
				if (RegEnumKeyEx(hKeyHandle, dwIndex++, pKey, &dwSizeKey, NULL, NULL, NULL, NULL) != ERROR_SUCCESS)
					break;

				lstrcpy(szBuf, pSubKey);
				if (*pSubKey) lstrcat(szBuf, "\\");
				lstrcat(szBuf, pKey);

				stack_insert(&pStackElement, dwIndex, &pStackFirst, &pStackTop);
				lstrcpy(pStackElement->string, szBuf);

				++nElement;
			}
		}
		RegCloseKey(hKeyHandle);
	}
	CloseHandle(hFileWrite);
	GlobalFree(pKey);
	GlobalFree(pValue);
	GlobalFree(pString);
	stack_clear(&pStackFirst, &pStackTop);
	if (hSearchDetails != 0) SendMessage(hSearchDetails, WM_SETTEXT, 0, (LPARAM)"");
	setvar(nVarError, "0", string_size, variables);
  }
}

void __declspec(dllexport) RestoreKey(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVarError;
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	popstring(szName);
	popstring(szError);
	nVarError=getvarindex(szError);

	if (FileExists(szName) == 0) goto Error;
	GetShortPathName(szName, szBuf2, sizeof(szBuf2));
	SearchPath(NULL, "regedit.exe", NULL, sizeof(szName), szName, 0);

	lstrcpy(szBuf, szName);
	lstrcat(szBuf, " /s ");
	lstrcat(szBuf, szBuf2);

	GetStartupInfo(&si);

	if (CreateProcess(NULL, szBuf, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
		setvar(nVarError, "0", string_size, variables);
		return;
	}

	Error:
	setvar(nVarError, "-1", string_size, variables);
  }
}
#endif //REGISTRY_BACKUP

#ifdef REGISTRY_CONVERT
void __declspec(dllexport) StrToHex(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVarError;

	popstring(szBuf);
	popstring(szError);
	nVarError=getvarindex(szError);

	str2hex((unsigned char *)szBuf, szBuf2, TRUE, lstrlen(szBuf));

	setvar(nVarError, szBuf2, string_size, variables);
  }
}

void __declspec(dllexport) HexToStr(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_stacktop=stacktop;
  {
	int nVarError;

	popstring(szBuf);
	popstring(szError);
	nVarError=getvarindex(szError);

	hex2str(szBuf, szBuf2);

	setvar(nVarError, szBuf2, string_size, variables);
  }
}
#endif //REGISTRY_CONVERT

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

#if defined REGISTRY_SEARCH || defined REGISTRY_READ || defined REGISTRY_WRITE ||\
	defined REGISTRY_CREATE || defined REGISTRY_DELETE || defined REGISTRY_BACKUP
// Function: "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft" -> HKEY_LOCAL_MACHINE "SOFTWARE\Microsoft"
void RegReadPath(HKEY *hKey, char **pSubKey)
{
	int nKey=1;
	char *pKey=*pSubKey + lstrlen(*pSubKey);
	char *pKeyRoot=*pSubKey;

	while (*--pKey == '\\') *pKey='\0';

	for (pKey=*pSubKey; (pKey[nKey] != '\\') && (pKey[nKey] != '\0'); ++nKey);

	if (pKey[nKey] == '\\')
		pKey[nKey]='\0';
	*pSubKey=&pKey[nKey+1];

	if (!lstrcmpi(pKeyRoot, "HKEY_CLASSES_ROOT") || !lstrcmpi(pKeyRoot, "HKCR"))
		*hKey=HKEY_CLASSES_ROOT;
	else if (!lstrcmpi(pKeyRoot, "HKEY_CURRENT_USER") || !lstrcmpi(pKeyRoot, "HKCU"))
		*hKey=HKEY_CURRENT_USER;
	else if (!lstrcmpi(pKeyRoot, "HKEY_LOCAL_MACHINE") || !lstrcmpi(pKeyRoot, "HKLM"))
		*hKey=HKEY_LOCAL_MACHINE;
	else if (!lstrcmpi(pKeyRoot, "HKEY_USERS") || !lstrcmpi(pKeyRoot, "HKU"))
		*hKey=HKEY_USERS;
	else if (!lstrcmpi(pKeyRoot, "HKEY_PERFORMANCE_DATA") || !lstrcmpi(pKeyRoot, "HKPD"))
		*hKey=HKEY_PERFORMANCE_DATA;
	else if (!lstrcmpi(pKeyRoot, "HKEY_CURRENT_CONFIG") || !lstrcmpi(pKeyRoot, "HKCC"))
		*hKey=HKEY_CURRENT_CONFIG;
	else if (!lstrcmpi(pKeyRoot, "HKEY_DYN_DATA") || !lstrcmpi(pKeyRoot, "HKDD"))
		*hKey=HKEY_DYN_DATA;
	else
		*hKey=0;
}
#endif //REGISTRY_SEARCH || REGISTRY_READ || REGISTRY_WRITE || REGISTRY_CREATE || REGISTRY_DELETE || REGISTRY_BACKUP

#if defined REGISTRY_SEARCH || defined REGISTRY_WRITE
int TypeNameToTypeValue(char *name)
{
	if (!lstrcmp(name, "REG_BINARY")) return REG_BINARY;
	else if (!lstrcmp(name, "REG_DWORD")) return REG_DWORD;
	else if (!lstrcmp(name, "REG_DWORD_BIG_ENDIAN")) return REG_DWORD_BIG_ENDIAN;
	else if (!lstrcmp(name, "REG_EXPAND_SZ")) return REG_EXPAND_SZ;
	else if (!lstrcmp(name, "REG_MULTI_SZ")) return REG_MULTI_SZ;
	else if (!lstrcmp(name, "REG_NONE")) return REG_NONE;
	else if (!lstrcmp(name, "REG_SZ")) return REG_SZ;
	else if (!lstrcmp(name, "REG_LINK")) return REG_LINK;
	else if (!lstrcmp(name, "REG_RESOURCE_LIST")) return REG_RESOURCE_LIST;
	else if (!lstrcmp(name, "REG_FULL_RESOURCE_DESCRIPTOR")) return REG_FULL_RESOURCE_DESCRIPTOR;
	else if (!lstrcmp(name, "REG_RESOURCE_REQUIREMENTS_LIST")) return REG_RESOURCE_REQUIREMENTS_LIST;
	else if (!lstrcmp(name, "REG_QWORD")) return REG_QWORD;
	else return -1;
}
#endif //REGISTRY_SEARCH || REGISTRY_WRITE

#if defined REGISTRY_SEARCH || defined REGISTRY_READ
// Function: Converts registry data to string
void RegReadType(char *szString, char *szType, DWORD dwType, unsigned char *pString, DWORD dwSizeString)
{
	char *pStr;
	unsigned int i=0;
	szString[0]='\0';

	if (dwType == REG_BINARY ||\
		dwType == REG_NONE ||\
		dwType == REG_LINK ||\
		dwType == REG_RESOURCE_REQUIREMENTS_LIST ||\
		dwType == REG_RESOURCE_LIST ||\
		dwType == REG_FULL_RESOURCE_DESCRIPTOR ||\
		dwType == REG_QWORD)
	{
		str2hex(pString, szString, TRUE, dwSizeString);
		if (dwType == REG_BINARY)                          //Raw binary data
			lstrcpy(szType, "REG_BINARY");
		else if (dwType == REG_NONE)                       //Undefined type
			lstrcpy(szType, "REG_NONE");
		else if (dwType == REG_LINK)                       //Unicode symbolic link
			lstrcpy(szType, "REG_LINK");
		else if (dwType == REG_RESOURCE_REQUIREMENTS_LIST)
			lstrcpy(szType, "REG_RESOURCE_REQUIREMENTS_LIST");
		else if (dwType == REG_RESOURCE_LIST)              //Device-driver resource list
			lstrcpy(szType, "REG_RESOURCE_LIST");
		else if (dwType == REG_FULL_RESOURCE_DESCRIPTOR)   // Resource list in the hardware description
			lstrcpy(szType, "REG_FULL_RESOURCE_DESCRIPTOR");
		else if (dwType == REG_QWORD)                      //64-bit number
			lstrcpy(szType, "REG_QWORD");
	}
	else if (dwType == REG_SZ ||\
		dwType == REG_EXPAND_SZ)
	{
		lstrcpy(szString, (char *)pString);
		if (dwType == REG_SZ)                              //Null-terminated string
			lstrcpy(szType, "REG_SZ");
		else if (dwType == REG_EXPAND_SZ)                  //String with unexpanded environment variables
			lstrcpy(szType, "REG_EXPAND_SZ");
	}
	else if (dwType == REG_MULTI_SZ)                         //Multiple strings ended by two null characters
	{
		for (i=0, pStr=(char *)pString; (*pStr); i++, pStr+=lstrlen(pStr) + 1)
		{
			if (*szString) lstrcat(szString, "\n");
			lstrcat(szString, pStr);
		}
		lstrcpy(szType, "REG_MULTI_SZ");
	}
	else if (dwType == REG_DWORD)                            //Double word in machine format (low-endian on Intel)
	{
		wsprintf(szString, "%d", *((unsigned int *)pString));
		lstrcpy(szType, "REG_DWORD");
	}
	else if (dwType == REG_DWORD_BIG_ENDIAN)                 //Double word in big-endian format
	{
		wsprintf(szString, "%d", SWAP_ENDIAN(*((unsigned int *)pString)));
		lstrcpy(szType, "REG_DWORD_BIG_ENDIAN");
	}
	else                                                     //Invalid type code
		lstrcpy(szType, "INVALID");
}
#endif //REGISTRY_SEARCH || REGISTRY_READ

#ifdef REGISTRY_WRITE
// Function from NSIS code:
// Converts string with binary data to binary data
void HexStrToHexData(char *pHexStr, unsigned char *pHexData, int *nHexLen)
{
	int nLen=0;
	int a,b;
	int c;

	while (*pHexStr)
	{
		a=*pHexStr;
		if (a >= '0' && a <= '9') a-='0';
		else if (a >= 'a' && a <= 'f') a-='a'-10;
		else if (a >= 'A' && a <= 'F') a-='A'-10;
		else break;
		b=*++pHexStr;
		if (b >= '0' && b <= '9') b-='0';
		else if (b >= 'a' && b <= 'f') b-='a'-10;
		else if (b >= 'A' && b <= 'F') b-='A'-10;
		else break;
		pHexStr++;
		c=(a<<4)|b;
		pHexData[nLen++]=c;
	}
	*nHexLen=nLen;
}
#endif //REGISTRY_WRITE

#ifdef REGISTRY_DELETE
// Function from NSIS code:
// based loosely on code from Tim Kosse
// in win9x this isn't necessary (RegDeleteKey() can delete a tree of keys),
// but in win2k you need to do this manually.
LONG myRegDeleteKeyEx(HKEY thiskey, LPCTSTR lpSubKey, int onlyifempty)
{
	HKEY key;
	int retval=RegOpenKeyEx(thiskey,lpSubKey,0,KEY_ENUMERATE_SUB_KEYS,&key);
	if (retval==ERROR_SUCCESS)
	{
		// NB - don't change this to static (recursive function)
		char buffer[MAX_PATH+1];
		while (RegEnumKey(key,0,buffer,MAX_PATH+1)==ERROR_SUCCESS)
		{
			if (onlyifempty)
			{
				RegCloseKey(key);
				return !ERROR_SUCCESS;
			}
			if ((retval=myRegDeleteKeyEx(key,buffer,0)) != ERROR_SUCCESS) break;
		}
		RegCloseKey(key);
		retval=RegDeleteKey(thiskey,lpSubKey);
	}
	return retval;
}
#endif //REGISTRY_DELETE

#ifdef REGISTRY_BACKUP
// Function: Writes registry data to file (REGEDIT4 format)
void RegWriteType(HANDLE hFileWrite, char *szValueName, DWORD dwType, unsigned char *pString, DWORD dwSizeString)
{
	//Global variables:
	//char szBuf[MAX_DATALEN]="";
	//char szBuf2[MAX_DATALEN]="";

	unsigned int i=0;
	int nCurWidth=0;
	int nColumnWidth;
	DWORD dwNumberOfBytesWritten;

	if (!*szValueName)
		lstrcpy(szBuf2, "@");
	else
	{
		ReplaceEscapeSequence(szBuf, szValueName);
		wsprintf(szBuf2, "\"%s\"", szBuf);
	}

	if (dwType == REG_BINARY ||\
		dwType == REG_EXPAND_SZ ||\
		dwType == REG_MULTI_SZ ||\
		dwType == REG_DWORD_BIG_ENDIAN ||\
		dwType == REG_NONE ||\
		dwType == REG_LINK ||\
		dwType == REG_RESOURCE_LIST ||\
		dwType == REG_FULL_RESOURCE_DESCRIPTOR ||\
		dwType == REG_RESOURCE_REQUIREMENTS_LIST ||\
		dwType == REG_QWORD)
	{
		if (dwType == REG_BINARY)
			lstrcat(szBuf2, "=hex:");
		else if (dwType == REG_NONE)
			lstrcat(szBuf2, "=hex(0):");
		else if (dwType == REG_EXPAND_SZ)
			lstrcat(szBuf2, "=hex(2):");
		else if (dwType == REG_DWORD_BIG_ENDIAN)
			lstrcat(szBuf2, "=hex(5):");
		else if (dwType == REG_LINK)
			lstrcat(szBuf2, "=hex(6):");
		else if (dwType == REG_MULTI_SZ)
			lstrcat(szBuf2, "=hex(7):");
		else if (dwType == REG_RESOURCE_LIST)
			lstrcat(szBuf2, "=hex(8):");
		else if (dwType == REG_FULL_RESOURCE_DESCRIPTOR)
			lstrcat(szBuf2, "=hex(9):");
		else if (dwType == REG_RESOURCE_REQUIREMENTS_LIST)
			lstrcat(szBuf2, "=hex(a):");
		else if (dwType == REG_QWORD)
			lstrcat(szBuf2, "=hex(b):");

		if (dwSizeString == 0)
		{
			lstrcat(szBuf2, "\r\n");
			WriteFile(hFileWrite, szBuf2, lstrlen(szBuf2), &dwNumberOfBytesWritten, NULL);
			return;
		}

		nColumnWidth=(79 - lstrlen(szBuf2)) / 3;

		if (nColumnWidth <= 0)
			nColumnWidth=1;

		for (; i < dwSizeString; lstrcpy(szBuf2, "  "), nColumnWidth=25)
		{
			for (nCurWidth=0; (i < dwSizeString) && (nCurWidth < nColumnWidth); ++i, ++nCurWidth)
			{
				wsprintf(szName, "%02x,", (unsigned int)pString[i]);
				lstrcat(szBuf2, szName);
			}
			if (i == dwSizeString)
			{
				szBuf2[lstrlen(szBuf2) - 1]='\0';
				lstrcat(szBuf2, "\r\n");
			}
			else lstrcat(szBuf2, "\\\r\n");

			WriteFile(hFileWrite, szBuf2, lstrlen(szBuf2), &dwNumberOfBytesWritten, NULL);
		}
	}
	else if (dwType == REG_SZ)
	{
		ReplaceEscapeSequence(szBuf, pString);
		lstrcpy(pString, szBuf2);
		lstrcat(pString, "=\"");
		lstrcat(pString, szBuf);
		lstrcat(pString, "\"\r\n");
		WriteFile(hFileWrite, pString, lstrlen(pString), &dwNumberOfBytesWritten, NULL);
	}
	else if (dwType == REG_DWORD)
	{
		wsprintf(szBuf, "%s=dword:%08x\r\n", szBuf2, *((unsigned int *)pString));
		WriteFile(hFileWrite, szBuf, lstrlen(szBuf), &dwNumberOfBytesWritten, NULL);
	}
}

// Function: Converts escape sequences (\\ -> \\\\), (\" -> \\\"), (\r -> \\r), (\n -> \\n)
void ReplaceEscapeSequence(char *pResult, char *pText)
{
	int a=0;
	int b=0;

	for (; (pText[a]); ++a, ++b)
		if (pText[a] == '\\')
			pResult[b]='\\', pResult[++b]='\\';
		else if (pText[a] == '\"')
			pResult[b]='\\', pResult[++b]='\"';
		else if (pText[a] == '\r')
			pResult[b]='\\', pResult[++b]='r';
		else if (pText[a] == '\n')
			pResult[b]='\\', pResult[++b]='n';
		else pResult[b]=pText[a];
	pResult[b]='\0';
}

// Function: Checks is file exist
BOOL FileExists(char *fname)
{
	WIN32_FIND_DATA wfd;
	HANDLE hFind=FindFirstFile(fname, &wfd);
	if (INVALID_HANDLE_VALUE != hFind)
	{
		FindClose(hFind);
		return TRUE;
	}
	return FALSE;
}
#endif //REGISTRY_BACKUP

//Function: Removes the element from the top of the NSIS stack and puts it in the buffer.
int popstring(char *str)
{
  stack_t *th;
  if (!g_stacktop || !*g_stacktop) return 1;
  th=(*g_stacktop);
  lstrcpy(str,th->text);
  *g_stacktop = th->next;
  GlobalFree((HGLOBAL)th);
  return 0;
}

// Function: Converts .r0-.r9 and .R0-.R9 to variable index
int getvarindex(char *var)
{
	int nVar=-1;

	if (!lstrcmp(var, ".r0")) nVar=INST_0;
	else if (!lstrcmp(var, ".r1")) nVar=INST_1;
	else if (!lstrcmp(var, ".r2")) nVar=INST_2;
	else if (!lstrcmp(var, ".r3")) nVar=INST_3;
	else if (!lstrcmp(var, ".r4")) nVar=INST_4;
	else if (!lstrcmp(var, ".r5")) nVar=INST_5;
	else if (!lstrcmp(var, ".r6")) nVar=INST_6;
	else if (!lstrcmp(var, ".r7")) nVar=INST_7;
	else if (!lstrcmp(var, ".r8")) nVar=INST_8;
	else if (!lstrcmp(var, ".r9")) nVar=INST_9;
	else if (!lstrcmp(var, ".R0")) nVar=INST_R0;
	else if (!lstrcmp(var, ".R1")) nVar=INST_R1;
	else if (!lstrcmp(var, ".R2")) nVar=INST_R2;
	else if (!lstrcmp(var, ".R3")) nVar=INST_R3;
	else if (!lstrcmp(var, ".R4")) nVar=INST_R4;
	else if (!lstrcmp(var, ".R5")) nVar=INST_R5;
	else if (!lstrcmp(var, ".R6")) nVar=INST_R6;
	else if (!lstrcmp(var, ".R7")) nVar=INST_R7;
	else if (!lstrcmp(var, ".R8")) nVar=INST_R8;
	else if (!lstrcmp(var, ".R9")) nVar=INST_R9;

	return nVar;
}
