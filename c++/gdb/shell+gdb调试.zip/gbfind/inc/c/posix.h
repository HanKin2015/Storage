#ifndef POSIX_H_
#define POSIX_H_

#include <c/common.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

ZBCDLL U32 posix_gettid(void);
ZBCDLL U32 posix_getpid(void);
ZBCDLL void posix_sleep(U32 second);
ZBCDLL void posix_msleep(U32 ms);
ZBCDLL void posix_pause(void);
ZBCDLL int posix_dup(int fd);
ZBCDLL int posix_dup2(int fd, int newfd);
ZBCDLL int posix_chdir(const char *path);
ZBCDLL int posix_unlink(const char *path);
ZBCDLL int posix_open(const char *pathname, int flags, U32 mode);
ZBCDLL int posix_close(int fd);
ZBCDLL FILE *posix_popen(const char *command, const char *type);
ZBCDLL int posix_pclose(FILE *stream);
ZBCDLL int posix_isatty(void);
ZBCDLL char *posix_mktemp(char *template_name);
ZBCDLL int posix_mkdir(const char *path, int mode);
ZBCDLL int posix_read(int fd, void *buf, U32 count);
ZBCDLL int posix_write(int fd, const void *buf, U32 count);
//  CPU count
ZBCDLL U32 posix_core_cnt(void);
//  Compare and Swap
ZBCDLL unsigned long posix_cas(unsigned long *ptr, unsigned long oldval, unsigned long newval);

ZBCDLL int posix_spawnve(const char *fname, const char *argv[], const char *env[]);
#ifdef __cplusplus
}
#endif


#endif  //POSIX_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
