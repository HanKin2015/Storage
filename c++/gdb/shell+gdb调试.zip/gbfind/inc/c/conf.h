#ifndef CONF_H_
#define CONF_H_
/**
 *  编译选项设置
 */

//  是否支持epoll: epoll_create, epoll_ctl,...
//#define HAS_EPOLL       1

//  是否支持backtrace: backtrace_symbols
//#define HAS_BACKTRACE   1

//#ifndef MODULE
//#   define MODULE 
//#endif
//#ifndef __KERNEL__
//#   define __KERNEL__
//#endif
//#ifdef CONFIG_SMP
//#   define __SMP__
//#endif

#endif //CONF_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
