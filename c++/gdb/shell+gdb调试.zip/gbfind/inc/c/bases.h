#ifndef BASES_H_
#define BASES_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//是否调试状态
#ifndef zDEBUG
#   ifndef NDEBUG
#       define zDEBUG 1
#   else
#       define zDEBUG 0
#   endif   //ifndef NDEBUG
#endif  //ifndef zDEBUG

//zPOSIX        是否兼容posix标准
//zWIN          Windows平台
//zDOS          DOS系统
#define zWIN        1
#define zPOSIX      2
#define zDOS        3

#ifndef zPLAT
#   ifdef _WIN32
#       define zPLAT        zWIN
#   endif
#   ifdef __linux__
#       define zPLAT        zPOSIX
#   endif
#endif  //ifndef zPLAT

//平台代码
#ifndef zPLAT
//gcc compiler
#ifdef __GNUC__
#   define zPLAT    zPOSIX
#endif
//watcom c++ compiler
#ifdef __WATCOMC__
#   define zPLAT    zDOS
#endif  //__WATCOMC__
//Microsoft C++ compiler
#ifdef _MSC_VER
#   define zPLAT    zWIN
#endif

#endif  //zPLAT

//Watcom c++ can't support the 'typename' keyword
#ifdef __WATCOMC__
#   define typename
#endif

//  unit test supports.
#if UT
#define UT_PRIVATE      public
#define UT_PROTECTED    public
#define UT_STATIC
#else   //if UT
#define UT_PRIVATE      private
#define UT_PROTECTED    protected
#define UT_STATIC       static
#endif  //if UT

//Only gcc/g++ support the '__attribute__'
#if !defined(__GNUC__) && !defined(__attribute__)
#define __attribute__(x) 
#endif

#if _MSC_VER >= 1200
#define NORETURN __declspec(noreturn)
#else
#define NORETURN 
#endif

#ifndef ZBCDLL
#   if _MSC_VER
#       ifdef STDZBC_EXPORTS
#           define ZBCDLL   __declspec(dllexport)
#       else    //ifdef STDZBC_EXPORTS
#           ifdef zUSEDLL
#               define ZBCDLL   __declspec(dllimport)
#           else    //ifdef zUSEDLL
#               define ZBCDLL
#           endif   //ifdef zUSEDLL
#       endif   //ifdef STDZBC_EXPORTS
#   else    //if _MSC_VER
#       define ZBCDLL
#   endif   //if _MSC_VER
#endif  //ifndef ZBCDLL

#if _MSC_VER > 1000
#pragma warning(disable:4786) //名字太长，截断为256
#endif

#endif//BASES_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
