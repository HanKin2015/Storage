#ifndef COMMON_H_
#define COMMON_H_

#include <c/conf.h>
#include <c/bases.h>
#include <c/types.h>

#endif//COMMON_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
