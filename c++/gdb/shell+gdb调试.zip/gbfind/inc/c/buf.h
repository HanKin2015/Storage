#ifndef BUF_H_
#define BUF_H_

#include <c/common.h>
#include <stdarg.h>
/**
 *  数据读写用的缓冲区
 */
struct buf_t {
    char   *buf_;           // 缓冲区首址
    U32     size_;          // 缓冲区长度
    U32     rpos_;          // 缓冲区读位置
    U32     wpos_;          // 缓冲区写位置
    BOOL    fixed_;         // 是否静态缓冲区，不允许扩张
};

/**
 *  初始化buf_t
 */
#define ZERO_buf_t     {0, 0, 0, 0, 0}
/**
 *  将缓冲区初始化为引用一个字节数组来写
 */
#define BUF_REFER_W(buf)    {buf, sizeof(buf), 0, 0, TRUE}

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------------------------------------------------------*\
 *  缓冲区管理
\*----------------------------------------------------------------------------*/
ZBCDLL buf_t *buf_new(void);
ZBCDLL void buf_free(buf_t *self);
ZBCDLL void buf_clear(buf_t *self);
ZBCDLL void buf_reset(buf_t *self);
ZBCDLL void buf_refer_w(buf_t *self, void *ptr, U32 size);
ZBCDLL void buf_refer_r(buf_t *self, const void *ptr, U32 size);
ZBCDLL HRET buf_reserve(buf_t *self, U32 size);
ZBCDLL void *buf_detach(buf_t *self);
ZBCDLL void buf_attach(buf_t *self, void *buf, U32 size);
ZBCDLL void buf_swap(buf_t *self, buf_t *rhs);

/*----------------------------------------------------------------------------*\
 *  读写位置操作
\*----------------------------------------------------------------------------*/
ZBCDLL HRET buf_move_r(buf_t *self, int off);
ZBCDLL HRET buf_move_w(buf_t *self, int off);
ZBCDLL HRET buf_set_r(buf_t *self, U32 pos);
ZBCDLL HRET buf_set_w(buf_t *self, U32 pos);
ZBCDLL U32 buf_rpos(const buf_t *self);
ZBCDLL U32 buf_wpos(const buf_t *self);
ZBCDLL char *buf_rptr(const buf_t *self);
ZBCDLL char *buf_wptr(const buf_t *self);

/*----------------------------------------------------------------------------*\
 *  读写数据
\*----------------------------------------------------------------------------*/
ZBCDLL int buf_getc(buf_t *self);
ZBCDLL HRET buf_getn(buf_t *self, void *data, U32 data_size);

ZBCDLL void buf_putc(buf_t *self, U8 ch);
ZBCDLL void buf_puts(buf_t *self, const char *ss);
ZBCDLL void buf_putn(buf_t *self, const void *data, U32 data_size);
ZBCDLL void buf_format(buf_t *self, const char *fmt, ...) 
    __attribute__((format(printf,2,3)));
ZBCDLL void buf_vformat(buf_t *self, const char *fmt, va_list ap);
ZBCDLL void buf_put_str(buf_t *self, const string_t *str);
ZBCDLL void buf_end_str(buf_t *self);
ZBCDLL void buf_rewrite(buf_t *self, U32 pos, const void *data, U32 data_size);

/*----------------------------------------------------------------------------*\
 *  取整体结果
\*----------------------------------------------------------------------------*/
ZBCDLL const char *buf_str(const buf_t *self);
ZBCDLL BOOL buf_str_is_overflow(const buf_t *self);
ZBCDLL BOOL buf_bin_is_overflow(const buf_t *self);

ZBCDLL U32 buf_data_size(const buf_t *self);       //  可读数据区长度
ZBCDLL U32 buf_spare_size(const buf_t *self);      //  空闲区长度
ZBCDLL U32 buf_capacity(const buf_t *self);

#ifdef __cplusplus
}
#endif


#endif //BUF_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
