#ifndef ERR_H_
#define ERR_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <c/common.h>

enum err_major_e {
    ERR_MAJOR_RT,                   //  运行时错误
    ERR_MAJOR_SYS,                  //  POSIX错误号(包含网络相关错误)
    ERR_MAJOR_PRIVATE = 7,          //  模块内部的私有错误
    ERR_MAJOR_CUSTOM = 8,           //  可定制类型的最小值
    ERR_MAJOR_MAX = 16,             //  可定制类型的最大值
};

#define MAKE_ERR(major_, minor_)    ((HRET)0x80000000 | (((HRET)(major_)) << 16) | (minor_))

#define err_noerror          0
//RUNTIME ERROR
#define err_failed           MAKE_ERR(ERR_MAJOR_RT, 1)          // 普通失败，没有详细原因
#define err_file             MAKE_ERR(ERR_MAJOR_RT, 2)          // 文件操作失败
#define err_exec             MAKE_ERR(ERR_MAJOR_RT, 3)          // 启动进程失败
#define err_notexist         MAKE_ERR(ERR_MAJOR_RT, 4)          // 查找的对象不存在
#define err_syntax           MAKE_ERR(ERR_MAJOR_RT, 5)          // 语法错误
#define err_unexpected       MAKE_ERR(ERR_MAJOR_RT, 6)          // 不期望的数据/状态
#define err_abnormal_end     MAKE_ERR(ERR_MAJOR_RT, 7)          // 异常结束
#define err_undefined        MAKE_ERR(ERR_MAJOR_RT, 8)          // 未定义的
#define err_duplicated       MAKE_ERR(ERR_MAJOR_RT, 9)          // 重复定义的
#define err_conflict         MAKE_ERR(ERR_MAJOR_RT, 10)         // 有冲突的
#define err_not_implement    MAKE_ERR(ERR_MAJOR_RT, 11)         // 没有实现的功能
#define err_timeout          MAKE_ERR(ERR_MAJOR_RT, 12)         // 超时
#define err_rejected         MAKE_ERR(ERR_MAJOR_RT, 13)         // 拒绝执行请求(一般是不符合安全要求)
#define err_cast             MAKE_ERR(ERR_MAJOR_RT, 14)         // 无效的类型转换
#define err_unprepared       MAKE_ERR(ERR_MAJOR_RT, 15)         // 系统还没有准备好
#define err_internal         MAKE_ERR(ERR_MAJOR_RT, 16)         // 内部错误(逻辑bug)
#define err_divide_zero      MAKE_ERR(ERR_MAJOR_RT, 17)         // 除0错误
#define err_not_initialized  MAKE_ERR(ERR_MAJOR_RT, 18)         // 未初始化
#define err_illegal_op       MAKE_ERR(ERR_MAJOR_RT, 19)         // 误操作
#define err_invalid_argu     MAKE_ERR(ERR_MAJOR_RT, 20)         // 无效参数
#define err_overflow         MAKE_ERR(ERR_MAJOR_RT, 21)         // 溢出
#define err_underflow        MAKE_ERR(ERR_MAJOR_RT, 22)         // 下溢
#define err_overrun          MAKE_ERR(ERR_MAJOR_RT, 23)         // 超载(过度执行)
#define err_outmemory        MAKE_ERR(ERR_MAJOR_RT, 24)         // 内存不足
#define err_resource         MAKE_ERR(ERR_MAJOR_RT, 25)         // 资源不足

#ifdef __cplusplus
extern "C" {
#endif

ZBCDLL void set_err_info(HRET major, const char *infos[], U32 info_size);
ZBCDLL const char *get_err_info(HRET err);

#ifdef __cplusplus
}
#endif

#endif  //ERR_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
