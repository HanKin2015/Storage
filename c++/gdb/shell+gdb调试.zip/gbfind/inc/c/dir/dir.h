/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#ifndef DIR_H_
#define DIR_H_

#include <c/common.h>
#include <sys/types.h>
#include <sys/stat.h>
/*
POSIX: opendir/readdir/closedir
#define SLASH
#define SLASH_C
#define S_ISDIR(x_)
#define S_ISREG(x_)
#define S_ISCHR(x_)
#define S_ISFIFO(x_)
#define _unlink
#define _mkdir
#define _MAX_FNAME
#define _MAX_EXT
#define _MAX_PATH
*/
#if defined(_MSC_VER)
#include <c/dir/win/dir_.h>
#else
#include <c/dir/posix/dir_.h>
#endif // _MSC_VER

#ifdef __cplusplus
extern "C" {
#endif
//  判断是否 "." 和 ".."
ZBCDLL BOOL is_self_or_parent_dir(const char *name);
//  判断是否 "." 和 ".."
ZBCDLL BOOL is_self_or_parent(struct dirent *pDirent);
//  判断name是否一个目录
ZBCDLL test_e dir_test(const char *path);
//  把路径的分隔符转换为字符slash
ZBCDLL void dir_conv(char *path, char slash);
//  把路径转换成适应当前系统类型的路径名
ZBCDLL void dir_localize(char *path);
//  去除路径末尾的斜杠
ZBCDLL void dir_trim(char *dir);
//  将目录和文件名连接为完全路径名
ZBCDLL int dir_concat(char *path
    , const char *dir, const char *fname, const char *fext, char slash);
//  分解路径字符串，从中取出文件名，及扩展名
ZBCDLL void split_path(const char *path, char *dir, char *fname, char *ext);
//  已知当前目录的绝对路径是abs_curdir，求目标(相对路径为dest)的绝对路径
ZBCDLL int get_absolute_path(char *path
    , const char *abs_curdir, const char *dest);
//  取得从当前目录(绝对路径是abs_curdir)到目标(绝对路径abs_dest)的相对路径
ZBCDLL void get_relative_path(char *path
    , const char *abs_curdir, const char *abs_dest);
//  改变相对路径path的基准路径，原来的基准路径是abs_curdir,新的基准路径是basedir
ZBCDLL int change_base_dir(char *path
    , const char *abs_curdir, const char *basedir);

//  将一个文件名正规化
ZBCDLL void file_normalize(char *fname, const char *fprefix, const char *ext);

//  创建文件fname的父目录
ZBCDLL int mk_parent_dir(const char *path);
//  创建目录，如果上级目录不存在，递归创建上级目录
ZBCDLL int mk_dir(const char *dir);

#ifdef __cplusplus
}
#endif

#endif //DIR_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
