/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#ifndef DIR__H_
#define DIR__H_

//  VC不支持opendir/readdir/closedir

#ifndef _WIN32
#error "This file only using in WIN32."
#endif

#include <io.h>
#include <direct.h>
//  define _MAX_PATH, _MAX_FNAME, _MAX_DIR, _MAX_EXT, _MAX_DRIVE
#include <stdlib.h>

#define SLASH           "\\"
#define SLASH_C         '\\'

#ifndef S_ISDIR
#define S_ISDIR(x_)     (((x_) & _S_IFDIR) == _S_IFDIR)     //目录
#endif

#ifndef S_ISREG
#define S_ISREG(x_)     (((x_) & _S_IFREG) == _S_IFREG)     //普通文件
#endif

#ifndef S_ISCHR
#define S_ISCHR(x_)     (((x_) & _S_IFCHR) == _S_IFCHR)     //字符设备
#endif

#ifndef S_ISFIFO
#define S_ISFIFO(x_)    (((x_) & _S_IFIFO) == _S_IFIFO)     //FIFO
#endif

#ifndef NAME_MAX
#define NAME_MAX        260         //文件名的最大长度
#endif

/**
 *  目录
 */
struct dirent {
    long d_ino;                 /* inode number */
    off_t d_off;                /* offset to this dirent */
    unsigned short d_reclen;    /* length of this d_name */
    char d_name[NAME_MAX+1];    /* file name (null-terminated) */
};
/**
 *  目录扫描的临时结果
 */
typedef struct DIR_ {
    struct _finddata_t fdata;
    int hfind;
    struct dirent dir;
} DIR;

/**
 *  scandir扫描过程中过滤目录
 *  @return 非0表示需要将该目录存储返回给scandir的调用者
 */
typedef int (*dirent_filter)(const struct dirent *);
/**
 *  scandir扫描过程中的排序比较函数
 */
typedef int (*dirent_compare)(const struct dirent **, const struct dirent **);

#ifdef __cplusplus
extern "C" {
#endif

ZBCDLL DIR *opendir(const char *name);
ZBCDLL struct dirent *readdir(DIR *pDir);
ZBCDLL int closedir(DIR *pDir);

ZBCDLL int scandir(const char *dir, struct dirent ***namelist
    , dirent_filter filter, dirent_compare compar);
ZBCDLL int alphasort(const struct dirent **lhs, const struct dirent **rhs);
ZBCDLL int versionsort(const struct dirent **lhs, const struct dirent **rhs);
ZBCDLL int lstat(const char *name, struct stat *pst);

#ifdef __cplusplus
}
#endif

#endif //DIR__H_
