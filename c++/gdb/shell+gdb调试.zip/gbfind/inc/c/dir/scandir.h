#ifndef SCANDIR_H_
#define SCANDIR_H_

#include <c/dir/dir.h>

/**
 *  扫描目录时的回调函数原型
 *  @param  fullname    当前被扫描到的文件的全路径名
 *  @param  dirname     当前被扫描到的文件的所在路径
 *  @param  fname       当前被扫描到的文件的文件名
 *  @param  para        扫描时传入的扩展参数
 */
typedef HRET (*PfnScanDir_SeeFile)(const char *fullname
        , const char *dirname, const char *fname, void *para);

#ifdef __cplusplus
extern "C" {
#endif

ZBCDLL HRET scan_dir(const char *dirname, BOOL bScanChilds, const char *fexts
    , PfnScanDir_SeeFile pfn, void *para);
ZBCDLL BOOL match_file_exts(const char *fname, const char *fexts);

#ifdef __cplusplus
}
#endif

#endif //SCANDIR_H_

/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
