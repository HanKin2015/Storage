/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#ifndef DIR__H_
#define DIR__H_

//POSIX标准支持opendir/readdir/closedir
//MINGW也支持,另外MINGW的stdlib已经定义了_MAX_PATH等宏

#include <dirent.h>
#include <unistd.h>

#define SLASH           "/"
#define SLASH_C         '/'
#define _unlink         unlink
#define _mkdir          mkdir
#define _MAX_FNAME      256
#define _MAX_EXT        256
#ifndef _MAX_PATH
#define _MAX_PATH       260
#endif


#endif //DIR__H_
