#ifndef TYPES_H_
#define TYPES_H_

/*----------------------------------------------------------------------------*\
    基础数据类型的重定义(为了跨平台)
\*----------------------------------------------------------------------------*/
typedef unsigned char       U8;
typedef unsigned short      U16;
typedef unsigned int        U32;

typedef signed char         I8;
typedef signed short        I16;
typedef int                 I32;

#ifdef _MSC_VER
typedef __int64             I64;
typedef unsigned __int64    U64;
#else   //ifdef _MSC_VER
typedef long long           I64;
typedef unsigned long long  U64;
#endif  //ifdef _MSC_VER

#ifdef __KERNEL__
//  在内核里，不应使用double类型
typedef I64 _fake_double;
#define double _fake_double
#endif  //ifdef __KERNEL__
/*----------------------------------------------------------------------------*\
    错误标记类型
\*----------------------------------------------------------------------------*/
typedef int HRET;           //错误号类型(Here’s the Result)
typedef int HIDX;           //索引类型，>=0表示索引，<0表示错误号(Here's the index)
/*----------------------------------------------------------------------------*\
    BOOL --- 布尔值
\*----------------------------------------------------------------------------*/
typedef int BOOL;           //BOOL类型，只有两个取值：TRUE,FALSE

#ifndef TRUE
#define TRUE    1
#endif

#ifndef FALSE
#define FALSE   0
#endif
/*----------------------------------------------------------------------------*\
    指针类型
\*----------------------------------------------------------------------------*/
//  空指针的跨平台定义
#ifndef NULL
#   ifdef __cplusplus
#       define NULL    0
#   else   //ifdef __cplusplus
#       define NULL    ((void *)0)
#   endif  //ifdef __cplusplus
#endif  //ifndef NULL
/*----------------------------------------------------------------------------*\
    数组类型
\*----------------------------------------------------------------------------*/
//  数组元素个数
//  !!!不能用来测试函数参数中所传递数组的长度，因为参数中的数组会退化为指针
#ifndef DIMOF
#define DIMOF(arr)  (sizeof(arr) / sizeof(arr[0]))
#endif  //ifndef DIMOF
/*----------------------------------------------------------------------------*\
    默认初始化
\*----------------------------------------------------------------------------*/
#ifndef ZERO
#define ZERO(type)  ZERO_##type
#endif  //ifndef ZERO
/*----------------------------------------------------------------------------*\
    数据及配置
\*----------------------------------------------------------------------------*/
/**
 *  使能标识
 */
typedef enum enable_e {
    UNCHANGED   = 0,    //不改变原有设置
    DISABLE     = -1,   //禁止功能
    ENABLE      = 1,    //开启功能
    DEFAULT     = 2,    //系统缺省值
} enable_e;
/**
 *  执行某个条件测试的结果：出错，符合，不符合
 */
typedef enum test_e {
    TEST_ERROR = -1,    //出错
    TEST_NO = 0,        //不符合
    TEST_YES = 1,       //符合
} test_e;
/**
 *  数据格式
 */
typedef enum data_e {
    DF_NONE,        //  无效格式
    DF_AUTO,        //  默认格式
    DF_XML,         //  XML格式
    DF_JSON,        //  JSON格式
    DF_MML,         //  MML格式
    DF_BIN,         //  二进制格式
    DF_MAX
} data_e;

/*----------------------------------------------------------------------------*\
    base
\*----------------------------------------------------------------------------*/
typedef struct ref_t            ref_t;          //<c/ref.h>: 委托数据
typedef struct buf_t            buf_t;          //<c/buf.h>: 读写缓冲区
typedef struct string_t         string_t;       //<c/str.h>: 字符串
typedef struct packet_t         packet_t;       //<c/packet.h>: 数据包
typedef struct pklist_t         pklist_t;       //<c/packet.h>: 数据包队列
typedef struct htable_t         htable_t;       //<c/ht.h>: 哈希表
typedef struct hset_t           hset_t;         //<c/hset.h>: 哈希集合
typedef struct hnode_t          hnode_t;        //<c/ht.h>: 哈希表的节点
typedef struct dict_t           dict_t;         //<c/dict.h>: 字典(字符串键值表)
typedef struct trie_t           trie_t;         //<c/trie.h>: 字典树
typedef struct bitset_t         bitset_t;       //<c/bitset.h>: 位集合
typedef struct cycque_t         cycque_t;       //<c/cycque.h>: 循环队列
typedef struct pd_table_t       pd_table_t;     //<c/privdata.h>: private data table, 私有数据注册表
typedef struct pd_chunk_t       pd_chunk_t;     //<c/privdata.h>: private data chunk, 私有数据块
typedef struct ptrlist_t        ptrlist_t;      //<c/ptrlist.h>: 指针列表
typedef struct objlist_t        objlist_t;      //<c/objlist.h>: 对象列表
typedef struct range_t          range_t;        //<c/str/range.h>: 字符串区间[beg, end)
typedef struct kobj_t           kobj_t;         //核心对象(可注册的版本化对象)
typedef struct klist_t          klist_t;        //核心对象列表
typedef struct argv_t           argv_t;         //命令行参数列表

typedef struct threshold_item_t threshold_item_t; //<c/dbg/threshold.h>: 控制某个组的开关
typedef struct threshold_t      threshold_t;    //<c/dbg/threshold.h>: 命名开关
/*----------------------------------------------------------------------------*\
    c/parse:
\*----------------------------------------------------------------------------*/
typedef struct reader_t         reader_t;
typedef struct rd_pos_t         rd_pos_t;
typedef struct token_t          token_t;
typedef struct c_lexer_t        c_lexer_t;
/*----------------------------------------------------------------------------*\
    c/xml:
\*----------------------------------------------------------------------------*/
typedef struct xml_node_t       xml_node_t;     //<c/xml/xml.h>
typedef struct xml_doc_t        xml_doc_t;      //<c/xml/xml.h>
typedef struct xml_attrs_t      xml_attrs_t;    //属性集合
typedef struct xml_nodes_t      xml_nodes_t;    //节点集合
/*----------------------------------------------------------------------------*\
    c/json:
\*----------------------------------------------------------------------------*/
typedef struct jvalue_t         jvalue_t;       //<c/json/jvalue.h>

/*----------------------------------------------------------------------------*\
    c/writer:
\*----------------------------------------------------------------------------*/
typedef struct writer_t         writer_t;

/*----------------------------------------------------------------------------*\
    c/net:
\*----------------------------------------------------------------------------*/
typedef union sockaddr_t        sockaddr_t;

/*----------------------------------------------------------------------------*\
    meta:
\*----------------------------------------------------------------------------*/
typedef struct type_t           type_t;
typedef struct member_t         member_t;
typedef struct meta_t           meta_t;
typedef struct attr_t           attr_t;
typedef struct method_t         method_t;
typedef struct interface_t      interface_t;
typedef struct array_t          array_t;        //<meta/arr.h>: 数组
typedef struct metalist_t       metalist_t;
typedef struct feature_t        feature_t;
typedef struct track_t          track_t;
typedef struct objref_t         objref_t;

/*----------------------------------------------------------------------------*\
    callbacks:
\*----------------------------------------------------------------------------*/
typedef void (*fn_free)(void *);                        //释放对象
typedef void *(*fn_clone)(const void *);                //复制对象
typedef void (*fn_dump)(const void *, xml_node_t *);    //倾印对象信息
typedef U32 (*fn_hash)(const void *data);               //计算对象的HASH值
typedef int (*fn_compare)(const void *lhs, const void *rhs); //比较两个对象

/*----------------------------------------------------------------------------*\
    krt相关
\*----------------------------------------------------------------------------*/
#ifndef __KERNEL__
/**
 *  文件描述符上可以发生的事件
 *  @note 这三个的值和POLLIN,POLLOUT,POLLERR保持一致。
 */
#define FDEVENT_IN   1
#define FDEVENT_OUT  2
#define FDEVENT_ERR  4
#define FDEVENT_HUP  8
#define FDEVENT_PRI  16

/**
 *  程序返回值(main函数返回值)
 */
#define MAIN_OK     0       //成功执行命令的请求
#define MAIN_ARGU   1       //参数错误
#define MAIN_FAILED 2       //失败，重试不确定能否成功
#define MAIN_ERROR  3       //一个错误，确定性问题
/*----------------------------------------------------------------------------*\
    c/fd:
\*----------------------------------------------------------------------------*/
typedef struct fd_handler_t     fd_handler_t;   //<c/fd/fd.h>
typedef struct fd_t             fd_t;           //<c/fd/fd.h>
typedef struct fset_t           fset_t;         //<c/fd/fset.h>
typedef struct sockset          sockset;        //<c/net/sockset.h>
typedef struct udp_t            udp_t;          //<c/fd/udp.h>
/*----------------------------------------------------------------------------*\
    c/task:
\*----------------------------------------------------------------------------*/
typedef struct task_s           task_s;
typedef struct timeque_t        timeque_t;
typedef struct taskque_t        taskque_t;

/*----------------------------------------------------------------------------*\
    c/module:
\*----------------------------------------------------------------------------*/
typedef struct module_t         module_t;

#endif //ifndef __KERNEL__

#endif //TYPES_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
