#ifndef RANGE_H_
#define RANGE_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <c/common.h>
/**
 *  字符串区间分析算法，即对目标字符串的分析比较只局限在一个区间内。
 *  这些函数统一特点是：前两个参数是目标区间的起止地址：原型如:
 *      xxx(const char *pb, const char *pe, ...)
 */
struct range_t {
    const char *beg;
    const char *end;
};

#define ZERO_range_t        {(const char *)0, (const char *)0}
#define RANGE_INIT(pb, pe)  {pb, pe}
#define RANGE_PAIR(pb, pe)  \
    ((pe) ? (int)((char *)(pe) - (char *)(pb)) : -1), (char *)(pb)

#ifdef __cplusplus
extern "C" {
#endif

//  比较两字符串是否相同，其中一个以'\0'作为结束，一个通过区间[pb, pe)标示
ZBCDLL int range_cmp(const char *pb, const char *pe, const char *strs);
//  比较两字符串是否相同(忽略大小写)，其中一个以'\0'作为结束，一个通过区间[pb, pe)标示
ZBCDLL int range_ncase_cmp(const char *pb, const char *pe, const char *strs);
//  区间内搜索子串,类strstr
ZBCDLL const char *range_substr(const char *pb, const char *pe, const char *sub);
//  区间内搜索字符,类strchr
ZBCDLL const char *range_strchr(const char *pb, const char *pe, char ch);
//  复制一个区间的字符为一个新字符串
ZBCDLL char *range_strdup(const char *pb, const char *pe);
//  拷贝一个字符串区间到缓冲区buf中(buf长度为bufsize)
ZBCDLL void range_copy(char *buf, U32 bufsize, const char *pb, const char *pe);
//  检查区间[pb,pe)开头是否是子串strs,是则跳过，否则不动
ZBCDLL const char *range_skip(const char *pb, const char *pe, const char *strs);

#ifdef __cplusplus
}
#endif


#endif //RANGE_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
