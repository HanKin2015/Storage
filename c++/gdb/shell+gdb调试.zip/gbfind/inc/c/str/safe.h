#ifndef SAFE_H_
#define SAFE_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <c/common.h>
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

ZBCDLL void strcpy_n(char *buf, U32 bufsize, const char *src);
ZBCDLL char *strcat_n(char *buf, U32 bufsize, const char *src);
ZBCDLL char *strdup_s(const char *sz);
ZBCDLL void sprintf_n(char *buf, U32 bufsize, const char *fmt, ...)
    __attribute__((format(printf,3,4)));
ZBCDLL void vsprintf_n(char *buf, U32 bufsize, const char *fmt, va_list ap);

#ifdef _MSC_VER
ZBCDLL int snprintf(char *buf, U32 bufsize, const char *fmt, ...);
ZBCDLL int vsnprintf(char *buf, U32 bufsize, const char *fmt, va_list ap);
#endif

#ifdef __cplusplus
}
#endif


#endif //SAFE_H_
/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
