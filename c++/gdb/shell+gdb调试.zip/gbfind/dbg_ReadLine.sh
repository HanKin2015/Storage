#!/usr/bin/expect

#log_file ./gbfind_test.log

spawn gdb ./pack/LINUX/bin/gbfind

# 在StatFile函数开头设断点
expect "(gdb)"
send "break StatFile\n"

expect "(gdb)"
send "break 215\n"

# 启动gbfind
expect "(gdb)"
send "r /c /s /e:xsl\n"

# 调用gbfind中的函数
expect "(gdb)"
send "set fname=\"gbfind.c\"\n"

expect "(gdb)"
send "continue\n"

# 调用ReadLine函数进行测试，并检查结果，如果结果不对，进入交互调试环节
expect "(gdb)"
send "call ReadLine(&strLine, fp)\n"
expect {
    "= 1" {send_log "ReadLine(.) OK\n"}
    "= 0" {interact}
}

# 退出gdb
expect "(gdb)"
send "quit\n"
