/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/dir/dir.h>
#include <c/str/safe.h>
#include <c/posix.h>

#include <string.h>
#include <assert.h>
#include <errno.h>
#ifdef _MSC_VER
#include "vc/dir.c"
#endif // ifdef _MSC_VER
/**
 *  @file
 *  @ingroup dir
 *  @brief 目录操作
 */

/**
 *  @brief 判断目录名字name是否 "." 和 ".."
 */
BOOL is_self_or_parent_dir(const char *name)
{
    assert(name);
    if (name[0] != '.')
        return FALSE;
    if (name[1] == '\0')
        return TRUE;
    if (name[1] == '.' && name[2] == '\0')
        return TRUE;
    return FALSE;
}

/**
 *  @brief 判断目录项dir是否 "." 和 ".."
 */
BOOL is_self_or_parent(struct dirent *dir)
{
    assert(dir);
    return is_self_or_parent_dir(dir->d_name);
}
/**
 *  @brief 判断name是否一个目录
 *  @param name 路径名字
 *  @return 是否目录
 *  @retval TEST_ERROR 表示出错，name表示的文件根本不存在
 *  @retval TEST_YES 表示目录
 *  @retval TEST_NO 表示非目录
 */
test_e dir_test(const char *path)
{
    struct stat st;

    assert(path);
    if (stat(path, &st) < 0)
        return TEST_ERROR;
    if (S_ISDIR(st.st_mode))
        return TEST_YES;
    return TEST_NO;
}
/**
 *  @brief 把路径的分隔符转换为字符split
 */
void dir_conv(char *path, char slash)
{
    char *pc;

    assert(path);
    for (pc = path; *pc; ++pc) {
        if (*pc == '/' || *pc == '\\') {
            *pc = slash;
        }
    }
}
/**
 *  @brief 把路径转换成适应当前系统类型的路径名
 *  @param [in,out] path  路径名
 */
void dir_localize(char *path)
{
#if zPLAT == zWIN
    dir_conv(path, '\\');
#elif zPLAT == zPOSIX
    dir_conv(path, '/');
#else
#error unsupport
#endif
}
/**
 *  去除路径末尾的斜杠
 *  @param [in,out] dir 目录名
 */
void dir_trim(char *dir)
{
    int len;

    assert(dir);
    //  首字符是斜杠表示根目录，不去除
    for (len = (int)strlen(dir) - 1; len > 0; --len) {
        if (dir[len] == '/' || dir[len] == '\\') {
            dir[len] = '\0';
        } else {
            break;
        }
    }
}
/**
 *  @brief 将目录和文件名连接起来成为完全路径
 *  @param [out] path 全路径名
 *  @param [in] dir 目录名
 *  @param [in] fname 文件名
 *  @param [in,opt] fext 后缀名，可以带.，也可不带，如：.txt txt
 *  @param [in] slash 分隔符
 *  @return >=0表示成功，否则表示有错误，如连接后路径超长
 */
int dir_concat(char *path
    , const char *dir, const char *fname, const char *fext, char slash)
{
    char *pw;
    char *pe;
    const char *pr;

    assert(path);
    assert(dir);
    assert(fname);

    pr = dir;
    pw = path;
    pe = pw + _MAX_PATH - 1;
    while (*pr) {
        if (pw >= pe)
            goto failed_;
        if (*pr == '/' || *pr == '\\') {
            *pw = slash;
        } else {
            *pw = *pr;
        }
        ++pr;
        ++pw;
    }
    //  最后一个字符不是分隔符
    if (pw > path && *(pw - 1) != slash) {
        *pw++ = slash;
    }
    pr = fname;
    while (*pr) {
        if (pw >= pe)
            goto failed_;
        *pw++ = *pr++;
    }
    if (fext) {
        pr = fext;
        if (*pr == '.')
            ++pr;
        if (pw >= pe)
            goto failed_;
        *pw++ = '.';
        while (*pr) {
            if (pw >= pe)
                goto failed_;
            *pw++ = *pr++;
        }
    }
    *pw = '\0';
    return 0;
failed_:
    *pw = '\0';
    return -1;
}
/**
 *  @brief 分解路径字符串，从中取出文件名，及扩展名
 *  @param [in] path    路径字符串
 *  @param [out] dir    目录
 *  @param [out] fname  文件名
 *  @param [out] fext   扩展名
 */
void split_path(const char *path, char *dir, char *fname, char *fext)
{
    U32 len = 0;
    U32 dirend = 0;         //目录名的结束位置
    U32 fnend = 0;          //文件名的结束位置

    assert(path);

    len = strlen(path);
    if (len >= _MAX_PATH)
        len = _MAX_PATH - 1;
    dirend = 0;

    //  从后往前找,找到'.'或目录分界符
    for (fnend = len; fnend > 0; --fnend) {
        char c = path[fnend - 1];
        if (c == '.') {
            --fnend;            //fnend指向'.'的位置
            dirend = fnend;     //dirend也指向点的位置
            break;
        } else if (c == '/' || c == '\\') { //说明文件名中没有'.'
            dirend = fnend;     //dirend指向'/'后面一个位置,目录名包含了最后一个'/'
            fnend = len;        //fnend指向路径末尾
            break;
        }
    }
    if (fnend == 0 && path[0] != '.') {   //什么分隔符都没有找到，纯粹文件名
        dirend = 0;
        fnend = len;
    } else {
        //  找到最后一个目录分界符,dirend指向的是分界符的后一个位置
        for (; dirend > 0; --dirend) {
            char c = path[dirend - 1];
            if (c == '/' || c == '\\')
                break;
        }
    }
    if (dir) {
        memcpy(dir, path, dirend);
        dir[dirend] = '\0';
    }
    if (fname) {
        memcpy(fname, path + dirend, fnend - dirend);
        fname[fnend - dirend] = '\0';
    }
    if (fext) {
        memcpy(fext, path + fnend, len - fnend);
        fext[len - fnend] = '\0';
    }
}
/**
 *  @brief 取绝对路径的前导符号
 *  @param [in] path  路径，可能是相对路径或绝对路径
 *  @return 前导符号
 *      '/'表示POSIX绝对路径,
 *      ‘\\'表示windows绝对路径不带盘符
 *      ':'表示windows绝对路径带盘符
 *      '\0'表示非绝对路径
 */
static char get_absolute_path_leader(const char *path)
{
    assert(path);
    if (*path == '/')
        return '/';
    else if (*path == '\\')
        return '\\';
    return strchr(path, ':') ? ':' : '\0';
}
/**
 *  @brief 取得从当前目录(绝对路径是abs_curdir)到目标(绝对路径abs_dest)的相对路径
 *  @param [out] path  相对路径
 *  @param [in] abs_curdir  当前目录(需保证是绝对路径)
 *  @param [in] abs_dest    目标路径(需保证是绝对路径)
 */
void get_relative_path(char *path, const char *abs_curdir, const char *abs_dest)
{
    const char *sp;     //sp指向srcdir的本次分析开始位置
    const char *dp;     //dp指向dest的本次分析开始位置
    const char *spe;    //spe指向srcdir的本次分析结束位置
    const char *dpe;    //dpe指向dest的本次分析结束位置
    char *pw;           //path的下一个写位置
    char separator;     //srcdir使用的前导分隔符： ':' '/'

    assert(path);
    assert(abs_curdir);
    assert(abs_dest);
    separator = get_absolute_path_leader(abs_curdir);
    assert(separator == ':' || separator == '/');
    separator = separator == ':' ? '\\' : '/';
    //  先去除两个路径开头相同的部分
    //  这个相同部分表示两个路径的公共父目录
    sp = abs_curdir;
    dp = abs_dest;
    for (;;) {
        spe = strpbrk(sp, "/\\");
        dpe = strpbrk(dp, "/\\");

        //  如果有一端已经是到末尾了
        if (!spe) {
            spe = sp + strlen(sp);
        }
        if (!dpe) {
            dpe = dp + strlen(dp);
        }
        //  两边已经不相同了
        if (spe - sp != dpe - dp)
            break;
        if (memcmp(sp, dp, spe - sp) != 0)
            break;

        //  相同的子目录，继续比较下一级子目录
        sp = spe;
        dp = dpe;

        if (*sp != '\0')
            ++sp;
        if (*dp != '\0')
            ++dp;
        if (*sp == '\0' || *dp == '\0')
            break;
    }

    if (strchr(dp, ':')) {  //还是绝对路径
        strcpy_n(path, _MAX_PATH, abs_dest);
        return;
    }
    pw = path;
    //  计算srcdir还剩几级的路径，每多一级，在相对路径上加一个../
    //  表示从srcdir到达公共父目录需要进行几次..
    for (;;) {
        if (*sp == '\0')
            break;
        *pw++ = '.';
        *pw++ = '.';
        spe = strpbrk(sp, "/\\");
        if (!spe)
            break;
        *pw++ = separator;
        sp = spe + 1;
    }
    if (pw == path) {
        *pw++ = '.';
    }
    if (*dp) {
        *pw++ = separator;
        strcpy(pw, dp);
    } else {
        *pw = '\0';
    }
}
/**
 *  @brief 已知当前目录的绝对路径是abs_curdir，求目标(相对路径为dest)的绝对路径
 *  @param [out] path  绝对路径
 *  @param [in] abs_curdir  当前目录(必须是绝对路径)
 *  @param [in] dest        目标路径(相对于abs_curdir的相对路径)
 *  @return <0 路径有错误; ==0 正常
 */
int get_absolute_path(char *path, const char *abs_curdir, const char *dest)
{
    const char *dp;     //  指向dest的当前处理位置的指针
    const char *cp;     //  指向curdir当前处理位置的指针

    char cur_separator; //  curdir使用的分隔字符: ':' '/'
    char dest_leader;   //  dest的前导符号：'\\' '/' ':'

    assert(path);
    assert(abs_curdir && abs_curdir[0]);
    assert(dest && dest[0]);

    //  curdir应该是个绝对路径
    cur_separator = get_absolute_path_leader(abs_curdir);
    assert(cur_separator == ':' || cur_separator == '/');

    //  检查dest是否绝对路径
    dest_leader = get_absolute_path_leader(dest);
    if (dest_leader == ':' || dest_leader == '/') {
        strcpy_n(path, _MAX_PATH, dest);
        return 0;
    } else if (dest_leader == '\\') {       //window绝对路径，缺少盘符
        sprintf_n(path, _MAX_PATH, "%c:%s", abs_curdir[0], dest);
        return 0;
    }
    //  cp定位到curdir，从后向前处理，如果末尾是分隔符，将其消掉
    //  假如curdir为POSIX的根目录，也会被消掉
    cp = abs_curdir + strlen(abs_curdir);
    if (*(cp-1) == '/' || *(cp - 1) == '\\')
        --cp;
    //  dest是相对路径
    //  消除dest中开头的那些./和../，每个../会抵消curdir末尾的一级目录
    dp = dest;
    for (;;) {
        if (*dp != '.')
            break;
        ++dp;
        if (*dp == '\0') {
            break;
        } else if (*dp == '/' || *dp == '\\') { //  是./ 或 .\ 直接跳过
            ++dp;
            continue;
        } else if (*dp == '.') {                //..
            ++dp;
            if (*dp != '\0' && *dp != '/' && *dp != '\\') { // ..x
                dp -= 2;
                break;
            }
            if (cp == abs_curdir || *(cp - 1) == ':') {   //退多了，表明..太多
                path[0] = '\0';
                return -1;
            }
            //  遇到../或..\, curdir往上退一级
            while (cp > abs_curdir) {
                --cp;
                if (*cp == '/' || *cp == '\\')
                    break;
            }
            if (*dp == '\0')
                break;
            else
                ++dp;
        } else {        // .x文件
            --dp;
            break;
        }
    }
    if (cp == abs_curdir && *cp == '/') {   //POSIX路径，已经退到根目录了
        sprintf_n(path, _MAX_PATH, "/%s", dp);
        return 0;
    }
    if (dp[0] != '\0') {
        sprintf_n(path, _MAX_PATH, "%.*s%c%s", (int)(cp - abs_curdir)
            , abs_curdir, cur_separator == ':' ? '\\' : '/', dp);
    } else {
        sprintf_n(path, _MAX_PATH, "%.*s", (int)(cp - abs_curdir), abs_curdir);
    }
    return 0;
}
/**
 *  @brief 改变相对路径path的基准路径，原来的基准路径是abs_curdir,新的基准路径是basedir
 *  @param [in,out] path    相对路径
 *  @param [in] abs_curdir  旧的基准路径(必须是绝对路径)
 *  @param [in] basedir     新的基准路径(相对于abs_curdir的相对路径)
 *  @return <0表示有错误，否则表示成功
 *  @remark
 *      调用change_base_dir前,path是基于abs_curdir的相对路径
 *      调用change_base_dir后,path是基于basedir的相对路径
 */
int change_base_dir(char *path
    , const char *abs_curdir, const char *basedir)
{
    char abs_base[_MAX_PATH];
    char abs_path[_MAX_PATH];
    int ret;

    ret = get_absolute_path(abs_base, abs_curdir, basedir);
    if (ret < 0)
        return ret;
    ret = get_absolute_path(abs_path, abs_curdir, path);
    if (ret < 0)
        return ret;

    get_relative_path(path, abs_base, abs_path);
    return 0;
}
/**
 *  @brief 生成path依赖的父目录
 *  @param path 文件路径
 *  @return <0表示创建失败，否则表示成功
 */
int mk_parent_dir(const char *path)
{
    char dir[_MAX_PATH];
    char *p = dir;
    int ret;
    char old;

    assert(path);

    strcpy_n(dir, sizeof(dir), path);
    if (*p == '/')
        ++p;
    for (;;) {
        p = strpbrk(p, "/\\");
        if (!p)
            return 0;
        old = *p;
        *p = '\0';
        ret = posix_mkdir(dir, 0775);
        *p = old;
        if (ret < 0 && errno != EEXIST)
            return -1;
        p = p + 1;
    }
}
/**
 *  创建目录，如果上级目录不存在，递归创建上级目录
 */
int mk_dir(const char *path)
{
    int ret;

    assert(path);
    ret = mk_parent_dir(path);
    if (ret < 0)
        return ret;
    ret = posix_mkdir(path, 0775);
    if (ret < 0 && errno != EEXIST)
        return -1;
    return 0;
}

/**
 *  生成一个文件名，该文件放在目录dir下，后缀为ext，文件名主体部分为fprefix的变体
 */
void file_normalize(char *fname, const char *fprefix, const char *ext)
{
    const char *pc;
    char *pw;
    char *pe;

    assert(fname);
    assert(fprefix);
    
    //  把文件前缀名转义输出到文件名前部
    pw = fname;
    pe = fname + _MAX_PATH - 1;
    for (pc = fprefix; *pc; ++pc) {
        if (pw >= pe)
            break;
        if (strchr("\\/:*?\"<>|%", *pc) == NULL) {
            *pw++ = *pc;
            continue;
        }
        //  通过把字符转为%xx形式的十六进制编码来避免文件名不合法
        if (pw + 3 >= pe)
            break;
        sprintf(pw, "%%%02x", (U8)*pc);
        pw += 3;
    }
    //  把扩展名附加到文件名后部
    for (pc = ext ? ext : ""; *pc; ++pc) {
        if (pw >= pe)
            break;
        *pw++ = *pc;
    }
    *pw = '\0';
}
