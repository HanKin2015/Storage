/*
 *  Copyright (c) 2006 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/dir/scandir.h>
#include <c/err.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
/**
 *  @file
 *  @ingroup dir
 *  @brief 目录遍历
 */
//RTDUMP_THRESHOLD("scandir"); 
/**
 *  检查文件名是否匹配扩展名列表（扩展名列表是以';'或','分隔的字符串）
 *  @note "c;cpp;cxx;h;hpp;hxx;inc", ".c;.cpp;.cxx;.fxx;.hxx;"
 */
BOOL match_file_exts(const char *fname, const char *fexts)
{
    char fext[_MAX_EXT];
    const char *cur = NULL;
    U32 fext_len;

    assert(fexts && fname);

    split_path(fname, NULL, NULL, fext);

    if (fext[0] == '\0')
        return FALSE;

    //split_path得到的扩展名fext中带有'.'这个前缀，而扩展名列表中的扩展名不带'.'前缀
    //所以，比较时需要忽略fext的前缀'.'
    fext_len = strlen(fext + 1);
    cur = strstr(fexts, fext + 1);
    while (cur) {
        if (cur[fext_len] == ';' || cur[fext_len] == ','
            || cur[fext_len] == '\0') {     //后面是分隔符或者结束符
            if (cur == fexts)
                return TRUE;
            else if (*(cur - 1) == '.')     //
                return TRUE;
            else if (*(cur - 1) == ';')
                return TRUE;
            else if (*(cur - 1) == ',')
                return TRUE;
        }
        cur = strstr(cur + fext_len, fext + 1);
    }
    return FALSE;
}
/**
 *  扫描目录并对扫描到的所有文件执行回调
 *  @param [in] dirname     待扫描的目录名
 *  @param [in] bScanChilds 是否扫描子目录
 *  @param [in] fexts       需要扫描的文件的扩展名列表，以';'或','分隔,为NULL表示所有文件
 *  @param [in] pfn         扫描到文件时执行的回调函数
 *  @param [in] para        传递给回调函数pfn的扩展参数，可以为NULL
 *  @return 成功返回0，否则返回<0
 *  @note 扩展名列表fexts格式：c;cpp;h;hpp
 */
HRET scan_dir(const char *dirname, BOOL bScanChilds, const char *fexts
    , PfnScanDir_SeeFile pfn, void *para)
{
    DIR *pdir = NULL;
    struct dirent *p = NULL;

    assert(dirname);
    assert(pfn);

    pdir = opendir(dirname);
    if (!pdir) {
        fprintf(stderr, "opendir(%s) failed(%d): %s\n"
            , dirname, errno, strerror(errno));
        return err_file;
    }
    for (p = readdir(pdir); p; p = readdir(pdir)) {
        char fullname[_MAX_FNAME];
        int ret = 0;

        if (is_self_or_parent_dir(p->d_name))
            continue;
        dir_concat(fullname, dirname, p->d_name, NULL, SLASH_C);
        //如果是目录(且无需扫描子目录）或者出错，则直接跳过
        switch (dir_test(fullname)) {
        case TEST_ERROR:                //  失败
            continue;
        case TEST_YES:                  //  目录
            if (bScanChilds) {
                (void)scan_dir(fullname, bScanChilds, fexts, pfn, para);
            }
            continue;
        case TEST_NO:
        default:
            break;
        }
        //比较扩展名，如果不符合要求，则直接跳过
        if (fexts && !match_file_exts(p->d_name, fexts))
            continue;
        //  非目录
        ret = pfn(fullname, dirname, p->d_name, para);
        if (ret < 0) {
            (void)closedir(pdir);
            return ret;
        }
    }
    (void)closedir(pdir);
    return err_noerror;
}

