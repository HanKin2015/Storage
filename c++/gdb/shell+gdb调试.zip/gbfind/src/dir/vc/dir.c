/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#ifndef _MSC_VER
#error "This file only using in VC."
#endif
/**
 *  将_finddata_t类型的结果转换为dirent类型
 */
static void trans_dir(struct dirent *dir, const struct _finddata_t *found)
{
    assert(dir);
    assert(found);

    strcpy(dir->d_name, found->name);
    dir->d_ino = 0;
    ++dir->d_off;
    dir->d_reclen = strlen(dir->d_name);
}
/**
 *  开始目录遍历
 *  @param name 需要遍历的目录名字
 *  @return 遍历过程中的中间数据
 */
DIR *opendir(const char *name)
{
    char buf[_MAX_PATH];
    DIR *pdir = NULL;

    assert(name);

    sprintf_n(buf, _MAX_PATH, "%s\\*.*", name);

    pdir = CALLOC_OBJ(DIR);
    pdir->hfind = _findfirst(buf, &pdir->fdata);
    if (pdir->hfind == -1) {
        mem_free(pdir);
        return 0;
    }
    return pdir;
}
/**
 *  读取下一个文件（或目录）的信息
 */
struct dirent *readdir(DIR *pdir)
{
    assert(pdir);

    if (pdir->dir.d_off != 0) {
        int ret = _findnext(pdir->hfind, &pdir->fdata);
        if (ret != 0)
            return 0;
    }
    trans_dir(&pdir->dir, &pdir->fdata);
    return &pdir->dir;
}
/**
 *  结束目录遍历
 */
int closedir(DIR *pdir)
{
    assert(pdir);

    _findclose(pdir->hfind);
    mem_free(pdir);
    return 0;
}

int lstat(const char *name, struct stat *pst)
{
    assert(name);
    assert(pst);

    return stat(name, pst);
}
