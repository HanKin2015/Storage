/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/str/range.h>
#include <c/str/safe.h>
#include <c/common.h>
#include <assert.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
/**
 *  @file
 *  @ingroup stralgo
 *  @brief  字符串区间操作
 */
//TODO(zbc): 还没调试
/**
 *  在区间[pb,pe)中搜寻子串sub
 *  @param  pb  字串开头
 *  @param  pe  字串结束
 *  @param  sub 待搜寻的子串，是一个'\0'结束的字符串
 *  @return 返回NULL表示未找到匹配的子串，否则返回该子串在区间[pb,pe)中第一次出现的位置
 */
const char *range_substr(const char *pb, const char *pe, const char *sub)
{
    const char *cp = NULL;

    assert(pb && sub);
    assert(!pe || pe >= pb);

    if (!pe)
        return strstr(pb, sub);
    if (!*sub)
        return pb;

    cp = pb;
    while (*cp) {
        const char *s1 = cp;
        const char *s2 = sub;

        while (s1 < pe && *s2 && !(*s1-*s2)) {
            s1++;
            s2++;
        }

        if (!*s2)
            return cp;

        cp++;
    }
    return NULL;
}
/**
 *  拷贝一个字符串区间[pb, pe)到缓冲区buf中(buf长度为bufsize)
 *  @param  buf  字符串缓冲区
 *  @param  bufsize 字符串缓冲区长度
 *  @param  pb  区间开始
 *  @param  pe  区间结束
 *  @note 补'\0'和截断规则与strcpy_n一样
 */
void range_copy(char *buf, U32 bufsize, const char *pb, const char *pe)
{
    assert(buf);
    assert(!pe || pe >= pb);

    if (!pe) {
        strcpy_n(buf, bufsize, pb);
        return;
    }
    if (bufsize >= (U32)(pe - pb + 1))
        bufsize = (U32)(pe - pb + 1);
    while ((bufsize > 1) && (*buf++ = *pb++)) {
        --bufsize;
    }

    if (bufsize == 1)
        *buf = '\0';
}

/**
 *  比较两字符串是否相同，其中一个以'\0'作为结束，一个通过区间[pb, pe)标示
 *  @param  [in] pb      字串开头
 *  @param  [in] pe      字串结束
 *  @param  [in] strs    '\0'结束的字串
 *  @return 相等返回0，否则返回>0或<0
 *  @note [pb, pe)区间中如果有'\0'，可能会导致读strs字符串之后的无效空间
 */
int range_cmp(const char *pb, const char *pe, const char *strs)
{
    int ret = 0;

    assert(pb && strs);
    assert(!pe || pe >= pb);

    if (!pe)
        return strcmp(pb, strs);
    while (pb < pe) {
        ret = (int)*(U8 *)pb - (int)*(U8 *)strs;
        if (ret)
            break;
        ++pb;
        ++strs;
    }

    if (ret < 0)
        ret = -1;
    else if (ret > 0)
        ret = 1;
    else
        ret = *strs ? 1 : 0;

    return ret;
}
/**
 *  忽略大小写的字串比较，一个字串为区间[pb, pe),一个字串为'\0'结束字串
 *  @param  pb      字串开头
 *  @param  pe      字串结束
 *  @param  strs    '\0'结束的字串
 *  @return 相等返回0，否则返回>0或<0
 *  @note [pb, pe)区间中如果有'\0'，可能会导致读strs字符串之后的无效空间
 */
int range_ncase_cmp(const char *pb, const char *pe, const char *strs)
{
    int ret = 0;

    assert(pb && strs);
    assert(!pe || pe >= pb);

    if (!pe) {
        while (*pb) {
            ret = (int)toupper(*(U8 *)pb) - (int)toupper(*(U8 *)strs);
            if (ret)
                break;
            ++pb;
            ++strs;
        }
    } else {
        while (pb < pe) {
            ret = (int)toupper(*(U8 *)pb) - (int)toupper(*(U8 *)strs);
            if (ret)
                break;
            ++pb;
            ++strs;
        }
    }
    if (ret < 0)
        ret = -1;
    else if (ret > 0)
        ret = 1;
    else
        ret = *strs ? 1 : 0;

    return ret;
}
/**
 *  复制区间[pb, pe)的字符为一个新字符串
 *  @return 新字符串，新字符串一定以'\0'结尾。
 */
char *range_strdup(const char *pb, const char *pe)
{
    U32 len = 0;
    char *p = NULL;

    assert(pb);
    assert(!pe || pe >= pb);

    if (!pe)
        return strdup(pb);

    len = pe - pb;
    p = (char *)malloc(len + 1);
    assert(p);

    strncpy(p, pb, len);
    p[len] = '\0';
    return p;
}
/**
 *  @brief 检查区间[pb,pe)开头是否是子串strs,是则跳过，否则不动
 */
const char *range_skip(const char *pb, const char *pe, const char *strs)
{
    int ret = 0;
    const char *pc = pb;

    assert(pb);
    assert(!pe || pe >= pb);
    assert(strs);
    if (!pe) {
        while (*pc && *strs) {
            ret = (int)*pc - (int)*strs;
            if (ret)
                return pb;
            ++pc;
            ++strs;
        }
    } else {
        while (pc < pe && *strs) {
            ret = (int)*pc - (int)*strs;
            if (ret)
                return pb;
            ++pc;
            ++strs;
        }
    }
    if (*strs)
        return pb;
    return pc;
}


