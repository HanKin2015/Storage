/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/str/safe.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
/**
 *  @file
 *  @ingroup stralgo
 *  @brief 安全的字符串操作，用以替代标准库中容易出问题的strcpy系列函数
 */
#ifdef _MSC_VER
/**
 *  模拟glibc的snprintf行为，VC CRT的snprintf前面带_，而且不自动补0。
 */
int snprintf(char *buf, U32 bufsize, const char *fmt, ...)
{
    va_list ap;
    int ret;

    va_start(ap, fmt);
    ret = vsnprintf(buf, bufsize, fmt, ap);
    va_end(ap);

    return ret;
}
/**
 *  模拟glibc的vsnprintf行为，VC CRT的vsnprintf前面带_，而且不自动补0。
 */
int vsnprintf(char *buf, U32 bufsize, const char *fmt, va_list ap)
{
    int ret;

    ret = _vsnprintf(buf, bufsize, fmt, ap);

    if (ret < 0 || ret >= (int)bufsize) {   //  缓冲区不够用
        if (bufsize == 0) {                 //  无缓冲区可用
            return -1;
        }
        buf[bufsize - 1] = '\0';
        return -1;
    }
    return ret;
}
#endif
/**
 *  格式化输出到字符串缓冲区
 *  vsprintf_n保证缓冲区内字符串以0结尾，除非bufsize == 0
 */
void vsprintf_n(char *buf, U32 bufsize, const char *fmt, va_list ap)
{
    int ret = 0;
    assert(fmt);
    assert(buf);

    ret = vsnprintf(buf, bufsize, fmt, ap);

    //  MINGW的vsnprintf不自动补'\0'
    if (ret < 0 || ret >= (int)bufsize) {   //  缓冲区不够用
        if (bufsize == 0)                   //  无缓冲区可用
            return;
        buf[bufsize - 1] = '\0';
    }
}
/**
 *  格式化输出到字符串缓冲区
 *  sprintf_n保证缓冲区内字符串以0结尾，除非bufsize == 0
 */
void sprintf_n(char *buf, U32 bufsize, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsprintf_n(buf, bufsize, fmt, ap);
    va_end(ap);
}
/**
 *  限制拷贝长度的字符串拷贝
 *  @param [out] buf    目标缓冲区指针
 *  @param [in] bufsize 目标缓冲区的长度
 *  @param [in] src 源字符串
 *  @note strcpy_n保证拷贝长度不超过bufSize，只要bufSize不为0，
 *      目标缓冲区就是一个以'\0'结束的字符串。
 */
void strcpy_n(char *buf, U32 bufsize, const char *src)
{
    assert(buf && src);

    while ((bufsize > 1) && (*buf++ = *src++)) {
        --bufsize;
    }

    if (bufsize == 1)
        *buf = '\0';
}
/**
 *  安全的连接字符串
 *  @param [out] buf    目标缓冲区指针
 *  @param [in] bufsize 目标缓冲区的长度
 *  @param [in] src 源字符串
 *  @return 目标缓冲区的头指针
 *  @note strcat_n保证新字符串长度小于bufsize，只要bufsize不为0，
 *      目标缓冲区就是一个以'\0'结束的字符串。
 */
char *strcat_n(char *buf, U32 bufsize, const char *src)
{
    char *out;
    const char *pin;

    assert(buf && src);
//TODO(zbc): 保证末尾有'\0'
    //寻找字符串buf的末尾
    out = buf;
    while (*out && bufsize > 0) {
        ++out;
        --bufsize;
    }
    //在buf末尾追加一个新字符串src
    pin = src;
    while (bufsize > 1 && *pin) {
        *out++ = *pin++;
        --bufsize;
    }

    if (bufsize >= 1)
        *out = '\0';

    return out;
}

/**
 *  安全复制字符串，即使源串为空指针
 */
char *strdup_s(const char *sz)
{
    return strdup(sz ? sz : "");
}
