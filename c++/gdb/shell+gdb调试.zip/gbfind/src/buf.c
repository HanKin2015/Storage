/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/buf.h>
#include <assert.h>
#include <string.h>
#include <malloc.h>
#include <stdio.h>
/**
 *  @file
 *  @ingroup container
 *  @brief 输出缓冲区
 *  @see string
 */
/**
 *  写指针
 */
#define BUF_WPTR(buf)   ((buf)->buf_ + (buf)->wpos_)
/**
 *  读指针
 */
#define BUF_RPTR(buf)   ((buf)->buf_ + (buf)->rpos_)
/**
 *  缓冲区剩余长度
 *  @note 必须先保证该buf_t没发生溢出
 */
#define BUF_SPARE(buf)  ((buf)->size_ - (buf)->wpos_)
/**
 *  释放内部缓冲
 */
#define BUF_RELEASE(buf)                        \
    do {                                        \
        if ((buf)->buf_ && !(buf)->fixed_)      \
            free((buf)->buf_);              \
    } while (0)

/**
 *  @brief 缓冲区读指针
 */
char *buf_rptr(const buf_t *self)
{
    assert(self);
    return BUF_RPTR(self);
}
/**
 *  @brief 缓冲区写指针
 */
char *buf_wptr(const buf_t *self)
{
    assert(self);
    return BUF_WPTR(self);
}
/**
 *  @brief 缓冲区读位置
 */
U32 buf_rpos(const buf_t *self)
{
    assert(self);
    return self->rpos_;
}
/**
 *  @brief 缓冲区写位置
 */
U32 buf_wpos(const buf_t *self)
{
    assert(self);
    return self->wpos_;
}
/**
 *  @brief buf_t中放的是个字符串，检查是否有截断问题
 */
BOOL buf_str_is_overflow(const buf_t *self)
{
    assert(self);
    return self->wpos_ >= self->size_;
}
/**
 *  @brief 检查数据有没有溢出（二进制数据，无结束符）
 *  @param self 缓冲区对象
 *  @return 是否有溢出
 */
BOOL buf_bin_is_overflow(const buf_t *self)
{
    assert(self);
    return self->wpos_ > self->size_;
}
/**
 *  @brief 创建一个空的缓冲区对象
 */
buf_t *buf_new(void)
{
    return calloc(1, sizeof(buf_t));
}
/**
 *  @brief 释放“拥有”的内存块
 */
void buf_clear(buf_t *self)
{
    assert(self);

    BUF_RELEASE(self);
    self->buf_ = NULL;
    self->fixed_ = FALSE;
    self->size_ = 0;
    self->rpos_ = 0;
    self->wpos_ = 0;
}
/**
 *  @brief 释放缓冲区及其“拥有”的内存块
 */
void buf_free(buf_t *self)
{
    assert(self);

    BUF_RELEASE(self);
    free(self);
}
/**
 *  @brief 重置缓冲区
 *  @note 读写位置都回到开头，但缓冲内存块还有效
 */
void buf_reset(buf_t *self)
{
    assert(self);

    self->rpos_ = 0;
    self->wpos_ = 0;
}
/**
 *  @brief 交换两个缓冲的内容
 */
void buf_swap(buf_t *self, buf_t *rhs)
{
    buf_t buf;

    assert(self);
    assert(rhs);
    buf = *self;
    *self = *rhs;
    *rhs = buf;
}
/**
 * @brief 绑定一块内存作为buf_t的内部存储
 * @param self buf_t
 * @param buf  外部缓冲区指针
 * @param size 外部缓冲区buf的长度
 * @note buf“拥有”该内存块，需要负责释放该内存
 */
void buf_attach(buf_t *self, void *buf, U32 size)
{
    assert(self);
    assert(buf);
    assert(size > 0);

    BUF_RELEASE(self);
    self->buf_ = buf;
    self->size_ = size;
    self->rpos_ = 0;
    self->wpos_ = 0;
    self->fixed_ = FALSE;
}
/**
 *  @brief 释放内部缓冲块
 */
void *buf_detach(buf_t *self)
{
    void *p = NULL;

    assert(self);
    p = self->buf_;
    self->buf_ = NULL;
    self->fixed_ = FALSE;
    self->size_ = 0;
    self->rpos_ = 0;
    self->wpos_ = 0;
    return p;
}
/**
 *  @brief 引用某块内存用来写数据，不再自动分配内存
 *  @param  self    用来写的缓冲区
 *  @param  ptr     缓存写入数据的内存块的指针（这块内存可能会被全部改写）
 *  @param  size    ptr指向的内存块的长度
 */
void buf_refer_w(buf_t *self, void *ptr, U32 size)
{
    assert(self);
    assert(ptr);
    assert(size > 0);

    BUF_RELEASE(self);
    self->buf_ = (char *)ptr;
    self->size_ = size;
    self->wpos_ = 0;
    self->rpos_ = 0;
    self->fixed_ = TRUE;
}
/**
 *  @brief 引用某块内存用来读
 *  @param  self    用来读的缓冲区
 *  @param  ptr     数据块指针
 *  @param  size    ptr指向的数据块长度
 */
void buf_refer_r(buf_t *self, const void *ptr, U32 size)
{
    assert(self);
    assert(ptr);
    assert(size > 0);

    BUF_RELEASE(self);
    self->buf_ = (char *)ptr;
    self->size_ = size;
    self->wpos_ = size;
    self->rpos_ = 0;
    self->fixed_ = TRUE;
}
/**
 *  @brief 设置缓冲区的读指针位置
 *  @param  self 缓冲区指针
 *  @param  pos 读位置
 *  @return <0表示失败，否则表示成功
 */
HRET buf_set_r(buf_t *self, U32 pos)
{
    assert(self);

    if (pos > self->wpos_)
        return -1;
    self->rpos_ = pos;
    return 0;
}
/**
 *  @brief 设置缓冲区的写指针位置
 *  @param  self 缓冲区指针
 *  @param  pos 写位置
 *  @return <0表示失败，否则表示成功
 */
HRET buf_set_w(buf_t *self, U32 pos)
{
    assert(self);

    if (pos < self->rpos_)
        return -1;
    self->wpos_ = pos;
    return 0;
}
/**
 *  @brief 移动缓冲区的读指针位置
 *  @param  self 缓冲区指针
 *  @param  off  移动的偏移(>0表示往后移，<0表示往前移)
 *  @return <0表示失败，否则表示成功
 */
HRET buf_move_r(buf_t *self, int off)
{
    int pos = 0;

    assert(self);

    pos = (int)self->rpos_ + off;
    if (pos < 0 || pos > (int)self->wpos_)
        return -1;
    self->rpos_ = pos;
    return 0;
}
/**
 *  @brief 移动缓冲区的写指针位置
 *  @param  self 缓冲区指针
 *  @param  off  移动的偏移(>0表示往后移，<0表示往前移)
 *  @return <0表示失败，否则表示成功
 */
HRET buf_move_w(buf_t *self, int off)
{
    int pos = 0;

    assert(self);

    pos = (int)self->wpos_ + off;
    if (pos < (int)self->rpos_)
        return -1;
    self->wpos_ = (U32)pos;
    return 0;
}
/**
 *  @brief 从缓冲区self中读取一段数据
 *  @param  self     缓冲区指针
 *  @param  data    存放读取数据的缓冲区
 *  @param  size    读取数据长度
 *  @return <0表示失败，否则表示成功
 */
HRET buf_getn(buf_t *self, void *data, U32 size)
{
    assert(data && self);

    if (buf_data_size(self) < size)
        return -1;
    memcpy(data, BUF_RPTR(self), size);
    self->rpos_ += size;
    return 0;
}
/**
 *  @brief 从缓冲区读取一个字符
 *  @return <0表示读取失败，>=0表示读取到的字符的编码值，取值范围[0,256)
 */
int buf_getc(buf_t *self)
{
    assert(self);

    if (buf_data_size(self) < 1)
        return -1;
    return ((U8 *)self->buf_)[self->rpos_++];
}
/**
 *  @brief 写入一个字节
 */
void buf_putc(buf_t *self, U8 ch)
{
    assert(self);
    if (!self->fixed_) {
        (void)buf_reserve(self, 1);
    }
    if (self->wpos_ < self->size_)              //空间足够则写
        self->buf_[self->wpos_] = (char)ch;
    ++self->wpos_;                              //无论能不能写，都移动写位置
}
/**
 *  @brief 将一段数据写到缓冲区self中
 *  @param  self    缓冲区指针
 *  @param  data    待写入数据的缓冲区
 *  @param  size    写入数据长度
 */
void buf_putn(buf_t *self, const void *data, U32 size)
{
    assert(self);
    assert(data || size == 0);

    if (!self->fixed_) {
        buf_reserve(self, size);
    }
    if (self->wpos_ + size <= self->size_) {    //空间足够
        memcpy(BUF_WPTR(self), data, size);
        self->wpos_ += size;
    } else {                                    //空间不够，需要截断数据
        if (self->size_ > self->wpos_)          //还能写一部分
            memcpy(BUF_WPTR(self), data, BUF_SPARE(self));
        self->wpos_ += size;
    }
}
/**
 *  @brief 往字符串中追加字符串
 */
void buf_puts(buf_t *self, const char *ss)
{
    assert(self);
    assert(ss);

    buf_putn(self, ss, strlen(ss));
}
/**
 *  @brief 给缓冲区self保留size个字节，用于写数据
 */
HRET buf_reserve(buf_t *self, U32 size)
{
    char *pnew = NULL;
    U32 new_size = 0;

    assert(self);

    if (buf_spare_size(self) >= size)
        return 0;
    if (self->fixed_)
        return -1;
    new_size = self->size_ + size;
    if (new_size < self->size_ * 2)
        new_size = self->size_ * 2;
    if (new_size < 4)
        new_size = 4;
    pnew = (char *)malloc(new_size);

    if (self->buf_) {
        memcpy(pnew, self->buf_, self->wpos_);
        free(self->buf_);
    }
    self->buf_ = pnew;
    self->size_ = new_size;
    return 0;
}
/**
 *  @brief 不扩张缓冲区，在现有缓冲区内完成字符串格式化
 */
static void buf_static_vformat(buf_t *self, const char *fmt, va_list ap)
{
    int ret = 0;

    assert(self);
    assert(fmt);

    if (self->wpos_ >= self->size_)     //已经溢出
        return;

    ret = vsnprintf(BUF_WPTR(self), BUF_SPARE(self), fmt, ap);

    if (ret < 0) {                              //小于0，不清楚输出数据有多长
        self->buf_[self->size_ - 1] = '\0';
        self->wpos_ = self->size_ + 1;
    } else if ((U32)ret >= BUF_SPARE(self)) {   //输出数据过长，被截断
        self->buf_[self->size_ - 1] = '\0';
        self->wpos_ += (U32)ret;
    } else {                                    //缓冲足够，正常输出
        self->wpos_ += (U32)ret;
    }
}
/**
 *  @brief 以追加方式打印一个字符串
 */
static void buf_expand_vformat(buf_t *self, const char *fmt, va_list ap)
{
    U32 max_len = 1024;

    assert(self);
    assert(fmt);

    //  预分配一段缓冲，将字符串格式化输出到缓冲，如果产生溢出,
    //  则增大缓冲，重新尝试，直到不再溢出或出错为止
    for (;;) {
        int ret = 0;
        char *ptr = NULL;
#ifdef __GNUC__
        va_list ap_cpy;
#endif
        ptr = (char *)malloc(self->wpos_ + max_len);
        assert(ptr);
#ifdef __GNUC__
        //  64位平台下va_list的类型发生变化，在调用vsnprintf之前应该va_copy
        va_copy(ap_cpy, ap);
        ret = vsnprintf(ptr + self->wpos_, max_len, fmt, ap_cpy);
        va_end(ap_cpy);
#else
        ret = vsnprintf(ptr + self->wpos_, max_len, fmt, ap);
#endif
        if (ret >= 0 && (U32)ret < max_len) {       //输出没被截断
            if (self->buf_) {
                memcpy(ptr, self->buf_, self->wpos_);
                free(self->buf_);
            }
            self->buf_ = ptr;
            self->size_ = self->wpos_ + max_len;
            self->wpos_ += (U32)ret;
            return;
        }
        max_len *= 2;
        free(ptr);
    }
}

/**
 *  @brief 格式化字符串
 */
void buf_vformat(buf_t *self, const char *fmt, va_list ap)
{
    assert(self);
    assert(fmt);

    if (self->fixed_) {
        buf_static_vformat(self, fmt, ap);
    } else {
        buf_expand_vformat(self, fmt, ap);
    }
}
/**
 *  @brief 以追加方式打印一个字符串
 */
void buf_format(buf_t *self, const char *fmt, ...)
{
    va_list ap;

    assert(self);
    assert(fmt);

    va_start(ap, fmt);
    buf_vformat(self, fmt, ap);
    va_end(ap);
}
/**
 *  @brief 缓冲区的字符串数据结束位置
 */
#define BUF_STR_END(buf)    \
    ((self)->wpos_ < (self)->size_ ? (self)->wpos_ : (self)->size_ - 1)
/**
 *  @brief 结束一个字符串
 *  @note 在字符串后面补一个'\0', 如果空间不足，则截断字符串
 */
void buf_end_str(buf_t *self)
{
    assert(self);

    if (!self->fixed_) {
        (void)buf_reserve(self, 1);
    }
    if (self->size_ == 0)
        return;
    self->buf_[BUF_STR_END(self)] = '\0';
}
/**
 *  @brief 改写数据
 *  @note
 *  - 1) 不改变读取和写入位置;
 *  - 2) 不会扩展内存空间；
 *  - 3) 如果写入数据超出现有区间范围，不保证写入完整，能写多少写多少
 */
void buf_rewrite(buf_t *self, U32 pos, const void *data, U32 data_size)
{
    assert(self);
    assert(data);

    if (pos >= self->size_)
        return;
    if (pos + data_size > self->size_)
        data_size = self->size_ - pos;
    memcpy(self->buf_ + pos, data, data_size);
}
/**
 *  @brief 把缓存区内的内容作为字符串获取
 */
const char *buf_str(const buf_t *self)
{
    assert(self);

    if (self->size_ == 0)
        return "";
    assert(self->buf_[BUF_STR_END(self)] == '\0');
    return self->buf_;
}
/**
 *  @brief 缓冲区容量
 */
U32 buf_capacity(const buf_t *self)
{
    assert(self);
    return self->size_;
}
/**
 *  @brief 可读数据长度
 *  @note 实际写入的有效数据长度，如果有溢出，将不包括溢出部分
 */
U32 buf_data_size(const buf_t *self)
{
    assert(self);
    if (self->wpos_ >= self->size_)
        return self->size_ - self->rpos_;
    return self->wpos_ - self->rpos_;
}
/**
 *  @brief 空闲区域的大小
 */
U32 buf_spare_size(const buf_t *self)
{
    assert(self);
    if (self->wpos_ >= self->size_)
        return 0;
    return BUF_SPARE(self);
}

#ifdef __KERNEL__
EXPORT_SYMBOL(buf_rptr);
EXPORT_SYMBOL(buf_wptr);
EXPORT_SYMBOL(buf_rpos);
EXPORT_SYMBOL(buf_wpos);
EXPORT_SYMBOL(buf_str_is_overflow);
EXPORT_SYMBOL(buf_bin_is_overflow);
EXPORT_SYMBOL(buf_new);
EXPORT_SYMBOL(buf_clear);
EXPORT_SYMBOL(buf_free);
EXPORT_SYMBOL(buf_reset);
EXPORT_SYMBOL(buf_attach);
EXPORT_SYMBOL(buf_detach);
EXPORT_SYMBOL(buf_refer_w);
EXPORT_SYMBOL(buf_refer_r);
EXPORT_SYMBOL(buf_set_r);
EXPORT_SYMBOL(buf_set_w);
EXPORT_SYMBOL(buf_move_r);
EXPORT_SYMBOL(buf_move_w);
EXPORT_SYMBOL(buf_getn);
EXPORT_SYMBOL(buf_getc);
EXPORT_SYMBOL(buf_putc);
EXPORT_SYMBOL(buf_putn);
EXPORT_SYMBOL(buf_puts);
EXPORT_SYMBOL(buf_put_str);
EXPORT_SYMBOL(buf_reserve);
EXPORT_SYMBOL(buf_vformat);
EXPORT_SYMBOL(buf_format);
EXPORT_SYMBOL(buf_end_str);
EXPORT_SYMBOL(buf_str);
EXPORT_SYMBOL(buf_capacity);
EXPORT_SYMBOL(buf_data_size);
EXPORT_SYMBOL(buf_spare_size);
#endif  //__KERNEL__

