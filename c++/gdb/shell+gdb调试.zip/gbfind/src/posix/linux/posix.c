/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/posix.h>
#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <linux/unistd.h>
#include <time.h>

//usleep的单位是微秒(us)

//pid_t gettid(void);
//#ifdef __linux__
//_syscall0(pid_t, gettid)
//#endif

U32 posix_getpid(void)
{
    return (U32)getpid();
}

U32 posix_gettid(void)
{
    return (U32)syscall(SYS_gettid);
}

void posix_sleep(U32 second)
{
    (void)sleep(second);
}
/**
 *  睡眠ms毫秒
 */
void posix_msleep(U32 ms)
{
    struct timespec req;
    struct timespec rem;

    req.tv_sec = ms / 1000;
    req.tv_nsec = (ms % 1000) * 1000 * 1000;
    rem.tv_sec = 0;
    rem.tv_nsec = 0;

    for (;;) {
        //nanosleep如果因为收到信号提前返回会把剩余时间记录到rem中，并返回-1
        int ret = nanosleep(&req, &rem);
        if (ret >= 0)
            break;
        req = rem;
    }
}
/**
 *  暂停执行，等待按键
 */
void posix_pause(void)
{
    (void)pause();
}
/**
 *  跨平台的dup函数
 *  @param [in] fd 待复制的文件描述符
 */
int posix_dup(int fd)
{
    return dup(fd);
}
/**
 *  跨平台的dup2函数
 *  @param [in] fd    待复制的文件描述符
 *  @param [in] newfd Parameter_Description
 *  @return Return_Description
 *  @details Details
 */
int posix_dup2(int fd, int newfd)
{
    return dup2(fd, newfd);
}

int posix_open(const char *pathname, int flags, mode_t mode)
{
    return open(pathname, flags, mode);
}

int posix_read(int fd, void *buf, U32 count)
{
    return read(fd, buf, count);
}

int posix_write(int fd, const void *buf, U32 count)
{
    return write(fd, buf, count);
}

int posix_close(int fd)
{
    return close(fd);
}

int posix_unlink(const char *path)
{
    return unlink(path);
}

FILE *posix_popen(const char *fname, const char *mode)
{
    return popen(fname, mode);
}

int posix_pclose(FILE *stream)
{
    return pclose(stream);
}

int posix_mkdir(const char *path, int mode)
{
    return mkdir(path, mode);
}

int posix_chdir(const char *path)
{
    return chdir(path);
}
/**
 *  CPU个数
 */
U32 posix_core_cnt(void)
{
    U32 count = 1;
    count = sysconf(_SC_NPROCESSORS_CONF);
    return count;
}

int posix_spawnve(const char *fname, const char *argv[], const char *env[])
{
    int pid;
    int status = 0;

    pid = fork();
    if (pid < 0)
        return -1;
    else if (pid > 0) {
        waitpid(pid, &status, 0);
    } else {
        int ret = execve(fname, (char **)argv, (char **)env);
        _exit(ret);
    }
    return status;
}

