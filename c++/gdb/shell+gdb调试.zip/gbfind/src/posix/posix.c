/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/posix.h>

#ifdef _WIN32
#include "win/posix.c"
#else
#include "linux/posix.c"
#endif

