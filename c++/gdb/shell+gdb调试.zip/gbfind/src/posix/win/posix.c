/*
 *  Copyright (c) 2003-2013 Zbchun.
 *  这是一个开源软件，允许任意使用，但必须保留该版权声明。
 */
#include <c/posix.h>
#include <windows.h>
#include <io.h>
#include <direct.h>
#include <process.h>

U32 posix_getpid(void)
{
    return (U32)GetCurrentProcessId();
}

U32 posix_gettid(void)
{
    return (U32)GetCurrentThreadId();
}

void posix_sleep(U32 second)
{
    Sleep(second * 1000);
}

void posix_msleep(U32 ms)
{
    Sleep(ms);
}

void posix_pause(void)
{
    Sleep(INFINITE);
}

int posix_dup(int fd)
{
    return _dup(fd);
}

int posix_dup2(int fd, int newfd)
{
    return _dup2(fd, newfd);
}

int posix_open(const char *pathname, int flags, U32 mode)
{
    return _open(pathname, flags, mode);
}

int posix_read(int fd, void *buf, U32 count)
{
    return _read(fd, buf, count);
}

int posix_write(int fd, const void *buf, U32 count)
{
    return _write(fd, buf, count);
}

int posix_close(int fd)
{
    return _close(fd);
}

int posix_unlink(const char *path)
{
    return _unlink(path);
}

FILE *posix_popen(const char *fname, const char *mode)
{
    return _popen(fname, mode);
}

int posix_pclose(FILE *stream)
{
    return _pclose(stream);
}

int posix_chdir(const char *path)
{
    return _chdir(path);
}

int posix_mkdir(const char *path, int mode)
{
    return _mkdir(path);
}
/**
 *  CPU个数
 */
U32 posix_core_cnt(void)
{
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    return si.dwNumberOfProcessors;
}

int posix_spawnve(const char *fname, const char *argv[], const char *env[])
{
    return _spawnve(_P_WAIT, fname, argv, env);
}
