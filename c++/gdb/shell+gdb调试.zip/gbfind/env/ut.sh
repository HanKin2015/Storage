#!/bin/sh

if [ "Msys" == "`uname -o`" ]; then
    BINDIR="${ROOTDIR}/pack/MINGW/bin"
    LIBDIR="${ROOTDIR}/pack/MINGW/lib"
    EXEEXT=".exe"
    DLLEXT=".dll"
    LIBEXT=".lib"
else
    BINDIR="${ROOTDIR}/pack/LINUX/bin"
    LIBDIR="${ROOTDIR}/pack/LINUX/lib"
    EXEEXT=""
    DLLEXT=".so"
    LIBEXT=".a"
fi

ccmeta="${BINDIR}/ccmeta${EXEEXT}"
cmpmeta="${BINDIR}/cmpmeta${EXEEXT}"
gendata="${BINDIR}/gendata${EXEEXT}"
rwdata="${BINDIR}/rwdata${EXEEXT}"

krtd="${BINDIR}/krtd${EXEEXT}"
cfgd="${BINDIR}/cfgd${EXEEXT}"
luad="${BINDIR}/luad${EXEEXT}"
msgd="${BINDIR}/msgd${EXEEXT}"
statd="${BINDIR}/statd${EXEEXT}"
syncd="${BINDIR}/syncd${EXEEXT}"
udpd="${BINDIR}/udpd${EXEEXT}"
taskflowd="${BINDIR}/taskflowd${EXEEXT}"
webui="${BINDIR}/webui${EXEEXT}"
findme="${BINDIR}/findme${EXEEXT}"

krpc="${BINDIR}/krpc${EXEEXT}"
tui="${BINDIR}/tui${EXEEXT}"
json="${BINDIR}/json${EXEEXT}"
xmlset="${BINDIR}/xmlset${EXEEXT}"
xmlget="${BINDIR}/xmlget${EXEEXT}"
xpp="${BINDIR}/xpp${EXEEXT}"
genopt="${BINDIR}/genopt${EXEEXT}"
j2x="${BINDIR}/j2x${EXEEXT}"

KW3="$krpc -c 7900 -w 3"

MAIN_ARGU=1
MAIN_FAILED=2
MAIN_ERROR=3

EXPECT_EQ()
{
    local expect="$1"
    local actual="$2"
    local report="$3"

    if [ "$expect" != "$actual" ]; then
        echo "[FAILED] $report ..."
        echo "expect: $expect"
        echo "actual: $actual"
        exit 1
    fi
    echo "[PASS] expect $expect: $report ..."
}

EXPECT_NEQ()
{
    local expect="$1"
    local actual="$2"
    local report="$3"

    if [ "$expect" == "$actual" ]; then
        echo "[FAILED] $report ..."
        echo "expect neq: $expect"
        exit 1
    fi
    echo "[PASS] expect $expect != $report ..."
}

EXPECT_FILE()
{
    local expect_file="$1"
    local actual_file="$2"
    local report="$3"

    diff -w $expect_file $actual_file > /dev/null
    if [ $? -ne 0 ]; then
        echo "[FAILED] compare file [$expect_file <=> $actual_file] failed ..."
        exit 1
    fi
    echo "[PASS] compare file [$expect_file <=> $actual_file] ok ..."
}


EXEC_EXPECT_OK()
{
    local expect="$1"
    local command="$2"
    local result

    result=`$command`
    if [ $? -ne 0 ]; then
        echo "[FAILED] run failed: $command ..."
        echo "result: $result"
        exit 1
    fi

    if [ "$expect" != "$result" ]; then
        echo "[FAILED] $command ..."
        echo "expect: $expect"
        echo "result: $result"
        exit 1
    fi
    echo "[PASS] expect '$expect': $command ..."
}

EXEC_EXPECT_RET()
{
    local expect="$1"
    local command="$2"
    local result
    local actual

    result=`$command`
    actual=$?
    if [ $actual -ne $expect ]; then
        echo "[FAILED] $command ..."
        echo "expect: $expect"
        echo "actual: $actual"
        exit 1
    fi

    echo "[PASS] expect $expect: $command ..."
}

EXEC_WAIT_OK()
{
    local timeout=$1
    local command="$2"
    local result

    for ((i=1;i<=${timeout};i++)); do
        echo wait ${i}s ...
        sleep 1
        result=`$command`
        if [ $? -eq 0 ]; then
            echo "[PASS] wait ok: $command ..."
            return 0
        fi
    done
    echo "[FAILED] wait timeout: $command ..."
    exit 1
}

