#include <c/dir/scandir.h>
#include <c/dir/dir.h>
#include <c/buf.h>
//#include <c/def.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef _MSC_VER
#pragma warning(disable:4786)
#endif

/*
//  NOTEXIST    文件或目录不存在
//  DIRECTORY   目录
//  FILE        文件
*/

typedef enum TARGET_TYPE {
    tNOTEXIST,
    tDIRECTORY,
    tFILE
} TARGET_TYPE;

static const char *s_pszPath    = ".";
static BOOL s_bShowHelp         = FALSE;            //显示Usage
static BOOL s_bLogo             = TRUE;             //是否输出LOGO信息
static BOOL s_bVerbose          = FALSE;            //是否显示详细信息
static TARGET_TYPE s_tTarget    = tNOTEXIST;        //搜索目标的类型
static BOOL s_bStatAll          = TRUE;             //查找所有文件类型
static BOOL s_bStatSubDir       = FALSE;            //搜索子目录
static BOOL s_bSkipCppComment   = TRUE;             //是否跳过C++注释
//
static const char *s_pszWildcard;                   //文件名的通配串
static const char *s_pszFileExts;                   //文件后缀

//
static int s_gb_line_cnt        = 0;                //有中文的行数
//
TARGET_TYPE CheckPath(const char *szpath)
{
    if (!szpath || szpath[0] == '\0')
        return tNOTEXIST;

    struct stat stat_info;

    int ret = stat(szpath, &stat_info);
    if (ret < 0)
        return tNOTEXIST;
    if (S_ISDIR(stat_info.st_mode))
        return tDIRECTORY;
    return tFILE;
}

void Set_StatCPP()
{
    s_bStatAll = FALSE;
    s_pszFileExts = "c;cpp;h;hpp;idl";
}

void Set_StatPart(const char *szExt)
{
    s_bStatAll = FALSE;
    s_pszFileExts = szExt;
}

#ifndef _MSC_VER
#define _vsnprintf vsnprintf
#endif
void PrintVerbose(const char *fmt, ...)
{
    if (!s_bVerbose)
        return;
    char buf[1024];
    va_list va;
    va_start(va, fmt);
    _vsnprintf(buf, 1024, fmt, va);
    va_end(va);
    printf("%s", buf);
}

void PrintLogo()
{
    printf("Copyright (C) by HaiFen studio, 1999-2004.\n\n");
}

void PrintUsage()
{
    printf("Usage:\n\n");
    printf("gbfind [pathname] [/s] [/c] [/a] [/e:ext{;ext}] [/w:wildcard]\n\n");
    printf("pathname            指定需要查找中文的文件或目录\n");
    printf("/s                  包括子目录\n");
    printf("/a                  指定查找所有文件的中文(查找目录时有效,缺省)\n");
    printf("/c                  指定只查找C/C++源文件中的中文(查找目录时有效)\n");
    printf("/e:ext{;ext}        指定需要查找中文的文件后缀(查找目录时有效)\n");
    printf("/w:wildcard         指定搜索文件时使用的通配符(查找目录时有效)\n");
    printf("/i                  是否显示详细信息\n");
    printf("/v                  使用VC可识别格式输出报告\n");
    printf("/?                  显示帮助信息\n");
    printf("...\n");
}

BOOL ParseCmdInfo(int argc, char *argv[])
{
    int i;
    int arg_start = 1;
    if (argc > 1 && argv[1][0] != '/') {
        s_pszPath = argv[1];
        ++arg_start;
    }
    s_tTarget = CheckPath(s_pszPath);
    for (i = arg_start ; i < argc ; ++i) {
        if(!strncmp(argv[i], "/e:", 3)) {                //文件类型
            Set_StatPart(argv[i]+3);
        } else if(!strcmp(argv[i], "/c")) {
            Set_StatCPP();
        } else if(!strncmp(argv[i], "/w:", 3)) {          //通配符选项
            s_pszWildcard = argv[i]+3;
        } else if(!strcmp(argv[i], "/s")) {
            s_bStatSubDir = TRUE;
        } else if(!strcmp(argv[i], "/i")) {
            s_bVerbose = TRUE;
        } else if(!strcmp(argv[i], "/a")) {
            s_bStatAll = TRUE;
        } else if(!strcmp(argv[i], "/?")) {
            s_bShowHelp = TRUE;
        } else {
            PrintLogo();
            printf("bad parameter: %s\n\n", argv[i]);
            PrintUsage();
            return FALSE;
        }
    }
    return TRUE;
}
//
int ReadLine_NoSkip(buf_t *strLine, FILE *fp)
{
    int line = 0;
    while(!feof(fp)) {
        char c = fgetc(fp);
        if (c == '\n') {
            ++line;
            break;
        }
        buf_putc(strLine, c);
    }
    return line;
}

int ReadLine_SkipCppComment(buf_t *strLine, FILE *fp)
{
    int line = 0;
    while(!feof(fp)) {
        char c = fgetc(fp);
        if (c == '\n') {
            return ++line;
        } else if (c == '/') {
            c = fgetc(fp);
            if (c == '/'){      //行注释跳过
                while(!feof(fp)) {
                    c = fgetc(fp);
                    if (c == '\n'){
                        return ++line;
                    }
                }
            } else if(c == '*') { //块注释，跳过块内部分
                while(!feof(fp)) {
                    c = fgetc(fp);
                    if (c == '\n') {
                        ++line;
                    } else if(c == '*') {
                        c = fgetc(fp);
                        if (c == '/')
                            break;
                        else {
                            ungetc(c, fp);
                        }
                    }
                }
            } else {
                ungetc(c, fp);
                buf_putc(strLine, '/');
            }
        } else {
            buf_putc(strLine, c);
        }
    }
    return line;

}

int ReadLine(buf_t *strLine, FILE *fp)
{
    int ret;
    buf_reset(strLine);
    if (s_bSkipCppComment)
        ret = ReadLine_SkipCppComment(strLine, fp);
    else
        ret = ReadLine_NoSkip(strLine, fp);
    buf_end_str(strLine);
    return ret;
}

void StatFile(const char *fname)
{
    buf_t strLine = ZERO(buf_t);

    PrintVerbose("file: [%s] ...\n",fname);

    FILE *fp = fopen(fname, "r");
    if (!fp)
        return;
    int line = 1;
    while(!feof(fp)) {
        int num = ReadLine(&strLine, fp);
        const char *p = buf_rptr(&strLine);
        for ( ; *p ; ++p) {
            if ((*p & 0x80) != 0) {   //有中文
                if (*p == EOF)
                    break;
                printf("%s(%d): %s\n", fname, line, buf_str(&strLine));
                ++s_gb_line_cnt;
                break;
            }
        }
        line += num;
    }
    fclose(fp);
}

static HRET scandir_SeeFile(const char *fullname
    , const char *dirname, const char *fname, void *para)
{
    StatFile(fullname);
    return 0;
}

//查找目录
void StatDirectory(const char *path)
{
    scan_dir(path, s_bStatSubDir, s_bStatAll ? NULL : s_pszFileExts
        , scandir_SeeFile, NULL);
}

void StatTarget()
{
    if (s_tTarget == tNOTEXIST) {
        printf("file not exist: %s\n", s_pszPath);
        PrintUsage();
        return;
    } else if(s_tTarget == tFILE) {   //file
        StatFile(s_pszPath);
        return;
    } else {                          //directory
        StatDirectory(s_pszPath);
    }

    printf("\nsearch [%s] - %d lines found\n", s_pszPath, s_gb_line_cnt);
}

int main(int argc, char* argv[])
{
    if (!ParseCmdInfo(argc, argv))
        return -1;
    if (s_bShowHelp) {
        PrintLogo();
        PrintUsage();
        return 0;
    }
    if (s_bLogo)
        PrintLogo();
    StatTarget();
    return 0;
}
