#!/usr/bin/expect

log_file ./gbfind_test.log

spawn gdb ./pack/LINUX/bin/gbfind

# 在main函数开头设断点
expect "(gdb)"
send "break main\n"

# 启动gbfind
expect "(gdb)"
send "r /c /s /e:xsl\n"

# 调用gbfind中的函数
expect "(gdb)"
send "call StatFile(\"./gbfind.c\")\n"

# 调用CheckPath函数进行测试，并检查结果，如果结果不对，进入交互调试环节
expect "(gdb)"
send "call CheckPath(\".\")\n"
expect {
    "tDIRECTORY" {send_log "CheckPath(.) OK\n"}
    "tFILE" {interact}
    "tNOTEXIST" {interact}
}

# 从断点处继续执行
expect "(gdb)"
send "c\n"

# 退出gdb
expect "(gdb)"
send "quit\n"
