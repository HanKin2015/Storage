# shell+gdb实现单元测试和非交互调试

## 说明

1. 把gdfind编译成可执行程序的方法：在gdfind目录运行make

2. 编写脚本，在脚本中调用gdb调试gdfind程序。可利用expect与gdb进行交互，实现非交互的调试流程。
expect的使用方法请参考：
https://www.cnblogs.com/lzrabbit/p/4298794.html
https://linux.die.net/man/1/expect

gdb的用法请参考：
http://www.gnu.org/software/gdb/documentation/
https://sourceware.org/gdb/current/onlinedocs/gdb/

3. gbfind/dbg.sh和gbfind/dbg_ReadLine.sh是示例脚本

在gbfind目录执行./dbg.sh命令，可以观察该脚本的运行结果。

4. 本练习的目的是:

A) 帮助学员掌握gdb的用法（包括一些高级用法）；
B) 帮助学员掌握一种利用expect+gdb进行自动化调试的方法(可以跳过很多不必要的逻辑，大大提升调试效率)；

## 要求

1. 使用expect+gdb的方式(参考gbfind/dbg.sh)对CheckPath，ReadLine_NoSkip，
ReadLine_SkipCppComment，ReadLine，StatFile，StatDirectory这6个函数进行单元测试。

对于ReadLine这类有复杂参数依赖的函数，可以在ReadLine或其调用者上设断点，
然后在执行ReadLine之前修改传递给ReadLine的参数。
通过这种方法，可以让ReadLine执行正常不会跑到的流程。相关做法请参考dbg_ReadLine.sh

2. 每个测试用例一个案例脚本。

3. 完成一个shell脚本(采用bash)，执行上述案例脚本，并遍历上述案例脚本产生的日志文件，输出单测失败的案例脚本文件名称。
说明：在上述案例测试脚本中，如果有异常，可以让expect输出特定日志内容。
shell脚本遍历日志文件时检查是否有特定日志内容，以判断是否有测试案例执行不正常。





